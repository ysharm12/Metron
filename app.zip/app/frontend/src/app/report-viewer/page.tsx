"use client";

import { useEffect, useState } from 'react';
import MainLayout from '../../components/MainLayout';
import { useRouter } from 'next/navigation';

export default function ReportViewerPage() {
  const [reportContent, setReportContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [approving, setApproving] = useState(false);
  const [approved, setApproved] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const fetchReport = async () => {
      try {
        setIsLoading(true);
        
        // Fetch the report content
        const response = await fetch('/api/get-report-content');
        
        if (!response.ok) {
          throw new Error('Failed to load report');
        }
        
        const html = await response.text();
        setReportContent(html);
        setError(null);
      } catch (err) {
        console.error('Error loading report:', err);
        setError(err instanceof Error ? err.message : 'Failed to load report');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchReport();
  }, []);

  // Function to approve the report
  const handleApprove = async () => {
    try {
      setApproving(true);
      const response = await fetch('http://localhost:8000/approve', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      const data = await response.json();
      
      if (data.success) {
        setApproved(true);
        // Show success message
        alert('Report approved! Next steps have been initiated.');
      } else {
        throw new Error(data.error || 'Failed to approve report');
      }
    } catch (err) {
      console.error('Error approving report:', err);
      setError(err instanceof Error ? err.message : 'Failed to approve report');
    } finally {
      setApproving(false);
    }
  };

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Campaign Report</h1>
          
          <button 
            onClick={handleApprove}
            disabled={approving || approved || isLoading || !!error}
            className={`px-6 py-2 rounded text-white font-medium ${approving ? 'bg-blue-400' : approved ? 'bg-green-600' : 'bg-blue-600 hover:bg-blue-700'}`}
          >
            {approving ? 'Processing...' : approved ? 'Approved ✓' : 'Approve Report'}
          </button>
        </div>
        
        {isLoading && (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        )}
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}
        
        {!isLoading && !error && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <div 
              className="report-content" 
              dangerouslySetInnerHTML={{ __html: reportContent }} 
            />
          </div>
        )}
      </div>
    </MainLayout>
  );
}
