"use client";

import React, { useState } from 'react';
import ReviewPopup from '../../components/ReviewPopup';

export default function TestPopupPage() {
  const [showPopup, setShowPopup] = useState(false);
  
  const handleShowPopup = () => {
    console.log('Showing popup manually');
    setShowPopup(true);
  };
  
  const handleClosePopup = () => {
    console.log('Closing popup');
    setShowPopup(false);
  };
  
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">Test Popup Page</h1>
      
      <p className="mb-4">
        This page allows you to test the ReviewPopup component directly.
      </p>
      
      <button 
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={handleShowPopup}
      >
        Show Review Popup
      </button>
      
      {showPopup && (
        <ReviewPopup onClose={handleClosePopup} />
      )}
    </div>
  );
}
