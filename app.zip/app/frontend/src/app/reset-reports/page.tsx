"use client";

import React, { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useReportMonitor } from '../../contexts/ReportMonitorContext';

export default function ResetReportsPage() {
  const { resetMonitor } = useReportMonitor();
  const router = useRouter();
  
  // Reset the monitor when this page loads
  useEffect(() => {
    console.log('Resetting report monitor...');
    
    // Clear localStorage directly to ensure it's completely reset
    if (typeof window !== 'undefined') {
      localStorage.removeItem('optumMarketing_seenReports');
      console.log('Cleared localStorage for seen reports');
    }
    
    // Also call the context's reset function
    resetMonitor();
    
    // Show a message and redirect after a short delay
    const timer = setTimeout(() => {
      router.push('/');
    }, 3000);
    
    return () => clearTimeout(timer);
  }, [resetMonitor, router]);
  
  return (
    <div className="container mx-auto p-8">
      <div className="bg-white rounded-lg p-6 max-w-md mx-auto shadow-xl">
        <h1 className="text-2xl font-bold mb-4">Resetting Report Monitor</h1>
        
        <p className="mb-4">
          All seen reports have been cleared from memory. You will now receive notifications
          for reports again, even if you've seen them before.
        </p>
        
        <p className="text-sm text-gray-500">
          Redirecting to home page in 3 seconds...
        </p>
      </div>
    </div>
  );
}
