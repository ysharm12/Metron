"use client"
import MainLayout from '../../components/MainLayout';
import DocumentsTable from '../../components/documents/DocumentsTable';
import Card from '../../components/ui/Card';

export default function DocumentsPage() {
  return (
    <MainLayout>
      <Card>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Documents</h1>
        </div>
        
        <DocumentsTable />
      </Card>
    </MainLayout>
  );
}
