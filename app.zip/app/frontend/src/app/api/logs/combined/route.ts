import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const AGENTIC_BEHAVIOR_PATH = path.join(process.cwd(), '..', 'backend', 'output', 'logging_agentic_behavior.json');
const RUNTIME_TRACKER_PATH = path.join(process.cwd(), '..', 'backend', 'output', 'runtime_tracker.json');
const TASKS_COUNTER_PATH = path.join(process.cwd(), '..', 'backend', 'output', 'tasks_counter.json');

interface LogFile {
  path: string;
  name: string;
  exists: boolean;
  isEmpty: boolean;
  data: any;
  error?: string;
}

export async function GET() {
  try {
    // Check and read all log files
    const logFiles: LogFile[] = [
      { 
        path: AGENTIC_BEHAVIOR_PATH, 
        name: 'agentic_behavior',
        exists: false,
        isEmpty: false,
        data: null
      },
      { 
        path: RUNTIME_TRACKER_PATH, 
        name: 'runtime_tracker',
        exists: false,
        isEmpty: false,
        data: null
      },
      { 
        path: TASKS_COUNTER_PATH, 
        name: 'tasks_counter',
        exists: false,
        isEmpty: false,
        data: null
      }
    ];

    // Process each log file
    for (const logFile of logFiles) {
      try {
        // Check if file exists
        logFile.exists = fs.existsSync(logFile.path);
        
        if (!logFile.exists) {
          logFile.error = `${logFile.name} file does not exist`;
          continue;
        }

        // Read file content
        const fileContent = fs.readFileSync(logFile.path, 'utf8');
        
        // Check if file is empty
        logFile.isEmpty = !fileContent.trim();
        
        if (logFile.isEmpty) {
          logFile.error = `${logFile.name} file is empty`;
          continue;
        }

        // Parse JSON content
        logFile.data = JSON.parse(fileContent);
      } catch (error) {
        logFile.error = `Error processing ${logFile.name}: ${(error as Error).message}`;
      }
    }

    // Create combined data structure
    const combinedData: any = {
      agent_metrics: [],
      timeline: [],
      summary: {
        total_tasks: 0,
        total_runtime: 0,
        agents_count: 0,
        avg_task_time: 0,
        completed_tasks: 0,
        running_tasks: 0,
        failed_tasks: 0
      }
    };

    // Get agentic behavior data
    const agenticBehavior = logFiles.find(f => f.name === 'agentic_behavior')?.data;
    if (agenticBehavior && agenticBehavior.logs) {
      // Extract timeline data
      combinedData.timeline = agenticBehavior.logs.map((log: any) => ({
        id: log.id,
        agent_name: log.agent_name,
        step: log.step,
        process: log.process,
        details: log.details,
        time_taken: log.time_taken,
        timestamp: log.timestamp,
        status: log.status,
        task_id: log.task_id
      }));

      // Count task statuses
      combinedData.summary.completed_tasks = agenticBehavior.logs.filter((log: any) => log.status === 'completed').length;
      combinedData.summary.running_tasks = agenticBehavior.logs.filter((log: any) => log.status === 'running').length;
      combinedData.summary.failed_tasks = agenticBehavior.logs.filter((log: any) => log.status === 'failed').length;
    }

    // Get runtime tracker data
    const runtimeTracker = logFiles.find(f => f.name === 'runtime_tracker')?.data;
    
    // Get tasks counter data
    const tasksCounter = logFiles.find(f => f.name === 'tasks_counter')?.data;

    // Combine data for agent metrics
    if (runtimeTracker && tasksCounter) {
      const agents = new Set([
        ...Object.keys(runtimeTracker), 
        ...Object.keys(tasksCounter)
      ]);
      
      combinedData.agent_metrics = Array.from(agents).map(agent => ({
        agent_name: agent,
        runtime: runtimeTracker[agent] || 0,
        tasks_count: tasksCounter[agent] || 0,
        avg_task_time: tasksCounter[agent] ? (runtimeTracker[agent] / tasksCounter[agent]) : 0
      }));

      // Calculate summary metrics
      combinedData.summary.total_tasks = Object.values(tasksCounter).reduce((sum: any, count: any) => sum + count, 0);
      combinedData.summary.total_runtime = Object.values(runtimeTracker).reduce((sum: any, time: any) => sum + time, 0);
      combinedData.summary.agents_count = agents.size;
      combinedData.summary.avg_task_time = combinedData.summary.total_tasks ? 
        (combinedData.summary.total_runtime / combinedData.summary.total_tasks) : 0;
    }

    // Return the combined data
    return NextResponse.json(
      { 
        logFiles,
        combinedData
      },
      { status: 200 }
    );
  } catch (error) {
    // Handle any other errors
    return NextResponse.json(
      { error: 'Failed to process log files', message: (error as Error).message },
      { status: 500 }
    );
  }
}
