import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const LOG_FILE_PATH = path.join(process.cwd(), '..', 'backend', 'output', 'tasks_counter.json');

export async function GET() {
  try {
    // Check if file exists
    if (!fs.existsSync(LOG_FILE_PATH)) {
      return NextResponse.json(
        { error: 'Tasks counter file does not exist', exists: false },
        { status: 404 }
      );
    }

    // Read file content
    const fileContent = fs.readFileSync(LOG_FILE_PATH, 'utf8');
    
    // Check if file is empty
    if (!fileContent.trim()) {
      return NextResponse.json(
        { error: 'Tasks counter file is empty', exists: true, isEmpty: true },
        { status: 200 }
      );
    }

    try {
      // Parse JSON content
      const tasksData = JSON.parse(fileContent);
      
      // Process the data to create a more structured format
      const formattedData = Object.entries(tasksData).map(([agent, count]) => ({
        agent_name: agent,
        tasks_count: count,
      }));
      
      // Sort by task count (descending)
      formattedData.sort((a, b) => (b.tasks_count as number) - (a.tasks_count as number));
      
      // Calculate total tasks
      const totalTasks = formattedData.reduce((sum, item) => sum + (item.tasks_count as number), 0);
      
      // Return the parsed and formatted data
      return NextResponse.json(
        { 
          exists: true, 
          isEmpty: false, 
          data: {
            raw: tasksData,
            formatted: formattedData,
            totalTasks
          }
        },
        { status: 200 }
      );
    } catch (parseError) {
      // Handle JSON parsing error
      return NextResponse.json(
        { 
          error: 'Invalid JSON format in tasks counter file', 
          exists: true, 
          isEmpty: false,
          rawContent: fileContent 
        },
        { status: 500 }
      );
    }
  } catch (error) {
    // Handle any other errors
    return NextResponse.json(
      { error: 'Failed to read tasks counter file', message: (error as Error).message },
      { status: 500 }
    );
  }
}
