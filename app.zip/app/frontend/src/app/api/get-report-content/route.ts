import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

export const dynamic = 'force-dynamic'; // Disable caching for this route

// Path to the campaign report file
const REPORT_FILE_PATH = path.resolve(process.cwd(), '..', 'backend', 'output', 'campaign_report.html');
console.log('Reading report file from:', REPORT_FILE_PATH);

export async function GET() {
  try {
    // Check if the report file exists
    try {
      await fs.access(REPORT_FILE_PATH);
      
      // Read the HTML content
      const htmlContent = await fs.readFile(REPORT_FILE_PATH, 'utf-8');
      
      // Return the HTML content with the appropriate content type
      return new NextResponse(htmlContent, {
        headers: {
          'Content-Type': 'text/html',
        },
      });
    } catch (error) {
      // File doesn't exist or can't be accessed
      return NextResponse.json(
        { error: 'Report file not found' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('Error reading report file:', error);
    return NextResponse.json(
      { error: 'Failed to read report file', details: String(error) },
      { status: 500 }
    );
  }
}
