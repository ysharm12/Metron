import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Decode the base64 filename
    const fileName = Buffer.from(params.id, 'base64').toString();
    
    // Path to the synthetic_data directory
    const dataDir = path.join(process.cwd(), '..', 'backend', 'synthetic_data');
    
    // Full path to the file
    const filePath = path.join(dataDir, fileName);
    
    // Check if file exists
    if (!fs.existsSync(filePath)) {
      return NextResponse.json({ error: 'File not found' }, { status: 404 });
    }
    
    // Get file content
    const fileContent = fs.readFileSync(filePath, 'utf8');
    
    // Get file extension
    const fileExtension = path.extname(fileName).slice(1).toLowerCase();
    
    // Determine content type based on file extension
    let contentType = 'text/plain';
    if (fileExtension === 'json') {
      contentType = 'application/json';
    } else if (fileExtension === 'csv') {
      contentType = 'text/csv';
    } else if (fileExtension === 'html') {
      contentType = 'text/html';
    }
    
    return new NextResponse(fileContent, {
      headers: {
        'Content-Type': contentType,
      },
    });
  } catch (error) {
    console.error('Error reading document:', error);
    return NextResponse.json({ error: 'Failed to fetch document content' }, { status: 500 });
  }
}
