import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic'; // Disable caching for this route

export async function POST() {
  try {
    console.log('API: Resetting seen reports state');
    
    // This is a server-side API endpoint that can be called to reset the state
    // The actual resetting happens on the client side, but this provides an API
    // that can be called from anywhere to trigger a reset
    
    return NextResponse.json({
      success: true,
      message: 'Reset signal sent. Client will need to clear localStorage.'
    });
  } catch (error) {
    console.error('Error in reset-seen-reports API:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'Failed to process reset request' 
      },
      { status: 500 }
    );
  }
}
