import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const channel = searchParams.get('channel');
  
  if (!channel) {
    return NextResponse.json({ error: 'Channel parameter is required' }, { status: 400 });
  }
  
  const validChannels = ['sms', 'linkedin', 'twitter', 'instagram', 'directmail'];
  if (!validChannels.includes(channel)) {
    return NextResponse.json({ error: 'Invalid channel' }, { status: 400 });
  }
  
  const outputDir = path.join(process.cwd(), '..', 'backend', 'output');
  const filename = `${channel}.txt`;
  const filePath = path.join(outputDir, filename);
  
  try {
    if (!fs.existsSync(filePath)) {
      return NextResponse.json({ content: '', exists: false }, { status: 200 });
    }
    
    const content = fs.readFileSync(filePath, 'utf8');
    return NextResponse.json({ content, exists: true }, { status: 200 });
  } catch (error) {
    console.error('Error reading file:', error);
    return NextResponse.json({ error: 'Failed to read file' }, { status: 500 });
  }
}
