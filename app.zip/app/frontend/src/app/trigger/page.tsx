"use client"
import MainLayout from '../../components/MainLayout';
import TriggerForm from '../../components/trigger/TriggerForm';
import Card from '../../components/ui/Card';

export default function TriggerPage() {
  return (
    <MainLayout>
      <Card>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Create New Campaign</h1>
        <TriggerForm />
      </Card>
    </MainLayout>
  );
}
