"use client"
import MainLayout from '../../components/MainLayout';
import ChannelContent from '../../components/content/ChannelContent';

export default function ContentPage() {
  return (
    <MainLayout>
      <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Channel Content Editor</h1>
        </div>
        
        <ChannelContent />
      </div>
    </MainLayout>
  );
}
