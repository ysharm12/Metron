import { useState, useEffect } from 'react';

interface AgentTasks {
  agent_name: string;
  tasks_count: number;
}

interface TasksCounterProps {
  className?: string;
}

export default function TasksCounter({ className = '' }: TasksCounterProps) {
  const [tasksData, setTasksData] = useState<AgentTasks[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [totalTasks, setTotalTasks] = useState<number>(0);

  useEffect(() => {
    const fetchTasksData = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/logs/tasks-counter');
        const data = await response.json();
        
        if (data.exists && !data.isEmpty && data.data) {
          setTasksData(data.data.formatted);
          setTotalTasks(data.data.totalTasks);
        } else {
          setError(data.error || 'No tasks data available');
        }
      } catch (err) {
        setError('Failed to fetch tasks data');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchTasksData();
    
    // Set up polling for real-time updates
    const intervalId = setInterval(fetchTasksData, 10000); // Poll every 10 seconds
    
    return () => clearInterval(intervalId);
  }, []);

  if (loading) {
    return (
      <div className={`flex justify-center items-center h-64 ${className}`}>
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`bg-red-50 dark:bg-red-900 p-4 rounded-md ${className}`}>
        <p className="text-red-800 dark:text-red-200">{error}</p>
      </div>
    );
  }

  return (
    <div className={className}>
      <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Tasks Distribution</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Total Tasks</h4>
          <p className="text-3xl font-bold text-gray-900 dark:text-white">{totalTasks}</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Active Agents</h4>
          <p className="text-3xl font-bold text-gray-900 dark:text-white">{tasksData.length}</p>
        </div>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Agent
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Tasks Count
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                % of Total
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {tasksData.map((agent) => {
              const percentage = totalTasks > 0 ? (agent.tasks_count / totalTasks) * 100 : 0;
              
              return (
                <tr key={agent.agent_name}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {agent.agent_name.replace('_', ' ')}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 dark:text-white">{agent.tasks_count}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 dark:text-white">{percentage.toFixed(1)}%</div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      
      {tasksData.length === 0 && (
        <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-md mt-4">
          <p className="text-gray-500 dark:text-gray-400">No tasks data available.</p>
        </div>
      )}
    </div>
  );
}
