import React from 'react';
import { Node, Edge } from 'reactflow';

interface NodeDetailsPanelProps {
  node: Node;
  onClose?: () => void;
  connections?: {
    incoming: Edge[];
    outgoing: Edge[];
  };
  nodeMap?: {[key: string]: Node};
}

export default function NodeDetailsPanel({ node, onClose, connections, nodeMap }: NodeDetailsPanelProps) {
  const { label, explanation, runtime } = node.data;
  
  // Get incoming and outgoing connections
  const incoming = connections?.incoming || [];
  const outgoing = connections?.outgoing || [];
  
  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-blue-50 dark:bg-blue-900/20">
        <h3 className="font-semibold text-lg text-gray-900 dark:text-white">Node Details</h3>
      </div>
      
      <div className="p-4 overflow-y-auto flex-grow">
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Node Name</h4>
          </div>
          <p className="text-base font-semibold text-gray-900 dark:text-white ml-5">{label}</p>
        </div>
        
        {runtime > 0 && (
          <div className="mb-6">
            <div className="flex items-center mb-2">
              <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Execution Time</h4>
            </div>
            <div className="flex items-center ml-5">
              <div className="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200 px-2 py-1 rounded text-sm font-medium">
                {runtime.toFixed(2)}s
              </div>
            </div>
          </div>
        )}
        
        {explanation && (
          <div className="mb-6">
            <div className="flex items-center mb-2">
              <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
              <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Description</h4>
            </div>
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-md text-sm text-gray-900 dark:text-white border border-gray-200 dark:border-gray-600 ml-5">
              {explanation}
            </div>
          </div>
        )}
        
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Connections</h4>
          </div>
          <div className="ml-5 space-y-3">
            {incoming.length === 0 && outgoing.length === 0 ? (
              <div className="bg-orange-50 dark:bg-orange-900/20 p-3 rounded-md border border-orange-100 dark:border-orange-800">
                <p className="text-sm text-gray-700 dark:text-gray-300">This node has no connections to other nodes.</p>
              </div>
            ) : (
              <>
                {incoming.length > 0 && (
                  <div>
                    <h5 className="text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">Incoming Connections:</h5>
                    <div className="space-y-2">
                      {incoming.map(edge => {
                        const sourceNode = nodeMap?.[edge.source];
                        const sourceLabel = sourceNode?.data?.label || 'Unknown';
                        return (
                          <div key={edge.id} className="bg-green-50 dark:bg-green-900/20 p-2 rounded-md border border-green-100 dark:border-green-800">
                            <p className="text-sm text-green-700 dark:text-green-300">
                              <span className="font-medium">{sourceLabel}</span> → {label}
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">ID: {edge.source}</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
                
                {outgoing.length > 0 && (
                  <div>
                    <h5 className="text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">Outgoing Connections:</h5>
                    <div className="space-y-2">
                      {outgoing.map(edge => {
                        const targetNode = nodeMap?.[edge.target];
                        const targetLabel = targetNode?.data?.label || 'Unknown';
                        return (
                          <div key={edge.id} className="bg-blue-50 dark:bg-blue-900/20 p-2 rounded-md border border-blue-100 dark:border-blue-800">
                            <p className="text-sm text-blue-700 dark:text-blue-300">
                              {label} → <span className="font-medium">{targetLabel}</span>
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">ID: {edge.target}</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
                
                <p className="text-xs text-gray-500 dark:text-gray-400 italic">
                  Click on any connection line to see more details.
                </p>
              </>
            )}
          </div>
        </div>
      </div>
      
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
        <p className="text-xs text-gray-500 dark:text-gray-400">Node ID: {node.id}</p>
      </div>
    </div>
  );
}
