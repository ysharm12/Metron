import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';

interface BlueprintNodeData {
  label: string;
  explanation: string;
  runtime: number;
  type?: string;
}

function BlueprintNode({ data, selected }: NodeProps<BlueprintNodeData>) {
  // Determine node color based on type or default to blue
  const getNodeColor = () => {
    const type = data.type?.toLowerCase() || '';
    if (type.includes('specialist')) return 'purple';
    if (type.includes('analyzer') || type.includes('analysis')) return 'green';
    if (type.includes('generator') || type.includes('writer')) return 'orange';
    if (type.includes('orchestrator')) return 'red';
    return 'blue';
  };
  
  const color = getNodeColor();
  const colorMap = {
    blue: {
      bg: selected ? 'bg-blue-100 dark:bg-blue-900/70' : 'bg-blue-50 dark:bg-blue-900/40',
      border: selected ? 'border-blue-500' : 'border-blue-300 dark:border-blue-700',
      header: 'bg-blue-100 dark:bg-blue-800 border-blue-200 dark:border-blue-600 text-blue-700 dark:text-blue-300',
      handle: 'bg-blue-500'
    },
    purple: {
      bg: selected ? 'bg-purple-100 dark:bg-purple-900/70' : 'bg-purple-50 dark:bg-purple-900/40',
      border: selected ? 'border-purple-500' : 'border-purple-300 dark:border-purple-700',
      header: 'bg-purple-100 dark:bg-purple-800 border-purple-200 dark:border-purple-600 text-purple-700 dark:text-purple-300',
      handle: 'bg-purple-500'
    },
    green: {
      bg: selected ? 'bg-green-100 dark:bg-green-900/70' : 'bg-green-50 dark:bg-green-900/40',
      border: selected ? 'border-green-500' : 'border-green-300 dark:border-green-700',
      header: 'bg-green-100 dark:bg-green-800 border-green-200 dark:border-green-600 text-green-700 dark:text-green-300',
      handle: 'bg-green-500'
    },
    orange: {
      bg: selected ? 'bg-orange-100 dark:bg-orange-900/70' : 'bg-orange-50 dark:bg-orange-900/40',
      border: selected ? 'border-orange-500' : 'border-orange-300 dark:border-orange-700',
      header: 'bg-orange-100 dark:bg-orange-800 border-orange-200 dark:border-orange-600 text-orange-700 dark:text-orange-300',
      handle: 'bg-orange-500'
    },
    red: {
      bg: selected ? 'bg-red-100 dark:bg-red-900/70' : 'bg-red-50 dark:bg-red-900/40',
      border: selected ? 'border-red-500' : 'border-red-300 dark:border-red-700',
      header: 'bg-red-100 dark:bg-red-800 border-red-200 dark:border-red-600 text-red-700 dark:text-red-300',
      handle: 'bg-red-500'
    }
  };
  
  const styles = colorMap[color as keyof typeof colorMap];

  return (
    <div 
      className={`px-4 py-3 rounded-md shadow-md min-w-[200px] max-w-[280px] transition-all duration-200 ${styles.bg} ${selected ? 'border-2' : 'border'} ${styles.border}`}
    >
      <Handle
        type="target"
        position={Position.Top}
        className={`w-3 h-3 ${styles.handle}`}
      />
      
      <div className="text-center">
        <div className={`font-bold text-sm mb-2 px-2 py-1 rounded border-b ${styles.header}`}>
          {data.label}
        </div>
        
        {data.runtime > 0 && (
          <div className="flex justify-center items-center text-xs text-gray-600 dark:text-gray-300 mb-1 px-2 py-1 rounded-sm">
            <svg className="w-4 h-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
            <span>{data.runtime.toFixed(2)}s</span>
          </div>
        )}
      </div>
      
      <Handle
        type="source"
        position={Position.Bottom}
        className={`w-3 h-3 ${styles.handle}`}
      />
    </div>
  );
}

export default memo(BlueprintNode);
