"use client"
import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactFlow, { 
  Background, 
  Controls, 
  MiniMap, 
  Node, 
  Edge, 
  NodeTypes, 
  useNodesState, 
  useEdgesState,
  addEdge,
  Connection,
  MarkerType,
  EdgeChange,
  NodeChange
} from 'reactflow';
import 'reactflow/dist/style.css';
import BlueprintNode from './BlueprintNode';
import NodeDetailsPanel from './NodeDetailsPanel';
import EdgeDetailsPanel from './EdgeDetailsPanel';

// Define custom node types
const nodeTypes: NodeTypes = {
  blueprintNode: BlueprintNode,
};

interface BlueprintData {
  nodes: {
    id: string;
    name: string;
    explanation?: string;
    runtime?: number;
  }[];
  connections: {
    from: string;
    to: string;
  }[];
}

interface BlueprintEditorProps {
  blueprintName?: string;
  showDetailsPanel?: boolean;
}

export default function BlueprintEditor({ blueprintName, showDetailsPanel = false }: BlueprintEditorProps) {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [selectedEdge, setSelectedEdge] = useState<Edge | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [nodeMap, setNodeMap] = useState<{[key: string]: Node}>({});
  const reactFlowWrapper = useRef<HTMLDivElement>(null);

  // Dummy data based on process_diagram.json
  const dummyData: BlueprintData = {
    nodes: [
      {
        id: "b61c2488-defe-430a-a99e-18ed6919617e",
        name: "Parent_Orchestrator",
        explanation: "I will now begin the strategy process",
        runtime: 3.99974
      },
      {
        id: "49c10f8b-908c-4577-aa0c-315170ac20c8",
        name: "Trigger_Specialist",
        explanation: "Updating Trigger with new campaign",
        runtime: 0.00059
      },
      {
        id: "4b7d76ce-a1eb-4c19-8186-5a3b7dae2e7b",
        name: "Ephermal_Customer_Specialist",
        explanation: "I have chosen to apply KMeans clustering on standardized customer features (age, num_purchases, total_spent) to partition customers into 3 clusters, revealing distinct segmentation characteristics.",
        runtime: 4.86123
      },
      {
        id: "27d846ef-04a6-4d2b-8ba6-161c290530a0",
        name: "Ephermal_Historical_Campaign_Specialist",
        explanation: "I have looked at the data, ill go with applying XGBoost with top features, thereby analysing the historical campaign data.",
        runtime: 3.51213
      },
      {
        id: "84d355c6-1ba1-4567-a110-cff4a0f61a5d",
        name: "Ephermal_Sentiment_Specialist",
        explanation: "I have chosen to apply a sentiment analysis model to understand the sentiment behind customer reviews, gaining insights into customer opinions and preferences.",
        runtime: 3.5247
      }
    ],
    connections: [
      {
        from: "b61c2488-defe-430a-a99e-18ed6919617e",
        to: "49c10f8b-908c-4577-aa0c-315170ac20c8"
      },
      {
        from: "b61c2488-defe-430a-a99e-18ed6919617e",
        to: "4b7d76ce-a1eb-4c19-8186-5a3b7dae2e7b"
      },
      {
        from: "b61c2488-defe-430a-a99e-18ed6919617e",
        to: "27d846ef-04a6-4d2b-8ba6-161c290530a0"
      },
      {
        from: "4b7d76ce-a1eb-4c19-8186-5a3b7dae2e7b",
        to: "27d846ef-04a6-4d2b-8ba6-161c290530a0"
      },
      {
        from: "b61c2488-defe-430a-a99e-18ed6919617e",
        to: "84d355c6-1ba1-4567-a110-cff4a0f61a5d"
      },
      {
        from: "4b7d76ce-a1eb-4c19-8186-5a3b7dae2e7b",
        to: "84d355c6-1ba1-4567-a110-cff4a0f61a5d"
      },
      {
        from: "27d846ef-04a6-4d2b-8ba6-161c290530a0",
        to: "84d355c6-1ba1-4567-a110-cff4a0f61a5d"
      }
    ]
  };
  
  // Load blueprint data
  useEffect(() => {
    const loadBlueprintData = async () => {
      try {
        setIsLoading(true);
        
        // Fetch data from the API endpoint
        const response = await fetch('/api/blueprints/process-diagram');
        const data = await response.json();
        
        // Transform nodes to ReactFlow format
        const flowNodes = data.nodes.map((node) => ({
          id: node.id,
          type: 'blueprintNode',
          position: { x: 0, y: 0 }, // Will be positioned by layout algorithm
          data: {
            label: node.name.replace(/_/g, ' '),
            explanation: node.explanation || '',
            runtime: node.runtime || 0,
            type: node.name, // Use the node name to determine the type for styling
          },
        }));
        
        // Create a map of nodes by ID for quick lookup
        const nodesById: {[key: string]: Node} = {};
        flowNodes.forEach(node => {
          nodesById[node.id] = node;
        });
        setNodeMap(nodesById);
        
        // Transform connections to ReactFlow edges
        const flowEdges = data.connections ? data.connections.map((connection, index) => {
          // Get source and target node names for the edge data
          const sourceName = data.nodes.find(n => n.id === connection.from)?.name || 'Unknown';
          const targetName = data.nodes.find(n => n.id === connection.to)?.name || 'Unknown';
          
          return {
            id: `edge-${index}`,
            source: connection.from,
            target: connection.to,
            type: 'smoothstep',
            animated: true,
            style: { stroke: '#3b82f6', strokeWidth: 2 },
            markerEnd: {
              type: MarkerType.ArrowClosed,
              color: '#3b82f6',
            },
            data: {
              sourceId: connection.from,
              targetId: connection.to,
              sourceName: sourceName.replace(/_/g, ' '),
              targetName: targetName.replace(/_/g, ' '),
            },
          };
        }) : [];
        
        // Apply automatic layout
        const positionedNodes = applyForceDirectedLayout(flowNodes, flowEdges);
        
        setNodes(positionedNodes);
        setEdges(flowEdges);
        
        // Clear selections when data is refreshed
        if (selectedEdge) {
          const edgeStillExists = flowEdges.some(e => e.id === selectedEdge.id);
          if (!edgeStillExists) {
            setSelectedEdge(null);
          }
        }
        
        if (selectedNode) {
          const nodeStillExists = flowNodes.some(n => n.id === selectedNode.id);
          if (!nodeStillExists) {
            setSelectedNode(null);
          }
        }
      } catch (error) {
        console.error('Error loading blueprint data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    // Initial load
    loadBlueprintData();
    
    // Set up polling to refresh the data every 5 seconds
    const intervalId = setInterval(() => {
      loadBlueprintData();
    }, 5000);
    
    // Clean up the interval when the component unmounts
    return () => clearInterval(intervalId);
  }, [selectedNode, selectedEdge]);
  
  // Simple force-directed layout algorithm
  const applyForceDirectedLayout = (nodes: Node[], edges: Edge[]) => {
    // This is a simplified version - in a real app, you'd use a proper layout library
    const centerX = 500;
    const centerY = 300;
    const radius = 400;
    
    // Position nodes in a circle initially
    return nodes.map((node, index) => {
      const angle = (index * 2 * Math.PI) / nodes.length;
      return {
        ...node,
        position: {
          x: centerX + radius * Math.cos(angle),
          y: centerY + radius * Math.sin(angle),
        },
      };
    });
  };

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const onNodeClick = (_: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
    setSelectedEdge(null); // Clear edge selection when a node is clicked
  };
  
  const onEdgeClick = (_: React.MouseEvent, edge: Edge) => {
    setSelectedEdge(edge);
    setSelectedNode(null); // Clear node selection when an edge is clicked
  };
  
  // Find incoming and outgoing connections for a node
  const getNodeConnections = (nodeId: string) => {
    const incoming = edges.filter(edge => edge.target === nodeId);
    const outgoing = edges.filter(edge => edge.source === nodeId);
    
    return { incoming, outgoing };
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-200px)] border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
      {blueprintName && (
        <div className="bg-blue-50 dark:bg-blue-900/30 px-4 py-2 text-sm text-blue-800 dark:text-blue-200 border-b border-blue-200 dark:border-blue-800">
          Viewing: <span className="font-semibold">{blueprintName}</span>
        </div>
      )}
      <div className="flex flex-grow h-full">
        <div ref={reactFlowWrapper} className="flex-grow h-full">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onNodeClick={onNodeClick}
            onEdgeClick={onEdgeClick}
            nodeTypes={nodeTypes}
            fitView
            fitViewOptions={{ padding: 0.2 }}
            defaultEdgeOptions={{
              animated: true,
              style: { stroke: '#3b82f6', strokeWidth: 2 },
              markerEnd: {
                type: MarkerType.ArrowClosed,
                color: '#3b82f6',
              },
            }}
            attributionPosition="bottom-right"
          >
            <Background color="#aaa" gap={16} variant="dots" />
            <Controls />
            <MiniMap 
              nodeStrokeColor={(n) => {
                return n.selected ? '#3b82f6' : '#555';
              }}
              nodeColor={(n) => {
                return n.selected ? '#3b82f6' : '#fff';
              }}
              maskColor="rgba(0, 0, 0, 0.1)"
              className="bg-blue-50 dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700"
            />
          </ReactFlow>
        </div>
        
        {/* Always show the details panel */}
        <div className="w-80 border-l border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 overflow-y-auto">
          {selectedNode ? (
            <NodeDetailsPanel 
              node={selectedNode} 
              onClose={() => setSelectedNode(null)}
              connections={getNodeConnections(selectedNode.id)}
              nodeMap={nodeMap}
            />
          ) : selectedEdge ? (
            <EdgeDetailsPanel 
              edge={selectedEdge} 
              onClose={() => setSelectedEdge(null)}
              nodeMap={nodeMap}
            />
          ) : (
            <div className="p-4 text-center text-gray-500 dark:text-gray-400 h-full flex flex-col items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mb-3 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p className="mb-1 font-medium">No Element Selected</p>
              <p className="text-sm">Click on a node or connection to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
