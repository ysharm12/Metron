import React from 'react';
import { Edge, Node } from 'reactflow';

interface EdgeDetailsPanelProps {
  edge: Edge;
  onClose?: () => void;
  nodeMap: {[key: string]: Node};
}

export default function EdgeDetailsPanel({ edge, onClose, nodeMap }: EdgeDetailsPanelProps) {
  const sourceId = edge.source;
  const targetId = edge.target;
  
  // Get source and target node data
  const sourceNode = nodeMap[sourceId];
  const targetNode = nodeMap[targetId];
  
  const sourceLabel = sourceNode?.data?.label || 'Unknown Source';
  const targetLabel = targetNode?.data?.label || 'Unknown Target';
  
  // Get edge data if available
  const edgeData = edge.data || {
    sourceName: sourceLabel,
    targetName: targetLabel
  };
  
  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 bg-blue-50 dark:bg-blue-900/20">
        <h3 className="font-semibold text-lg text-gray-900 dark:text-white">Connection Details</h3>
      </div>
      
      <div className="p-4 overflow-y-auto flex-grow">
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Connection Type</h4>
          </div>
          <div className="ml-5 bg-blue-50 dark:bg-blue-900/20 p-3 rounded-md border border-blue-100 dark:border-blue-800">
            <p className="text-sm font-medium text-blue-700 dark:text-blue-300">Data Flow</p>
          </div>
        </div>
        
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Source Node</h4>
          </div>
          <div className="ml-5 p-3 bg-green-50 dark:bg-green-900/20 rounded-md border border-green-100 dark:border-green-800">
            <p className="text-sm font-medium text-green-700 dark:text-green-300">{sourceLabel}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">ID: {sourceId}</p>
          </div>
        </div>
        
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Target Node</h4>
          </div>
          <div className="ml-5 p-3 bg-purple-50 dark:bg-purple-900/20 rounded-md border border-purple-100 dark:border-purple-800">
            <p className="text-sm font-medium text-purple-700 dark:text-purple-300">{targetLabel}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">ID: {targetId}</p>
          </div>
        </div>
        
        <div className="mb-6">
          <div className="flex items-center mb-2">
            <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
            <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Data Flow</h4>
          </div>
          <div className="ml-5">
            <div className="flex items-center space-x-2 mb-2">
              <div className="flex-1 p-2 bg-orange-50 dark:bg-orange-900/20 rounded-md border border-orange-100 dark:border-orange-800 text-center">
                <p className="text-sm font-medium text-orange-700 dark:text-orange-300">{sourceLabel}</p>
              </div>
              <div className="flex-shrink-0">
                <svg className="w-6 h-6 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </div>
              <div className="flex-1 p-2 bg-orange-50 dark:bg-orange-900/20 rounded-md border border-orange-100 dark:border-orange-800 text-center">
                <p className="text-sm font-medium text-orange-700 dark:text-orange-300">{targetLabel}</p>
              </div>
            </div>
            <p className="text-xs text-center text-gray-500 dark:text-gray-400">
              Data flows from source to target
            </p>
          </div>
        </div>
      </div>
      
      <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
        <p className="text-xs text-gray-500 dark:text-gray-400">Connection ID: {edge.id}</p>
      </div>
    </div>
  );
}
