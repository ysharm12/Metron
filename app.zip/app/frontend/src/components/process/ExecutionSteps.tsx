"use client";
import { useState, useEffect } from 'react';

interface Step {
  name: string;
  description: string;
  code: string;
  imports: string[];
}

export default function ExecutionSteps() {
  const [steps, setSteps] = useState<Step[]>([
    {
      name: "Main Trigger",
      description: "Initiates the marketing automation process by setting up the campaign trigger with basic information like campaign name, goal, audience, and budget.",
      code: "initiate_s1_main_trigger(dummy_data)",
      imports: ["from s1_main_trigger import initiate_s1_main_trigger"]
    },
    {
      name: "Strategy Generation",
      description: "Analyzes campaign data and generates a comprehensive multi-channel marketing strategy based on customer segmentation, historical campaigns, and sentiment analysis.",
      code: "generate_strategy_report()",
      imports: ["from s2_1_strategy import generate_strategy_report"]
    },
    {
      name: "Content Creation",
      description: "Creates tailored content for each marketing channel (LinkedIn, Twitter, Instagram, SMS, Direct Mail) based on the approved strategy.",
      code: "create_content_writeup()",
      imports: ["from s3_1_content_writeup import create_content_writeup"]
    },
    {
      name: "Banner Generation",
      description: "Generates visual banners for each channel using the content specifications and design guidelines from the content writeup.",
      code: "start_banner_creation()",
      imports: ["from s4_1_banner_creation import start_banner_creation"]
    }
  ]);

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold mb-6">Execution Steps</h2>
      <div className="space-y-6">
        {steps.map((step, index) => (
          <div key={index} className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
            <div className="flex items-center mb-4">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-100 text-blue-600 font-bold mr-4">
                {index + 1}
              </div>
              <h3 className="text-xl font-semibold">{step.name}</h3>
            </div>
            
            <p className="text-gray-700 mb-4">{step.description}</p>
            
            <div className="mb-4">
              <h4 className="text-sm font-medium text-gray-500 mb-2">Imports:</h4>
              <div className="bg-gray-50 p-3 rounded-md">
                <pre className="text-sm text-gray-800 whitespace-pre-wrap">
                  {step.imports.join('\n')}
                </pre>
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Execution:</h4>
              <div className="bg-gray-50 p-3 rounded-md">
                <pre className="text-sm text-gray-800">{step.code}</pre>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
