"use client";
import { useEffect, useState, useRef } from 'react';
import * as d3 from 'd3';

interface Node {
  id: string;
  name: string;
  explanation?: string;
  runtime?: number;
  // D3 force simulation adds these properties
  x?: number;
  y?: number;
  fx?: number | null;
  fy?: number | null;
}

interface Connection {
  from: string;
  to: string;
  // D3 force simulation transforms these into source/target
  source?: string | Node;
  target?: string | Node;
}

interface ProcessDiagram {
  nodes: Node[];
  connections: Connection[];
}

export default function ProcessFlowDiagram() {
  const [data, setData] = useState<ProcessDiagram | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const simulationRef = useRef<d3.Simulation<Node, undefined> | null>(null);

  // Sample fallback data in case the API fails
  const fallbackData: ProcessDiagram = {
    nodes: [
      { id: "parent", name: "Parent_Orchestrator", explanation: "Coordinates the entire process", runtime: 3.5 },
      { id: "trigger", name: "Trigger_Specialist", explanation: "Handles campaign trigger data", runtime: 1.2 },
      { id: "strategy", name: "Ephermal_Strategy_Specialist", explanation: "Develops marketing strategy", runtime: 5.1 },
      { id: "content", name: "Ephermal_Content_Writer", explanation: "Creates content for each channel", runtime: 4.3 },
      { id: "banner", name: "Ephermal_Banner_Generator_Specialist", explanation: "Creates visual banners", runtime: 6.7 }
    ],
    connections: [
      { from: "parent", to: "trigger" },
      { from: "parent", to: "strategy" },
      { from: "trigger", to: "strategy" },
      { from: "strategy", to: "content" },
      { from: "content", to: "banner" }
    ]
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        console.log('Fetching process data from API...');
        const response = await fetch('/api/process');
        
        if (!response.ok) {
          const errorData = await response.json();
          console.error('API error:', errorData);
          throw new Error(`Failed to fetch process data: ${response.status} ${response.statusText}`);
        }
        
        const processData = await response.json();
        console.log('Successfully fetched process data');
        setData(processData);
      } catch (err) {
        console.error('Error loading process diagram data:', err);
        // Use fallback data instead of showing an error
        console.log('Using fallback data instead');
        setData(fallbackData);
        setError(`Error: ${err instanceof Error ? err.message : String(err)}. Using sample data instead.`);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    // Cleanup function to stop any existing simulation
    return () => {
      if (simulationRef.current) {
        simulationRef.current.stop();
      }
    };
  }, []);

  useEffect(() => {
    if (!data || !svgRef.current) return;
    
    try {
      // Stop any existing simulation
      if (simulationRef.current) {
        simulationRef.current.stop();
        simulationRef.current = null;
      }
      
      console.log('Rendering diagram with data:', data);
      
      // Validate data structure
      if (!Array.isArray(data.nodes) || !Array.isArray(data.connections)) {
        console.error('Invalid data format:', data);
        setError('Invalid data format. Missing nodes or connections arrays.');
        return;
      }
      
      // Ensure all nodes have IDs
      const validNodes = data.nodes.filter(node => node && typeof node.id === 'string');
      if (validNodes.length !== data.nodes.length) {
        console.warn(`Found ${data.nodes.length - validNodes.length} nodes without valid IDs. These will be filtered out.`);
      }
      
      if (validNodes.length === 0) {
        console.error('No valid nodes found in data');
        setError('No valid nodes found in the process diagram data.');
        return;
      }
      
      // Create a map of node IDs to node objects for quick lookup
      const nodeMap = new Map<string, Node>();
      validNodes.forEach(node => nodeMap.set(node.id, node));
      
      // Ensure all connections reference valid nodes
      const validConnections = data.connections
        .filter(conn => conn && typeof conn.from === 'string' && typeof conn.to === 'string')
        .filter(conn => nodeMap.has(conn.from) && nodeMap.has(conn.to))
        .map(conn => ({
          ...conn,
          source: conn.from,
          target: conn.to
        }));
      
      if (validConnections.length !== data.connections.length) {
        console.warn(`Found ${data.connections.length - validConnections.length} invalid connections. These will be filtered out.`);
      }
      
      // Clear previous diagram
      const svg = d3.select(svgRef.current);
      svg.selectAll('*').remove();

      // Get the actual container dimensions
      const containerWidth = svgRef.current.clientWidth || 1000;
      const containerHeight = 600; // Fixed height to ensure it stays within the container
      const width = containerWidth;
      const height = containerHeight;
      const nodeRadius = 25; // Slightly smaller nodes
      const nodeColor = "#3b82f6"; // Blue color
      const nodeColorHighlight = "#2563eb"; // Darker blue for hover
      const linkColor = "#94a3b8"; // Gray color

      // Create SVG with responsive dimensions
      svg
        .attr('width', '100%')
        .attr('height', height)
        .attr('viewBox', [0, 0, width, height])
        .attr('style', 'max-width: 100%; height: auto; font: 12px sans-serif; border: 1px solid #e5e7eb; border-radius: 8px;');

      // Create tooltip
      const tooltip = d3.select(tooltipRef.current)
        .style('position', 'absolute')
        .style('visibility', 'hidden')
        .style('background-color', 'white')
        .style('border', '1px solid #ddd')
        .style('border-radius', '4px')
        .style('padding', '10px')
        .style('box-shadow', '0 4px 6px rgba(0, 0, 0, 0.1)')
        .style('z-index', '10');

      // Define arrow marker
      svg.append('defs').append('marker')
        .attr('id', 'arrowhead')
        .attr('viewBox', '0 -5 10 10')
        .attr('refX', nodeRadius + 10)
        .attr('refY', 0)
        .attr('orient', 'auto')
        .attr('markerWidth', 6)
        .attr('markerHeight', 6)
        .append('path')
        .attr('d', 'M0,-5L10,0L0,5')
        .attr('fill', linkColor);
        
      // Create links group
      const linkGroup = svg.append('g');
      
      // Create links
      const link = linkGroup
        .selectAll('line')
        .data(validConnections)
        .join('line')
        .attr('stroke', linkColor)
        .attr('stroke-width', 2)
        .attr('marker-end', 'url(#arrowhead)');

      // Create node group
      const nodeGroup = svg.append('g');
      
      // Create node groups
      const node = nodeGroup
        .selectAll('g')
        .data(validNodes)
        .join('g')
        .call(d3.drag<SVGGElement, Node>()
          .on('start', dragstarted)
          .on('drag', dragged)
          .on('end', dragended));

      // Add circles to nodes
      node.append('circle')
        .attr('r', nodeRadius)
        .attr('fill', nodeColor)
        .attr('stroke', '#fff')
        .attr('stroke-width', 2)
        .on('mouseover', function(event, d) {
          d3.select(this).attr('fill', nodeColorHighlight);
          tooltip
            .style('visibility', 'visible')
            .html(`
              <div class="font-semibold">${d.name}</div>
              ${d.explanation ? `<div class="text-sm mt-1">${d.explanation}</div>` : ''}
              ${d.runtime ? `<div class="text-xs mt-2">Runtime: ${d.runtime.toFixed(2)}s</div>` : ''}
            `);
        })
        .on('mousemove', function(event) {
          tooltip
            .style('top', (event.pageY - 10) + 'px')
            .style('left', (event.pageX + 10) + 'px');
        })
        .on('mouseout', function() {
          d3.select(this).attr('fill', nodeColor);
          tooltip.style('visibility', 'hidden');
        });

      // Add labels to nodes with full names and better visibility
      node.append('text')
        .attr('dy', nodeRadius + 20)
        .attr('text-anchor', 'middle')
        .attr('fill', '#4b5563')
        .attr('font-size', '12px')
        .attr('font-weight', '500')
        .text(d => d.name) // Use full name
        .style('pointer-events', 'none')
        .each(function(d) {
          // Check if text is too long and truncate if needed
          const textElement = d3.select(this);
          const textLength = (textElement.node() as SVGTextElement).getComputedTextLength();
          const maxLength = nodeRadius * 4;
          
          if (textLength > maxLength) {
            let text = d.name;
            while (text.length > 3 && (textElement.node() as SVGTextElement).getComputedTextLength() > maxLength) {
              text = text.slice(0, -1);
              textElement.text(text + '...');
            }
          }
        });

      // Set initial positions for nodes in a more structured layout
      // This helps the force simulation start from a better position
      const setInitialPositions = () => {
        // Create a map to track incoming connections for each node
        const incomingConnections = new Map<string, number>();
        validNodes.forEach(node => incomingConnections.set(node.id, 0));
        
        // Count incoming connections for each node
        validConnections.forEach(conn => {
          const targetId = typeof conn.target === 'string' ? conn.target : conn.target?.id;
          if (targetId && incomingConnections.has(targetId)) {
            incomingConnections.set(targetId, incomingConnections.get(targetId)! + 1);
          }
        });
        
        // Find root nodes (nodes with no incoming connections)
        const rootNodes = validNodes.filter(node => incomingConnections.get(node.id) === 0);
        
        // If no root nodes, just use the first node
        if (rootNodes.length === 0 && validNodes.length > 0) {
          rootNodes.push(validNodes[0]);
        }
        
        // Position nodes in layers based on their distance from root nodes
        const visited = new Set<string>();
        const nodeDistances = new Map<string, number>();
        
        // BFS to determine node distances from root
        const queue: {node: Node, distance: number}[] = [];
        rootNodes.forEach(node => {
          queue.push({node, distance: 0});
          visited.add(node.id);
          nodeDistances.set(node.id, 0);
        });
        
        while (queue.length > 0) {
          const {node, distance} = queue.shift()!;
          
          // Find all connections from this node
          const outgoingConnections = validConnections.filter(conn => {
            const sourceId = typeof conn.source === 'string' ? conn.source : conn.source?.id;
            return sourceId === node.id;
          });
          
          // Process each connected node
          outgoingConnections.forEach(conn => {
            const targetId = typeof conn.target === 'string' ? conn.target : conn.target?.id;
            if (targetId && !visited.has(targetId)) {
              const targetNode = validNodes.find(n => n.id === targetId);
              if (targetNode) {
                visited.add(targetId);
                nodeDistances.set(targetId, distance + 1);
                queue.push({node: targetNode, distance: distance + 1});
              }
            }
          });
        }
        
        // Count nodes at each distance level
        const nodesAtDistance = new Map<number, number>();
        nodeDistances.forEach((distance) => {
          nodesAtDistance.set(distance, (nodesAtDistance.get(distance) || 0) + 1);
        });
        
        // Position nodes based on their distance
        const maxDistance = Math.max(...Array.from(nodeDistances.values(), d => d || 0));
        const layerHeight = height / (maxDistance + 1);
        
        // Track how many nodes we've placed at each distance
        const placedAtDistance = new Map<number, number>();
        
        validNodes.forEach(node => {
          const distance = nodeDistances.get(node.id) || 0;
          const nodesInLayer = nodesAtDistance.get(distance) || 1;
          const placed = placedAtDistance.get(distance) || 0;
          
          // Calculate position
          const layerY = layerHeight * distance + layerHeight / 2;
          const layerWidth = width * 0.8; // Use 80% of width to leave margins
          const nodeSpacing = layerWidth / nodesInLayer;
          const layerX = width * 0.1 + nodeSpacing * (placed + 0.5); // 10% margin on each side
          
          // Set initial position
          node.x = layerX;
          node.y = layerY;
          
          // Update placed count
          placedAtDistance.set(distance, placed + 1);
        });
      };
      
      // Apply initial positions
      setInitialPositions();
      
      // Create and store the simulation with improved forces for better positioning
      const simulation = d3.forceSimulation<Node>(validNodes)
        .force('link', d3.forceLink<Node, Connection>(validConnections)
          .id(d => d.id)
          .distance(120)) // Slightly shorter distance between nodes
        .force('charge', d3.forceManyBody().strength(-300)) // Less repulsion
        .force('center', d3.forceCenter(width / 2, height / 2).strength(0.05)) // Weak centering force
        .force('collision', d3.forceCollide().radius(nodeRadius * 1.5)) // Prevent overlap
        .force('x', d3.forceX(width / 2).strength(0.05)) // Weak horizontal centering
        .force('y', d3.forceY().y((d) => {
          // Try to maintain the y-position from our initial layout
          return d.y || height / 2;
        }).strength(0.2)); // Stronger vertical positioning

      // Store the simulation in the ref
      simulationRef.current = simulation;

      // Update positions on simulation tick with boundary constraints
      simulation.on('tick', () => {
        // Constrain nodes to stay within the container boundaries
        validNodes.forEach(d => {
          d.x = Math.max(nodeRadius, Math.min(width - nodeRadius, d.x || width / 2));
          d.y = Math.max(nodeRadius, Math.min(height - nodeRadius, d.y || height / 2));
        });
        
        // Safely update link positions
        link
          .attr('x1', d => {
            const source = d.source as Node;
            return source.x || width / 2;
          })
          .attr('y1', d => {
            const source = d.source as Node;
            return source.y || height / 2;
          })
          .attr('x2', d => {
            const target = d.target as Node;
            return target.x || width / 2;
          })
          .attr('y2', d => {
            const target = d.target as Node;
            return target.y || height / 2;
          });

        // Safely update node positions
        node.attr('transform', d => `translate(${d.x || width/2},${d.y || height/2})`);
      });

      // Drag functions
      function dragstarted(event: d3.D3DragEvent<SVGGElement, Node, Node>) {
        if (!event.active && simulation) simulation.alphaTarget(0.3).restart();
        event.subject.fx = event.subject.x;
        event.subject.fy = event.subject.y;
      }

      function dragged(event: d3.D3DragEvent<SVGGElement, Node, Node>) {
        event.subject.fx = event.x;
        event.subject.fy = event.y;
      }

      function dragended(event: d3.D3DragEvent<SVGGElement, Node, Node>) {
        if (!event.active && simulation) simulation.alphaTarget(0);
        event.subject.fx = null;
        event.subject.fy = null;
      }
    } catch (err) {
      console.error('Error rendering diagram:', err);
      setError(`Error rendering diagram: ${err instanceof Error ? err.message : String(err)}`);
    }

  }, [data]);

  if (loading) {
    return <div className="flex justify-center items-center h-64">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
    </div>;
  }

  if (error) {
    return <div className="text-red-500 text-center">{error}</div>;
  }

  return (
    <div className="relative overflow-hidden">
      <svg ref={svgRef} className="w-full border border-gray-200 rounded-lg"></svg>
      <div ref={tooltipRef}></div>
    </div>
  );
}
