"use client";
import { useState, useEffect } from 'react';

interface Agent {
  name: string;
  role: string;
  description: string;
}

export default function AgentExplanation() {
  const [agents, setAgents] = useState<Agent[]>([
    {
      name: "Parent_Orchestrator",
      role: "Main Coordinator",
      description: "Coordinates the entire marketing automation process, assigns tasks to specialized agents, and ensures proper workflow execution."
    },
    {
      name: "Trigger_Specialist",
      role: "Campaign Initialization",
      description: "Handles the campaign trigger data, ensuring it's properly formatted and stored for use by other agents."
    },
    {
      name: "Ephermal_Customer_Specialist",
      role: "Customer Analysis",
      description: "Analyzes customer data using clustering techniques to identify distinct customer segments and their characteristics."
    },
    {
      name: "Ephermal_Historical_Campaign_Specialist",
      role: "Campaign Analysis",
      description: "Analyzes historical campaign data to identify patterns and successful strategies that can be applied to the current campaign."
    },
    {
      name: "Ephermal_Sentiment_Specialist",
      role: "Sentiment Analysis",
      description: "Analyzes customer sentiment data to understand opinions and preferences, helping to shape the marketing message."
    },
    {
      name: "Ephermal_KPI_Specialist",
      role: "Performance Metrics",
      description: "Defines and analyzes Key Performance Indicators (KPIs) to set boundaries and goals for the campaign."
    },
    {
      name: "Ephermal_Competitor_Specialist",
      role: "Competitive Analysis",
      description: "Analyzes competitor data to identify market trends and competitive opportunities for the campaign."
    },
    {
      name: "Ephermal_Strategy_Specialist",
      role: "Strategy Development",
      description: "Develops the comprehensive marketing strategy based on all collected data and analyses."
    },
    {
      name: "Ephermal_Content_Writer",
      role: "Content Creation",
      description: "Creates tailored content for each marketing channel based on the approved strategy."
    },
    {
      name: "Ephermal_Banner_Generator_Specialist",
      role: "Visual Design",
      description: "Creates visual banners for each channel according to the content specifications and design guidelines."
    }
  ]);

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold mb-6">Agents & Their Roles</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {agents.map((agent, index) => (
          <div key={index} className="bg-white p-5 rounded-lg shadow-md border border-gray-200 hover:shadow-lg transition-shadow">
            <div className="flex items-center mb-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                </svg>
              </div>
              <h3 className="text-lg font-semibold">{agent.name.replace(/_/g, ' ')}</h3>
            </div>
            <div className="ml-13">
              <div className="text-sm font-medium text-blue-600 mb-2">{agent.role}</div>
              <p className="text-gray-600 text-sm">{agent.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
