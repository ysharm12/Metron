import React from 'react';

interface SmsPreviewProps {
  textContent: string;
}

export default function SmsPreview({ textContent }: SmsPreviewProps) {
  return (
    <div className="max-w-xs mx-auto">
      <div className="bg-gray-800 rounded-t-lg p-2 flex items-center justify-center">
        <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
      </div>
      <div className="bg-gray-200 border-4 border-gray-800 rounded-b-lg p-4 h-[500px] overflow-y-auto">
        <div className="bg-green-500 text-white p-3 rounded-lg rounded-tl-none max-w-[80%] mb-2 ml-auto">
          <p className="text-sm">{textContent || 'SMS content will appear here'}</p>
        </div>
        <div className="text-xs text-gray-500 text-right">
          {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
    </div>
  );
}
