import React from 'react';

interface TextEditorProps {
  content: string;
  onChange: (content: string) => void;
}

export default function TextEditor({ content, onChange }: TextEditorProps) {
  return (
    <div className="w-full">
      <textarea
        className="w-full h-64 p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
        value={content}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Enter content here..."
      />
    </div>
  );
}
