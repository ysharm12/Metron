import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import TextEditor from './TextEditor';
import ImagePreview from './ImagePreview';
import ChannelPreview from './ChannelPreview';

type Channel = 'sms' | 'linkedin' | 'twitter' | 'instagram' | 'directmail';

const channels: Channel[] = ['sms', 'linkedin', 'twitter', 'instagram', 'directmail'];

export default function ChannelContent() {
  const [activeTab, setActiveTab] = useState<Channel>('sms');
  const [textContent, setTextContent] = useState<Record<Channel, string>>({
    sms: '',
    linkedin: '',
    twitter: '',
    instagram: '',
    directmail: ''
  });
  const [imageExists, setImageExists] = useState<Record<Channel, boolean>>({
    sms: false,
    linkedin: false,
    twitter: false,
    instagram: false,
    directmail: false
  });
  const [imagePaths, setImagePaths] = useState<Record<Channel, string>>({
    sms: '',
    linkedin: '',
    twitter: '',
    instagram: '',
    directmail: ''
  });
  const [loading, setLoading] = useState<Record<Channel, boolean>>({
    sms: true,
    linkedin: true,
    twitter: true,
    instagram: true,
    directmail: true
  });
  const [saving, setSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);

  // Fetch text content for a channel
  const fetchTextContent = async (channel: Channel) => {
    try {
      const response = await fetch(`/api/content/text-content?channel=${channel}`);
      const data = await response.json();
      
      setTextContent(prev => ({
        ...prev,
        [channel]: data.exists ? data.content : ''
      }));
      
      setLoading(prev => ({
        ...prev,
        [channel]: false
      }));
    } catch (error) {
      console.error(`Error fetching ${channel} content:`, error);
      setLoading(prev => ({
        ...prev,
        [channel]: false
      }));
    }
  };

  // Fetch image content for a channel
  const fetchImageContent = async (channel: Channel) => {
    if (channel === 'sms') {
      setImageExists(prev => ({
        ...prev,
        [channel]: false
      }));
      return;
    }
    
    try {
      const response = await fetch(`/api/content/image-content?channel=${channel}`);
      const data = await response.json();
      
      setImageExists(prev => ({
        ...prev,
        [channel]: data.exists
      }));
      
      if (data.exists) {
        setImagePaths(prev => ({
          ...prev,
          [channel]: data.imagePath
        }));
      }
    } catch (error) {
      console.error(`Error fetching ${channel} image:`, error);
    }
  };

  // Save text content for a channel
  const saveTextContent = async (channel: Channel, content: string) => {
    setSaving(true);
    try {
      const response = await fetch('/api/content/save-text', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ channel, content }),
      });
      
      if (response.ok) {
        setLastSaved(new Date());
      } else {
        console.error('Failed to save content');
      }
    } catch (error) {
      console.error('Error saving content:', error);
    } finally {
      setSaving(false);
    }
  };

  // Handle text content change
  const handleTextChange = (channel: Channel, content: string) => {
    setTextContent(prev => ({
      ...prev,
      [channel]: content
    }));
  };

  // Handle text content save
  const handleSave = async () => {
    await saveTextContent(activeTab, textContent[activeTab]);
  };

  // Fetch content when tab changes
  useEffect(() => {
    fetchTextContent(activeTab);
    fetchImageContent(activeTab);
  }, [activeTab]);

  // Auto-save when content changes (debounced)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (textContent[activeTab] !== '') {
        saveTextContent(activeTab, textContent[activeTab]);
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, [textContent, activeTab]);

  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Channel Content</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={handleSave}
            disabled={saving}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-blue-400"
          >
            {saving ? 'Saving...' : 'Save'}
          </button>
          {lastSaved && (
            <span className="text-sm text-gray-500">
              Last saved: {lastSaved.toLocaleTimeString()}
            </span>
          )}
        </div>
      </div>

      <Tabs defaultValue="sms" onValueChange={(value) => setActiveTab(value as Channel)}>
        <TabsList className="w-full mb-4">
          {channels.map((channel) => (
            <TabsTrigger
              key={channel}
              value={channel}
              className="flex-1 capitalize"
            >
              {channel === 'directmail' ? 'Direct Mail' : channel}
            </TabsTrigger>
          ))}
        </TabsList>

        {channels.map((channel) => (
          <TabsContent key={channel} value={channel} className="mt-4">
            {loading[channel] ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-700"></div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                <div className="md:col-span-3 bg-white p-4 rounded-md shadow-sm border border-gray-200">
                  <h3 className="text-lg font-medium mb-2 capitalize">
                    {channel === 'directmail' ? 'Direct Mail' : channel} Content
                  </h3>
                  <TextEditor
                    content={textContent[channel]}
                    onChange={(content) => handleTextChange(channel, content)}
                  />
                  
                  {channel !== 'sms' && imageExists[channel] && (
                    <div className="mt-4">
                      <h3 className="text-lg font-medium mb-2">Image</h3>
                      <div className="border border-gray-200 rounded-md p-2">
                        <img
                          src={imagePaths[channel]}
                          alt={`${channel} banner`}
                          className="w-full h-auto object-contain"
                        />
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="md:col-span-2 bg-white p-4 rounded-md shadow-sm border border-gray-200">
                  <h3 className="text-lg font-medium mb-2">Preview</h3>
                  <div className="h-[600px] overflow-y-auto">
                    <ChannelPreview
                      channel={channel}
                      textContent={textContent[channel]}
                      imagePath={imagePaths[channel]}
                      imageExists={imageExists[channel]}
                    />
                  </div>
                </div>
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
