import React, { useState } from 'react';
import Button from '../ui/Button';
import { useRouter } from 'next/navigation';

// Campaign types based on trigger.json
const campaignTypes = [
  'New_Campaign',
  'Renewal_Campaign',
  'Follow_up_Campaign',
  'Seasonal_Campaign'
];

interface TriggerFormData {
  trigger_type: string;
  campaign_name: string;
  goal: string;
  audience: string;
  budget: number | '';
  requested_date: string;
  test_mode?: boolean;
}

export default function TriggerForm() {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  
  // Initialize form with structure matching trigger.json
  const [formData, setFormData] = useState<TriggerFormData>({
    trigger_type: 'New_Campaign',
    campaign_name: '',
    goal: '',
    audience: '',
    budget: '',
    requested_date: '',
    test_mode: true // Enable test mode by default for now
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type, checked } = e.target as HTMLInputElement;
    
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : 
              name === 'budget' ? (value === '' ? '' : Number(value)) : value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    setSuccess(null);
    
    try {
      console.log('Submitting form data:', formData);
      
      const response = await fetch('/api/trigger', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        const errorMessage = result.message || result.error || 'Failed to start campaign';
        throw new Error(errorMessage);
      }
      
      setSuccess('Campaign started successfully! Processing in the backend...');
      console.log('Campaign started:', result);
      
      // Redirect to process page after 2 seconds to see the visualization
      setTimeout(() => {
        router.push('/process');
      }, 2000);
      
    } catch (err) {
      console.error('Error starting campaign:', err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
      
      // Show detailed error in console for debugging
      if (err instanceof Error) {
        console.error('Error details:', err.stack);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="trigger_type" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Campaign Type</label>
          <select
            id="trigger_type"
            name="trigger_type"
            value={formData.trigger_type}
            onChange={handleInputChange}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            required
          >
            {campaignTypes.map((type) => (
              <option key={type} value={type}>{type.replace('_', ' ')}</option>
            ))}
          </select>
        </div>
        
        <div>
          <label htmlFor="campaign_name" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Campaign Name</label>
          <input
            type="text"
            id="campaign_name"
            name="campaign_name"
            value={formData.campaign_name}
            onChange={handleInputChange}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            placeholder="e.g. New Optum RX Plan Launch"
            required
          />
        </div>
      </div>
      
      <div>
        <label htmlFor="goal" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Campaign Goal</label>
        <input
          type="text"
          id="goal"
          name="goal"
          value={formData.goal}
          onChange={handleInputChange}
          className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          placeholder="e.g. Increase sales by 20% for medicaid"
          required
        />
      </div>
      
      <div>
        <label htmlFor="audience" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Target Audience</label>
        <input
          type="text"
          id="audience"
          name="audience"
          value={formData.audience}
          onChange={handleInputChange}
          className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          placeholder="e.g. medicaid users"
          required
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="budget" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Budget (USD)</label>
          <input
            type="number"
            id="budget"
            name="budget"
            value={formData.budget}
            onChange={handleInputChange}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            placeholder="4000"
            required
          />
        </div>
        
        <div>
          <label htmlFor="requested_date" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Requested Launch Date</label>
          <input
            type="date"
            id="requested_date"
            name="requested_date"
            value={formData.requested_date}
            onChange={handleInputChange}
            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            required
          />
        </div>
      </div>

      {error && (
        <div className="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
          <span className="font-medium">Error:</span> {error}
        </div>
      )}
      
      {success && (
        <div className="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg" role="alert">
          <span className="font-medium">Success:</span> {success}
        </div>
      )}
      
      <div className="flex items-center mt-6 mb-4">
        <input
          type="checkbox"
          id="test_mode"
          name="test_mode"
          checked={!!formData.test_mode}
          onChange={handleInputChange}
          className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
        />
        <label htmlFor="test_mode" className="ml-2 text-sm font-medium text-gray-900 dark:text-white">
          Test Mode (Skip actual backend processing)
        </label>
      </div>
      
      <div className="flex justify-end space-x-3 mt-2">
        <Button 
          variant="secondary" 
          type="button" 
          onClick={() => router.push('/')}
        >
          Cancel
        </Button>
        <Button 
          variant="primary" 
          type="submit" 
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Starting Campaign...' : 'Start Campaign'}
        </Button>
      </div>
    </form>
  );
}
