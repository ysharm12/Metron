"use client"
import React, { useState, useEffect, useRef } from 'react';

interface HtmlFile {
  name: string;
  path: string;
  lastModified: string;
}

interface FileComment {
  text: string;
  timestamp: string;
}

interface FileStatus {
  approved: boolean;
  timestamp: string | null;
}

export default function HtmlFileViewer() {
  const [files, setFiles] = useState<HtmlFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [fileContents, setFileContents] = useState<{[key: string]: string}>({});
  const [comments, setComments] = useState<{[key: string]: FileComment[]}>({});
  const [statuses, setStatuses] = useState<{[key: string]: FileStatus}>({});
  const [commentInput, setCommentInput] = useState<string>('');
  const [lastModifiedTimes, setLastModifiedTimes] = useState<{[key: string]: string}>({});

  // Fetch the list of HTML files
  useEffect(() => {
    const fetchFiles = async () => {
      try {
        const response = await fetch('/api/hitl/html-files');
        const data = await response.json();
        
        if (data.files && data.files.length > 0) {
          // Check if files have changed
          let filesChanged = false;
          const newLastModifiedTimes: {[key: string]: string} = {};
          
          // Build a map of the new last modified times
          data.files.forEach((file: HtmlFile) => {
            newLastModifiedTimes[file.name] = file.lastModified;
            
            // Check if this file is new or has been modified
            if (!lastModifiedTimes[file.name] || lastModifiedTimes[file.name] !== file.lastModified) {
              filesChanged = true;
            }
          });
          
          // Check if any files have been removed
          if (Object.keys(lastModifiedTimes).length !== data.files.length) {
            filesChanged = true;
          }
          
          // Only update state if files have changed
          if (filesChanged) {
            setFiles(data.files);
            setLastModifiedTimes(newLastModifiedTimes);
            
            // Set the first file as active by default if no tab is active
            if (!activeTab || !data.files.some(f => f.name === activeTab)) {
              setActiveTab(data.files[0].name);
            }
            
            // Initialize comments and statuses for new files
            data.files.forEach((file: HtmlFile) => {
              if (!comments[file.name]) {
                setComments(prev => ({
                  ...prev,
                  [file.name]: []
                }));
              }
              
              if (!statuses[file.name]) {
                setStatuses(prev => ({
                  ...prev,
                  [file.name]: { approved: false, timestamp: null }
                }));
              }
            });
          }
        } else {
          setFiles([]);
          setActiveTab(null);
        }
      } catch (err) {
        setError('Failed to fetch HTML files');
        console.error('Error fetching HTML files:', err);
      } finally {
        setLoading(false);
      }
    };

    // Initial fetch
    fetchFiles();
    
    // Set up polling to check for file changes every 10 seconds
    const intervalId = setInterval(fetchFiles, 10000);
    
    return () => clearInterval(intervalId);
  }, [activeTab, lastModifiedTimes, comments, statuses]);

  // Fetch file content when activeTab changes or the file is modified
  useEffect(() => {
    const fetchFileContent = async (fileName: string) => {
      try {
        // Check if we need to fetch the content (if it's not cached or if the file has been modified)
        const shouldFetch = !fileContents[fileName] || 
          (lastModifiedTimes[fileName] && 
           (!fileContents[`${fileName}_lastModified`] || 
            fileContents[`${fileName}_lastModified`] !== lastModifiedTimes[fileName]));
        
        if (!shouldFetch) return;
        
        const response = await fetch(`/api/hitl/file-content?filename=${encodeURIComponent(fileName)}`);
        
        if (!response.ok) {
          throw new Error(`Failed to fetch content for ${fileName}`);
        }
        
        const content = await response.text();
        setFileContents(prev => ({
          ...prev,
          [fileName]: content,
          [`${fileName}_lastModified`]: lastModifiedTimes[fileName]
        }));
      } catch (err) {
        console.error(`Error fetching content for ${fileName}:`, err);
      }
    };

    if (activeTab) {
      fetchFileContent(activeTab);
    }
  }, [activeTab, lastModifiedTimes, fileContents]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
        <span className="ml-2 text-gray-600 dark:text-gray-400">Loading HTML files...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-100 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 p-4 rounded-lg">
        <p>{error}</p>
      </div>
    );
  }

  if (files.length === 0) {
    return (
      <div className="bg-yellow-100 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 text-yellow-700 dark:text-yellow-300 p-4 rounded-lg">
        <p>No HTML files found in the backend/output directory.</p>
      </div>
    );
  }

  // Handle adding a new comment
  const addComment = () => {
    if (!activeTab || !commentInput.trim()) return;
    
    const newComment: FileComment = {
      text: commentInput.trim(),
      timestamp: new Date().toISOString()
    };
    
    setComments(prev => ({
      ...prev,
      [activeTab]: [...(prev[activeTab] || []), newComment]
    }));
    
    setCommentInput('');
  };
  
  // Handle approval status change
  const handleApproval = (approved: boolean) => {
    if (!activeTab) return;
    
    setStatuses(prev => ({
      ...prev,
      [activeTab]: {
        approved,
        timestamp: new Date().toISOString()
      }
    }));
  };
  
  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      {/* Tabs */}
      <div className="flex border-b border-gray-200 dark:border-gray-700 overflow-x-auto">
        {files.map((file) => (
          <button
            key={file.name}
            className={`px-4 py-2 text-sm font-medium flex items-center whitespace-nowrap ${
              activeTab === file.name
                ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-500'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
            onClick={() => setActiveTab(file.name)}
          >
            {file.name}
            {statuses[file.name]?.approved && (
              <span className="ml-2 bg-green-100 text-green-800 text-xs font-medium px-2 py-0.5 rounded dark:bg-green-900 dark:text-green-300">
                Approved
              </span>
            )}
          </button>
        ))}
      </div>
      
      {/* Content */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
        {/* HTML Content - Takes up 2/3 of the space on medium+ screens */}
        <div className="md:col-span-2">
          {activeTab && fileContents[activeTab] ? (
            <div className="bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700 h-[500px] overflow-hidden">
              <iframe
                srcDoc={fileContents[activeTab]}
                title={activeTab}
                className="w-full h-full"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 bg-gray-50 dark:bg-gray-700 rounded border border-gray-200 dark:border-gray-600">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
              <span className="ml-2 text-gray-600 dark:text-gray-400">Loading content...</span>
            </div>
          )}
        </div>
        
        {/* Comments and Approval Section - Takes up 1/3 of the space */}
        <div className="bg-gray-50 dark:bg-gray-700 rounded border border-gray-200 dark:border-gray-600 p-4 h-[500px] flex flex-col">
          <div className="mb-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">File Status</h3>
            {activeTab && (
              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => handleApproval(true)}
                  className={`px-3 py-1.5 text-sm font-medium rounded-md ${
                    statuses[activeTab]?.approved
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-200 text-gray-800 dark:bg-gray-600 dark:text-gray-200 hover:bg-green-500 hover:text-white'
                  }`}
                >
                  Approve
                </button>
                <button
                  onClick={() => handleApproval(false)}
                  className={`px-3 py-1.5 text-sm font-medium rounded-md ${
                    statuses[activeTab] && !statuses[activeTab].approved
                      ? 'bg-red-600 text-white'
                      : 'bg-gray-200 text-gray-800 dark:bg-gray-600 dark:text-gray-200 hover:bg-red-500 hover:text-white'
                  }`}
                >
                  Reject
                </button>
              </div>
            )}
            
            {activeTab && statuses[activeTab]?.timestamp && (
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                <p>
                  {statuses[activeTab].approved ? 'Approved' : 'Rejected'} on {formatDate(statuses[activeTab].timestamp)}
                </p>
              </div>
            )}
          </div>
          
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Comments</h3>
          
          {/* Comments list */}
          <div className="flex-grow overflow-y-auto mb-4 space-y-3">
            {activeTab && comments[activeTab] && comments[activeTab].length > 0 ? (
              comments[activeTab].map((comment, index) => (
                <div key={index} className="bg-white dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-600">
                  <p className="text-sm text-gray-800 dark:text-gray-200">{comment.text}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{formatDate(comment.timestamp)}</p>
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-500 dark:text-gray-400 italic">No comments yet</p>
            )}
          </div>
          
          {/* Add comment form */}
          <div className="mt-auto">
            <div className="flex">
              <input
                type="text"
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                placeholder="Add a comment..."
                className="flex-grow p-2 text-sm border border-gray-300 dark:border-gray-600 rounded-l-md focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
              />
              <button
                onClick={addComment}
                disabled={!commentInput.trim()}
                className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 text-sm font-medium rounded-r-md disabled:bg-blue-400 disabled:cursor-not-allowed"
              >
                Add
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
