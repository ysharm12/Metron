"use client";

import React, { ReactNode } from 'react';
import { ReportMonitorProvider, useReportMonitor } from '../contexts/ReportMonitorContext';
import ReviewPopup from './ReviewPopup';

// This component wraps the app with necessary providers
function AppWrapperInner({ children }: { children: ReactNode }) {
  const { showPopup, dismissPopup } = useReportMonitor();
  
  // Log when popup state changes
  React.useEffect(() => {
    console.log('Popup state in AppWrapper:', showPopup);
  }, [showPopup]);
  
  return (
    <>
      {children}
      
      {/* Show the review popup when a report is detected */}
      {showPopup && (
        <ReviewPopup onClose={dismissPopup} />
      )}
    </>
  );
}

// This is the main wrapper that includes all providers
export default function AppWrapper({ children }: { children: ReactNode }) {
  // Log when the wrapper mounts
  React.useEffect(() => {
    console.log('AppWrapper mounted - Report monitoring active');
  }, []);
  
  return (
    <ReportMonitorProvider pollingInterval={3000}>
      <AppWrapperInner>
        {children}
      </AppWrapperInner>
    </ReportMonitorProvider>
  );
}
