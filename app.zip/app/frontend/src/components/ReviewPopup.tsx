"use client";

import React, { useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface ReviewPopupProps {
  onClose: () => void;
  onViewReport?: () => void; // Optional handler for viewing the report
}

export default function ReviewPopup({ onClose, onViewReport }: ReviewPopupProps) {
  const router = useRouter();
  
  useEffect(() => {
    console.log('ReviewPopup mounted');
    
    // Log that the popup is visible
    const timer = setTimeout(() => {
      console.log('ReviewPopup is visible');
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);
  
  const handleViewReport = () => {
    // Navigate to the report viewer page
    console.log('Navigating to report viewer');
    
    if (onViewReport) {
      // Use the provided handler
      onViewReport();
    } else {
      // Default behavior
      router.push('/report-viewer');
      onClose();
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full shadow-xl">
        <div className="flex items-center mb-4">
          <div className="bg-blue-100 p-2 rounded-full mr-3">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-gray-800">Human Review Required</h2>
        </div>
        
        <div className="mb-6">
          <p className="text-gray-600 mb-3">
            A campaign report has been generated and requires human review before proceeding.
          </p>
          <p className="text-gray-600">
            Please review the campaign report to ensure all details are correct and meet your requirements.
          </p>
        </div>
        
        <div className="flex justify-end space-x-3">
          <button 
            className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300"
            onClick={onClose}
          >
            Dismiss
          </button>
          <button 
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            onClick={handleViewReport}
          >
            View Report
          </button>
        </div>
        
        <div className="mt-4 pt-3 border-t border-gray-200 text-xs text-gray-500">
          <p>If you need to reset the popup system, visit the <a href="/reset-reports" className="text-blue-600 hover:underline">reset page</a>.</p>
        </div>
      </div>
    </div>
  );
}
