import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.linear_model import LinearRegression
import json

def generate_combined_sentiment_summary():
    # --- Process sentiment trends from CSV ---
    trends_df = pd.read_csv("synthetic_data/sentiment_trends.csv")
    trends_df['date'] = pd.to_datetime(trends_df['date'])
    trends_df['date_ordinal'] = trends_df['date'].apply(lambda x: x.toordinal())
    
    # Compute overall average sentiment from CSV data
    csv_avg_sentiment = trends_df['avg_sentiment'].mean()
    
    # Fit a linear regression model to capture the sentiment trend over time
    X = trends_df[['date_ordinal']]
    y = trends_df['avg_sentiment']
    model = LinearRegression()
    model.fit(X, y)
    slope = model.coef_[0]
    
    # Determine trend direction based on the slope (using a small threshold)
    threshold = 1e-3  
    if slope > threshold:
        trend_direction = "increasing"
    elif slope < -threshold:
        trend_direction = "decreasing"
    else:
        trend_direction = "stable"
    
    # --- Process individual sentiment entries from JSON ---
    try:
        with open("synthetic_data/sentiment.json", "r") as f:
            sentiments = json.load(f)
    except Exception as e:
        sentiments = []
        print(f"Error loading sentiment.json: {e}")
    
    if sentiments:
        individual_scores = [entry.get("sentiment_score", 0) for entry in sentiments]
        individual_avg_sentiment = np.mean(individual_scores)
        total_entries = len(sentiments)
    else:
        individual_avg_sentiment = None
        total_entries = 0
    
    # --- Build the multi-line summary string ---
    summary_lines = [
        "Sentiment Analysis Summary:",
        "-----------------------------------",
        "CSV Sentiment Trends:",
        f"  - Average Sentiment: {csv_avg_sentiment:.2f}",
        f"  - Trend Direction: {trend_direction} (slope: {slope:.5f})",
        "",
        "Individual Sentiment Entries:",
        f"  - Total Entries: {total_entries}",
        f"  - Average Sentiment Score: {individual_avg_sentiment:.2f}" if individual_avg_sentiment is not None else "  - Average Sentiment Score: N/A"
    ]
    
    summary_text = "\n".join(summary_lines)
    return summary_text

# if __name__ == "__main__":
#     summary = generate_combined_sentiment_summary()
#     print(summary)
