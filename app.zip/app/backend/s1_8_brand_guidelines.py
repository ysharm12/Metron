import os
import json
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

DEFAULT_BRAND_GUIDELINES = {
    "brand": "YourBrand",
    "tone": "Friendly, professional, and concise",
    "logo_usage": "Use the official logo with 20px clear space",
    "color_palette": {
        "primary": "#1D4ED8",
        "secondary": "#F59E0B",
        "accent": "#10B981"
    },
    "legal_disclaimers": {
        "email": "You can unsubscribe at any time",
        "sms": "Standard messaging rates apply"
    },
    "forbidden_phrases": [
        "free trial",
        "unlimited access"
    ],
    "compliance_rules": {
        "CA": "Include California-specific disclaimer",
        "NY": "NY residents: special disclaimer"
    }
}

def load_brand_guidelines(filepath="brand_guidelines.json"):
    """
    Loads the brand guidelines from the specified JSON file.
    If the file is missing or cannot be parsed, returns default guidelines.
    
    Returns:
        dict: The brand guidelines.
    """
    if not os.path.exists(filepath):
        logger.warning(f"Brand guidelines file not found at '{filepath}'. Using default guidelines.")
        return DEFAULT_BRAND_GUIDELINES
    
    try:
        with open(filepath, "r") as f:
            guidelines = json.load(f)
        # Verify that required keys exist; if not, use defaults for missing keys.
        for key in DEFAULT_BRAND_GUIDELINES:
            if key not in guidelines:
                logger.warning(f"Key '{key}' missing in guidelines; using default value.")
                guidelines[key] = DEFAULT_BRAND_GUIDELINES[key]
        return guidelines
    except Exception as e:
        logger.error(f"Error reading brand guidelines file: {e}. Using default guidelines.", exc_info=True)
        return DEFAULT_BRAND_GUIDELINES

def generate_brand_guidelines_report(guidelines):
    """
    Generates an in-depth multi-line text report from the brand guidelines.
    
    Returns:
        str: The formatted report.
    """
    report_lines = [
        "=== Brand Guidelines Analysis Report ===",
        f"Brand: {guidelines.get('brand', 'N/A')}",
        f"Tone: {guidelines.get('tone', 'N/A')}",
        f"Logo Usage: {guidelines.get('logo_usage', 'N/A')}",
        "",
        "Color Palette:",
        f"  - Primary: {guidelines.get('color_palette', {}).get('primary', 'N/A')}",
        f"  - Secondary: {guidelines.get('color_palette', {}).get('secondary', 'N/A')}",
        f"  - Accent: {guidelines.get('color_palette', {}).get('accent', 'N/A')}",
        "",
        "Legal Disclaimers:",
        f"  - Email: {guidelines.get('legal_disclaimers', {}).get('email', 'N/A')}",
        f"  - SMS: {guidelines.get('legal_disclaimers', {}).get('sms', 'N/A')}",
        "",
        "Forbidden Phrases:",
        "  - " + "\n  - ".join(guidelines.get("forbidden_phrases", [])),
        "",
        "Compliance Rules:",
    ]
    compliance = guidelines.get("compliance_rules", {})
    for region, rule in compliance.items():
        report_lines.append(f"  - {region}: {rule}")
    
    report_lines.append("")
    report_lines.append("This set of guidelines is used to ensure all generated content adheres to the brand's identity and legal requirements.")
    
    return "\n".join(report_lines)

def append_report(report_text, output_filepath):
    """
    Appends the given multi-line report text to the specified output file.
    If the file exists, the new report is appended; otherwise, a new file is created.
    
    Returns:
        str: The updated file content.
    """
    if os.path.exists(output_filepath):
        with open(output_filepath, "r") as f:
            current_content = f.read()
    else:
        current_content = ""
    
    updated_content = current_content + "\n\n" + report_text + "\n"
    with open(output_filepath, "w") as f:
        f.write(updated_content)
    logger.info(f"Report appended to {output_filepath}")
    return updated_content

def create_brand_guidelines_report():
    # Set file paths
    guidelines_file = "synthetic_data/brand_guidelines.json"
    output_folder = "output"
    os.makedirs(output_folder, exist_ok=True)
    combined_report_file = os.path.join(output_folder, "combined_text_data_report.txt")
    
    # Load brand guidelines
    guidelines = load_brand_guidelines(guidelines_file)
    
    # Generate a report from the guidelines
    report_text = generate_brand_guidelines_report(guidelines)
    
    # Append the generated report to the combined report file (preserving any existing content)
    append_report(report_text, combined_report_file)
    
    # For demonstration, print the report
    print("=== Brand Guidelines Analysis Report ===")
    print(report_text)

# if __name__ == "__main__":
#     main()
