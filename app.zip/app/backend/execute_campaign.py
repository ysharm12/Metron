#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Execute campaign script - Bridge between Next.js API and ui_call_1.py
This script takes a JSON file path as input, reads the campaign data,
and passes it to the initiate_s1_main_trigger function.
"""

import sys
import json
import os
import traceback

# Add the current directory to the Python path to ensure imports work
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Now import the function
try:
    from s1_main_trigger import initiate_s1_main_trigger
except ImportError as e:
    print(f"Error importing s1_main_trigger: {e}")
    traceback.print_exc()
    sys.exit(1)

def main():
    """Main function to execute the campaign with data from a JSON file."""
    print(f"Starting execute_campaign.py with args: {sys.argv}")
    print(f"Current working directory: {os.getcwd()}")
    
    if len(sys.argv) < 2:
        print("Error: Missing JSON file path argument")
        print("Usage: python execute_campaign.py <path_to_json_file>")
        sys.exit(1)
    
    json_file_path = sys.argv[1]
    print(f"JSON file path: {json_file_path}")
    
    # Handle both absolute and relative paths
    if not os.path.isabs(json_file_path):
        # If the path is relative to the frontend directory, we need to adjust it
        # Try different possible locations
        possible_paths = [
            json_file_path,  # As is (relative to current directory)
            os.path.join(os.getcwd(), json_file_path),  # Relative to current working directory
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'frontend', json_file_path)  # Relative to frontend directory
        ]
        
        found = False
        for path in possible_paths:
            print(f"Checking path: {path}")
            if os.path.exists(path):
                json_file_path = path
                found = True
                print(f"Found JSON file at: {json_file_path}")
                break
        
        if not found:
            print(f"Error: JSON file not found at any of these locations:")
            for path in possible_paths:
                print(f"  - {path}")
            sys.exit(1)
    elif not os.path.exists(json_file_path):
        print(f"Error: JSON file not found at {json_file_path}")
        sys.exit(1)
    
    try:
        # Read the campaign data from the JSON file
        with open(json_file_path, 'r') as f:
            campaign_data = json.load(f)
        
        # Print the data we're about to process
        print(f"Starting campaign with data: {json.dumps(campaign_data, indent=2)}")
        
        # Create a simple dummy response if the main function is not available
        # This is just for testing the API connection
        if 'test_mode' in campaign_data and campaign_data['test_mode']:
            print("Running in test mode, skipping actual campaign execution")
            print("Test successful!")
            sys.exit(0)
        
        # Call the main trigger function with our data
        try:
            result = initiate_s1_main_trigger(campaign_data)
            
            # Output success message
            print(f"Campaign execution completed successfully")
            if result:
                print(f"Result: {result}")
            
            sys.exit(0)
        except Exception as e:
            print(f"Error in initiate_s1_main_trigger: {str(e)}")
            traceback.print_exc()
            sys.exit(1)
            
    except json.JSONDecodeError as e:
        print(f"Error parsing JSON file: {str(e)}")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error executing campaign: {str(e)}")
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
