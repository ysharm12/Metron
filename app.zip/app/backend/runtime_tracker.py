import os
import json

OUTPUT_FOLDER = "output"
OUTPUT_FILE = os.path.join(OUTPUT_FOLDER, "runtime_tracker.json")

def _load_runtime():
    """
    Loads the runtime data from the JSON file.
    If the file or folder doesn't exist, returns an empty dictionary.
    """
    if not os.path.exists(OUTPUT_FOLDER):
        os.makedirs(OUTPUT_FOLDER)
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                data = {}
    else:
        data = {}
    return data

def _save_runtime(data):
    """
    Saves the runtime data dictionary to the JSON file.
    """
    with open(OUTPUT_FILE, "w") as f:
        json.dump(data, f, indent=4)

def update_agent_runtime(agent_name, elapsed_seconds):
    """
    Updates the total runtime for the given agent by adding the elapsed time.
    The new runtime is rounded to two decimal places before storing.
    
    Parameters:
        agent_name (str): The unique identifier for the agent (e.g., "StrategyAgent").
        elapsed_seconds (float): The elapsed time in seconds to add.
        
    Returns:
        float: The updated total runtime for the specified agent, rounded to 2 decimal places.
    """
    data = _load_runtime()
    current_runtime = data.get(agent_name, 0.0)
    # Add the elapsed seconds and round to two decimal places before storing
    new_runtime = elapsed_seconds + current_runtime
    data[agent_name] = new_runtime
    _save_runtime(data)
    print(f"Updated runtime for {agent_name}: {new_runtime:.2f} seconds.")
    return new_runtime

def get_agent_runtime(agent_name):
    """
    Retrieves the current total runtime for the specified agent.
    
    Parameters:
        agent_name (str): The unique identifier for the agent.
    
    Returns:
        float: The current total runtime for the agent (in seconds), rounded to 2 decimal places.
    """
    data = _load_runtime()
    runtime = data.get(agent_name, 0.0)
    print(f"Current runtime for {agent_name}: {runtime:.2f} seconds.")
    return runtime