import json
import os
import networkx as nx
import matplotlib.pyplot as plt

def visualize_process_diagram(json_path="process_diagram.json"):
    """
    Visualizes the process diagram stored in the JSON file.
    
    Reads the JSON file containing nodes and connections, creates a directed graph,
    and then displays it using networkx and matplotlib.
    
    Parameters:
      json_path (str): Path to the JSON file.
    """
    if not os.path.exists(json_path):
        print(f"File '{json_path}' does not exist.")
        return

    with open(json_path, "r") as f:
        data = json.load(f)

    # Create a directed graph.
    G = nx.DiGraph()

    # Add nodes. Use the node's name as its label.
    for node in data.get("nodes", []):
        node_id = node["id"]
        label = node.get("name", node_id)
        G.add_node(node_id, label=label)

    # Add edges from 'from' nodes to the current node.
    for connection in data.get("connections", []):
        src = connection["from"]
        dst = connection["to"]
        relationship = connection.get("relationship", "")
        G.add_edge(src, dst, relationship=relationship)

    # Use spring layout for a visually appealing graph.
    pos = nx.spring_layout(G)
    node_labels = {node: G.nodes[node]["label"] for node in G.nodes()}

    plt.figure(figsize=(10, 8))
    nx.draw_networkx_nodes(G, pos, node_color="lightblue", node_size=500)
    nx.draw_networkx_labels(G, pos, labels=node_labels, font_size=10)
    nx.draw_networkx_edges(G, pos, arrowstyle="->", arrowsize=10)

    # Draw edge labels if relationships exist.
    edge_labels = nx.get_edge_attributes(G, "relationship")
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_color="red")

    plt.title("Process Diagram Visualization")
    plt.axis("off")
    plt.show()


visualize_process_diagram("output/process_diagram.json")