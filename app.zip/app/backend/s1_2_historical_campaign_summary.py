import os
import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
#_____ ALWAYS IMPORT________
import logging_agentic_behavior as lab
import tasks_counter
import time
import runtime_tracker
from blueprints_creator import update_process
#___________________________

def generate_campaign_summary():
    start = time.time()
    # Load historical campaign data from synthetic_data/historical_campaigns.csv
    file_path = os.path.join("synthetic_data", "historical_campaigns.csv")
    campaigns = pd.read_csv(file_path)
    
    # Overall benchmark calculations
    total_campaigns = len(campaigns)
    total_impressions = campaigns["impressions"].sum()
    total_clicks = campaigns["clicks"].sum()
    total_conversions = campaigns["conversions"].sum()
    avg_ctr = (total_clicks / total_impressions * 100) if total_impressions > 0 else 0
    avg_conv_rate = (total_conversions / total_impressions * 100) if total_impressions > 0 else 0

    # Best performing channel based on conversion rate
    channel_perf = campaigns.groupby("channel").agg({
        "impressions": "sum",
        "clicks": "sum",
        "conversions": "sum"
    }).reset_index()
    channel_perf["conv_rate"] = channel_perf["conversions"] / channel_perf["impressions"] * 100
    best_channel_row = channel_perf.sort_values("conv_rate", ascending=False).iloc[0]
    best_channel = best_channel_row["channel"]
    best_channel_conv_rate = best_channel_row["conv_rate"]

    # Prepare features and target for ML model to predict conversions
    features = campaigns[["budget", "impressions", "clicks"]].copy()
    # One-hot encode categorical variables: channel and target_segment
    features = pd.concat([
        features,
        pd.get_dummies(campaigns["channel"], prefix="channel"),
        pd.get_dummies(campaigns["target_segment"], prefix="segment")
    ], axis=1)
    target = campaigns["conversions"]

    # Split data (for training/evaluation)
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)
    
    # Train a state-of-art XGBoost regressor
    model = xgb.XGBRegressor(n_estimators=100, random_state=42, verbosity=0)
    model.fit(X_train, y_train)
    
    # Evaluate the model and compute RMSE
    y_pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    
    # Extract top 3 feature importances
    importance_dict = model.get_booster().get_score(importance_type='gain')
    feature_importances = {feat: importance_dict.get(feat, 0) for feat in features.columns}
    top_features = sorted(feature_importances.items(), key=lambda x: x[1], reverse=True)[:3]
    top_features_str = ", ".join([f"{feat}" for feat, _ in top_features])
    
    # Build the multi-line summary string
    summary_lines = [
        "Historical Campaign Analysis Summary:",
        "--------------------------------------",
        f"Total Campaigns: {total_campaigns}",
        f"Average CTR: {avg_ctr:.2f}%",
        f"Average Conversion Rate: {avg_conv_rate:.2f}%",
        "",
        f"Best Performing Channel: {best_channel} (Conversion Rate: {best_channel_conv_rate:.2f}%)",
        "",
        "State-of-Art ML Insights:",
        f" - An XGBoost model was trained to predict campaign conversions with an RMSE of {rmse:.2f}.",
        f" - Key predictors of campaign performance are: {top_features_str}."
    ]

    import random; rand_float = random.uniform(3, 5)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Historical_Campaign_Specialist"
    log_step = 4
    log_task_id = "task_004"
    log_status = "completed"
    log_process = "Campaign_Summary_Analysis"
    log_details = "I have looked at the data, ill go with applying XGBoost with top features, thereby analysing the historical campaign data."
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator", "Ephermal_Customer_Specialist"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    
    return "\n".join(summary_lines)

# if __name__ == "__main__":
#     summary = generate_campaign_summary()
#     print(summary)
