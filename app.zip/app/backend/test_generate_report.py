#!/usr/bin/env python3
"""
Test script to generate a campaign report HTML file for testing the frontend popup.
This script creates a sample campaign_report.html file in the backend directory.
"""

import os
import sys
import datetime

def generate_test_report():
    """Generate a test campaign report HTML file."""
    # Get the directory of this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Path to the report file - make sure it's in the output directory
    output_dir = os.path.join(script_dir, 'output')
    
    # Ensure the output directory exists
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        print(f"Created output directory: {output_dir}")
    
    report_path = os.path.join(output_dir, 'campaign_report.html')
    
    # Generate HTML content
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campaign Report - {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
        }}
        .container {{
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }}
        h1, h2, h3 {{
            color: #0070c9;
        }}
        .header {{
            background: #f5f5f5;
            padding: 10px;
            margin-bottom: 20px;
            border-bottom: 2px solid #0070c9;
        }}
        .section {{
            margin-bottom: 30px;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }}
        th {{
            background-color: #f2f2f2;
        }}
        .highlight {{
            background-color: #ffffcc;
            padding: 10px;
            border-left: 4px solid #ffcc00;
            margin-bottom: 20px;
        }}
        .footer {{
            margin-top: 30px;
            text-align: center;
            font-size: 0.8em;
            color: #777;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Campaign Report</h1>
            <p>Generated on: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </div>
        
        <div class="highlight">
            <strong>Human Review Required:</strong> This campaign requires human review before proceeding to the next stage.
        </div>
        
        <div class="section">
            <h2>Campaign Overview</h2>
            <table>
                <tr>
                    <th>Campaign Name</th>
                    <td>Test Campaign</td>
                </tr>
                <tr>
                    <th>Type</th>
                    <td>Email Marketing</td>
                </tr>
                <tr>
                    <th>Goal</th>
                    <td>Increase customer engagement</td>
                </tr>
                <tr>
                    <th>Target Audience</th>
                    <td>Existing customers aged 25-45</td>
                </tr>
                <tr>
                    <th>Budget</th>
                    <td>$5,000</td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>Pending Review</td>
                </tr>
            </table>
        </div>
        
        <div class="section">
            <h2>Content Analysis</h2>
            <p>The AI has analyzed the campaign content and found the following:</p>
            <ul>
                <li>Message clarity: <strong>High</strong></li>
                <li>Brand alignment: <strong>Medium</strong></li>
                <li>Call-to-action effectiveness: <strong>High</strong></li>
                <li>Potential issues: <strong>None detected</strong></li>
            </ul>
        </div>
        
        <div class="section">
            <h2>Audience Analysis</h2>
            <p>Based on the target audience, here are the key insights:</p>
            <ul>
                <li>Estimated reach: <strong>15,000 customers</strong></li>
                <li>Predicted engagement rate: <strong>3.2%</strong></li>
                <li>Recommended channels: <strong>Email, Social Media</strong></li>
            </ul>
        </div>
        
        <div class="section">
            <h2>Items Requiring Review</h2>
            <p>Please review and approve the following items:</p>
            <ol>
                <li>Campaign messaging and tone</li>
                <li>Budget allocation across channels</li>
                <li>Timeline for campaign execution</li>
                <li>Target audience segmentation</li>
            </ol>
        </div>
        
        <div class="footer">
            <p>This report was generated by the Optum Marketing Platform. For questions, please contact support.</p>
        </div>
    </div>
</body>
</html>
"""
    
    # Write the HTML content to the file
    with open(report_path, 'w') as f:
        f.write(html_content)
    
    print(f"Test campaign report generated at: {report_path}")
    return report_path

if __name__ == "__main__":
    report_path = generate_test_report()
    print(f"You can now test the frontend popup by visiting the app.")
    print(f"The popup should appear automatically when the report is detected.")
