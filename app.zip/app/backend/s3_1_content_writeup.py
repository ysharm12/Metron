import os
import json
import re
from openai import AzureOpenAI
#_____ ALWAYS IMPORT________
import logging_agentic_behavior as lab
import tasks_counter
import time
import runtime_tracker
from blueprints_creator import update_process
#___________________________
# from openai.error import OpenAIError

# -------------------------
# Azure OpenAI Configuration
# -------------------------
client = AzureOpenAI(
    api_version="2024-06-01",
    azure_endpoint="https://openaiqueryit.openai.azure.com/",
    api_key="2u8gagl8riKy2RhvETKrCavz9N9HbflsTSIZX1ejO3HI8RTUBeqIJQQJ99BBACYeBjFXJ3w3AAABACOGussx"
)
deployment_name = "o1-mini"  # Update with your deployment name if needed

# -------------------------
# File Paths
# -------------------------
STRATEGY_FILE = "output/strategy_final.json"
PRODUCT_OVERVIEW_FILE = "synthetic_data/OptumRx_Product_Overview.txt"
FINAL_OUTPUT_FILE = "output/final_content_writeup.json"
CHANNEL_FILES = {
    "sms": "output/sms.txt",
    "linkedin": "output/linkedin.txt",
    "instagram": "output/instagram.txt",
    "twitter": "output/twitter.txt",
    "directmail": "output/directmail.txt"
}

# -------------------------
# Helper Functions
# -------------------------
def load_json_file(filepath):
    with open(filepath, "r") as file:
        return json.load(file)

def load_text_file(filepath):
    with open(filepath, "r") as file:
        return file.read()

def construct_prompt(strategy, product_overview):
    """
    Construct a prompt that instructs the model to create structured JSON output.
    The output will have keys for each channel:
      - For LinkedIn, Instagram, Twitter, and DirectMail: include "content" and a nested "banner" section with design guidelines.
      - For SMS: include only "content".
    The prompt also incorporates the strategy and product overview.
    """
    prompt = f"""
You are an expert marketing strategist and creative content designer.
Using the inputs provided below, generate a structured JSON output with detailed campaign content and banner design guidelines.
For each channel make sure to have proper new line where required, structured properly with appropriate content, emoji etc.

Inputs:
1. Campaign Strategy (from {STRATEGY_FILE}):
{json.dumps(strategy, indent=2)}

2. Product Overview (from {PRODUCT_OVERVIEW_FILE}):
{product_overview}

Instructions:
- For each channel (sms, linkedin, instagram, twitter, and directmail), generate a "content" write-up tailored to the campaign strategy. Use any trigger data in the strategy to determine tone and focus.
- For channels that will include a banner (linkedin, instagram, twitter, directmail), also provide a "banner" section. In the "banner" section, specify:
    - "title": the headline text and its suggested position.
    - "subtitle": any supporting text and its positioning.
    - "message": main body text placement.
    - "cta": call-to-action (e.g., phone number, button text) and where it should be located.
    - "design_instructions": detailed guidelines on layout, font sizes, use of whitespace, layering of graphics, and image usage (including recommended public image URLs). Ensure images are stretched to fill the designated dimensions while preserving aspect ratio.
- For SMS, only include the "content" section.
- Use Tailwind CSS styling guidelines for banner design.
- Output only the final JSON code, wrapped in triple backticks labeled as:
```json DATA
{{ ... }}
```
Do not include any extra commentary outside the JSON.

The expected JSON structure is as follows:
{{
  "sms": {{
      "content": "Detailed campaign write-up for SMS."
  }},
  "linkedin": {{
      "content": "Detailed campaign write-up for LinkedIn.",
      "banner": {{
          "title": "Text and positioning",
          "subtitle": "Text and positioning",
          "message": "Text and positioning",
          "cta": "Call-to-action details",
          "design_instructions": "Detailed design guidelines for banner creation"
      }}
  }},
  "instagram": {{
      "content": "Detailed campaign write-up for Instagram.",
      "banner": {{
          "title": "Text and positioning",
          "subtitle": "Text and positioning",
          "message": "Text and positioning",
          "cta": "Call-to-action details",
          "design_instructions": "Detailed design guidelines for banner creation"
      }}
  }},
  "twitter": {{
      "content": "Detailed campaign write-up for Twitter.",
      "banner": {{
          "title": "Text and positioning",
          "subtitle": "Text and positioning",
          "message": "Text and positioning",
          "cta": "Call-to-action details",
          "design_instructions": "Detailed design guidelines for banner creation"
      }}
  }},
  "directmail": {{
      "content": "Detailed campaign write-up for Direct Mail. Content should always have salutations etc regards, dear customer etc, regards and all that always.",
      "banner": {{
          "title": "Text and positioning",
          "subtitle": "Text and positioning",
          "message": "Text and positioning",
          "cta": "Call-to-action details",
          "design_instructions": "Detailed design guidelines for banner creation"
      }}
  }}
}}

Generate the final JSON now.
"""
    return prompt

def call_openai(prompt):
    """Call Azure OpenAI with the constructed prompt and return the parsed JSON."""
    try:
        response = client.chat.completions.create(
            model=deployment_name,
            messages=[
                {"role": "user", "content": prompt}
            ],
            timeout=300
        )
        raw_output = response.choices[0].message.content.strip()
        # Extract JSON from text enclosed in triple backticks with label "json DATA"
        pattern = r"```json\s*DATA\s*(\{.*\})\s*```"
        match = re.search(pattern, raw_output, re.DOTALL)
        if match:
            json_str = match.group(1)
        else:
            json_str = raw_output  # Fallback if not formatted in markdown
        return json.loads(json_str)
    except Exception as e:
        print(f"OpenAI API Error: {e}")
        return None
    except json.JSONDecodeError as e:
        print(f"JSON Decode Error: {e}")
        print("Raw output:")
        print(raw_output)
        return None

def save_final_json(final_data):
    """Save the final JSON output to FINAL_OUTPUT_FILE."""
    os.makedirs(os.path.dirname(FINAL_OUTPUT_FILE), exist_ok=True)
    with open(FINAL_OUTPUT_FILE, "w") as file:
        json.dump(final_data, file, indent=2)
    print(f"Final JSON saved to {FINAL_OUTPUT_FILE}")

def save_channel_texts(final_data):
    """Save each channel's 'content' to separate text files."""
    for channel, filepath in CHANNEL_FILES.items():
        content = final_data.get(channel, {}).get("content", "")
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w") as file:
            file.write(content)
        print(f"Content for '{channel}' saved to {filepath}")

# -------------------------
# Main Flow
# -------------------------
def create_content_writeup():
    start = time.time()
    # Load inputs from files
    strategy = load_json_file(STRATEGY_FILE)
    product_overview = load_text_file(PRODUCT_OVERVIEW_FILE)
    
    # Construct prompt for Azure OpenAI
    prompt = construct_prompt(strategy, product_overview)
    print("Constructed Prompt:\n", prompt)
    
    # Call Azure OpenAI to generate the structured JSON output
    final_json = call_openai(prompt)
    if final_json is None:
        print("Failed to obtain valid JSON output from Azure OpenAI.")
        exit(1)
    
    # Save the final JSON output
    save_final_json(final_json)
    
    # Save each channel's content into separate text files
    save_channel_texts(final_json)

    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Content_Writer"
    log_step = 15
    log_task_id = "task_015"
    log_status = "completed"
    log_process = "Content"
    log_details = "I have read and understood the approved strategy, thereby i have created a content write-up for each channel and defining the style in which I want the banner and what is to be in it."
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Ephermal_Strategy_Specialist", "Parent_Orchestrator"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________

# create_content_writeup()