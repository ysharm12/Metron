#!/usr/bin/env python3
import os
import re
import json
from openai import AzureOpenAI
#_____ ALWAYS IMPORT________
import logging_agentic_behavior as lab
import tasks_counter
import time
import runtime_tracker
from blueprints_creator import update_process
#___________________________

def generate_strategy_report():
    start = time.time()
    """
    This function reads campaign trigger details and an HTML campaign report,
    builds a detailed prompt for generating a multi-channel campaign strategy,
    calls the Azure OpenAI model (o1-mini) to generate the strategy, and then
    extracts the JSON and HTML outputs (each wrapped in triple backticks).
    Finally, it saves the outputs to the output folder.
    """
    # Paths for input and output files
    trigger_file = os.path.join("input_folder", "trigger.json")
    campaign_report_file = os.path.join("output", "campaign_report.html")
    output_folder = "output"
    json_output_file = os.path.join(output_folder, "strategy_final.json")
    html_output_file = os.path.join(output_folder, "strategy_final.html")

    # Ensure output folder exists
    os.makedirs(output_folder, exist_ok=True)

    # Load trigger data
    with open(trigger_file, "r") as f:
        trigger_data = json.load(f)
    trigger_str = json.dumps(trigger_data, indent=2)

    # Load campaign report HTML
    with open(campaign_report_file, "r") as f:
        campaign_report_html = f.read().strip()

    # Build the prompt using the provided template and inserting our trigger data and campaign report HTML.
    prompt = (
        "EXTREMELY IMPORTANT - LOGICAL FLOW MUST ALWAYS BE A PROCESS DIAGRAM SHOWING PROCESS AND CHAIN OF THOOUGHT THAT LEAD TO IT ALWAYS WITHOUT A DOUBT"
        "KEEP IT VERY DETAILED COVERING EACH PART OF THE COMBINED REPORT. BEAUTIFUL, STUNNING BREATHTAKING MODERN FURUISTIC."
        "VERY IMPORTANT MUST FOLLOW: each channel should be in its own card and on the right hand side of it should be your logical flow explaining in a simplified process diagram what decisions led to that strategy and what data discovery from the HTML data that I'm giving you which has data insights what did you learn from it and what did you implement explaining your reasoning step-by-step and on the right side of that you will have a executive summary of what led to it what was the decision taken and what did you learn for each channel?.\n\n"
        "VERY VERY IMPORTANT: EVERY PART SHOULD HAVE PROPER DIV AND SECTIONS BEAUTIFIES WITH TAILWIND, SUBTLE ANIMATION AND IF THERE ARE SECTIONS AND BULLETPOINTS OUT THEM IN PROPER HTML CODE SO THEY LOOK BEAUTIFUL NOT JUST AS A TEXT"
        "You are a marketing strategy expert. Based on the following HTML report and campaign trigger details, At the top of the document give a metadata saying Optum RX as business, and created by Metron Framework, template blueprint of 2025. You must clearly define in JSON what is the content you want what should be there what message to communicate as per data findings etc."
        "generate a detailed multi-channel campaign strategy for Trigger. "
        "each channel should be in its own card and on the right hand side of it should be your logical flow explaining in a simplified process diagram what decisions led to that strategy and what data discovery from the HTML data that I'm giving you which has data insights what did you learn from it and what did you implement explaining your reasoning step-by-step and on the right side of that you will have a executive summary of what led to it what was the decision taken and what did you learn for each channel?."
        "Use the aggregated data in the report (which includes customer segmentation, historical campaign performance, sentiment trends, "
        "KPI thresholds, and competitor profiles) to guide your strategy.\n\n"
        "NOTE: Be sure to make it beautiful and stunning and professional and everything should be inside a proper DIV or proper tables, etc. clearly making it extremely good at design.\n\n"
        "Campaign Trigger Details (JSON):\n"
        "```json\n" + trigger_str + "\n```\n\n"
        "Campaign Report (HTML):\n"
        "```html\n" + campaign_report_html + "\n```\n\n"
        "For each channel (LinkedIn, Twitter, Instagram, SMS, Direct Mail), provide:\n"
        "  - Objectives: How the channel will contribute to the overall goal.\n"
        "  - Content Recommendations: Specific messaging ideas, tone, and creative direction.\n"
        "  - Scheduling: Recommended posting or sending times and frequency.\n"
        "  - Performance Targets: KPIs that must be met, based on the thresholds provided.\n"
        "  - Specialized Agent Prompt: A concise instruction that will be passed to a dedicated agent for generating content on that channel.\n\n"
        "Additionally, produce an overall summary of key decisions and insights derived from the data (e.g., trends, historical benchmarks, competitor insights) "
        "that justify the strategy. Your output must be in two parts:\n\n"
        "1. **JSON Output** (use backticks to denote the JSON code block) that contains:\n"
        "   - An \"overall\" strategy with campaign details (campaign_id, campaign_name, goal, target_audience, budget, start_date, summary).\n"
        "   - A key for each channel with the details described above.\n\n"
        "2. **HTML Output** (a Tailwind CSS based snippet) that visually displays the overall strategy and each channel’s strategy in a user-friendly format for human review. "
        "The HTML should include sections with headings for each channel and the overall summary, styled for clarity.\n\n"
        "Your final output must include two code blocks:\n\n"
        "Example JSON Output format:\n"
        "```json\n"
        "{\n"
        '  "campaign_strategy": {\n'
        '    "overall": {\n'
        '      "campaign_id": "CAMP001",\n'
        '      "campaign_name": "GET FROM TRIGGER",\n'
        '      "goal": "Increase sales by 20%",\n'
        '      "target_audience": "tech enthusiasts",\n'
        '      "budget": 5000,\n'
        '      "start_date": "2025-09-01",\n'
        '      "summary": "Based on historical performance, rising positive sentiment, and competitor analysis, we recommend a multi-channel approach ..."\n'
        "    },\n"
        '    "LinkedIn": { ... },\n'
        '    "Twitter": { ... },\n'
        '    "Instagram": { ... },\n'
        '    "SMS": { ... },\n'
        '    "DirectMail": { ... }\n'
        "  }\n"
        "}\n"
        "```\n\n"
        "Example HTML Output (Tailwind CSS based):\n"
        "```html\n"
        "<!DOCTYPE html>\n"
        "<html lang=\"en\">\n"
        "<head>\n"
        "  <meta charset=\"UTF-8\">\n"
        "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n"
        "  <title>get title from trigger Report</title>\n"
        "  <link href=\"https://cdn.jsdelivr.net/npm/tailwindcss@2.0.0/dist/tailwind.min.css\" rel=\"stylesheet\">\n"
        "</head>\n"
        "<body class=\"bg-gray-100 p-6\">\n"
        "  <div class=\"max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-6\">\n"
        "    <h1 class=\"text-3xl font-bold mb-4\">Back-to-School Promo Strategy Report</h1>\n"
        "    <!-- Overall Strategy Summary -->\n"
        "    <div class=\"mb-6\">\n"
        "      <h2 class=\"text-2xl font-semibold\">Overall Strategy</h2>\n"
        "      <p class=\"text-gray-700 mt-2\">\n"
        "        <strong>Campaign ID:</strong> CAMP001<br>\n"
        "        <strong>Goal:</strong> Increase sales by 20%<br>\n"
        "        <strong>Target Audience:</strong> tech enthusiasts<br>\n"
        "        <strong>Budget:</strong> $5000<br>\n"
        "        <strong>Start Date:</strong> 2025-09-01<br>\n"
        "        <strong>Summary:</strong> Based on historical performance, rising sentiment trends, and competitor analysis, a multi-channel approach is recommended ...\n"
        "      </p>\n"
        "    </div>\n"
        "    <!-- Channel Strategies -->\n"
        "    <div class=\"grid grid-cols-1 md:grid-cols-2 gap-6\">\n"
        "      <div class=\"p-4 border rounded\">\n"
        "        <h3 class=\"font-bold text-xl\">LinkedIn</h3>\n"
        "        <!-- LinkedIn details go here -->\n"
        "      </div>\n"
        "      <div class=\"p-4 border rounded\">\n"
        "        <h3 class=\"font-bold text-xl\">Twitter</h3>\n"
        "        <!-- Twitter details go here -->\n"
        "      </div>\n"
        "      <div class=\"p-4 border rounded\">\n"
        "        <h3 class=\"font-bold text-xl\">Instagram</h3>\n"
        "        <!-- Instagram details go here -->\n"
        "      </div>\n"
        "      <div class=\"p-4 border rounded\">\n"
        "        <h3 class=\"font-bold text-xl\">SMS</h3>\n"
        "        <!-- SMS details go here -->\n"
        "      </div>\n"
        "      <div class=\"p-4 border rounded\">\n"
        "        <h3 class=\"font-bold text-xl\">Direct Mail</h3>\n"
        "        <!-- Direct Mail details go here -->\n"
        "      </div>\n"
        "    </div>\n"
        "  </div>\n"
        "</body>\n"
        "</html>\n"
        "```\n\n"
        "Provide both outputs in your final response.\n\n"
        "VERY IMPORTANT MUST FOLLOW: each channel should be in its own card and on the right hand side of it should be your logical flow explaining in a simplified process diagram what decisions led to that strategy and what data discovery from the HTML data that I'm giving you which has data insights what did you learn from it and what did you implement explaining your reasoning step-by-step and on the right side of that you will have a executive summary of what led to it what was the decision taken and what did you learn for each channel?."
        "Common Brand Elements:"
        "Logo:"
        "Description: Use the official Optum logo with sufficient clear space."
        "Usage: Ensure the logo remains unaltered in proportion and color."
        "Brand Colors:"
        "Primary: Optum Orange – Hex: #FF612B, RGB: 255,97,43, CMYK: 0,68,96,0, Pantone: 165 C"
        "Secondary: Optum Grey – Hex: #58595B, RGB: 88,89,91, CMYK: 0,2,0,64, Pantone: Cool Gray 11 C"
        "Typography:"
        "Primary Font: Arial (for headlines and banners)"
        "Secondary Font: Helvetica (for body copy and print materials)"
        "Tone & Voice:"
        "Professional, empathetic, clear, and actionable."
        "Imagery Guidelines:"
        "Use high-resolution, consistently filtered images that reflect an innovative yet approachable healthcare brand."
        "EXTREMELY IMPORTANT - LOGICAL FLOW MUST ALWAYS BE A PROCESS DIAGRAM SHOWING PROCESS AND CHAIN OF THOOUGHT THAT LEAD TO IT ALWAYS WITHOUT A DOUBT"
    )

    # Call the Azure OpenAI model (using o1-mini)
    client = AzureOpenAI(
    api_version="2024-06-01",
    azure_endpoint="https://openaiqueryit.openai.azure.com/",
    api_key="2u8gagl8riKy2RhvETKrCavz9N9HbflsTSIZX1ejO3HI8RTUBeqIJQQJ99BBACYeBjFXJ3w3AAABACOGussx"
)
    
    response = client.chat.completions.create(
        model="o1-mini",
        messages=[
            {"role": "assistant", "content": "You are a helpful marketing strategy generator."},
            {"role": "user", "content": prompt}
        ],
        timeout=300
    )

    # Extract the full response text
    full_response = response.choices[0].message.content.strip()

    # Use regex to extract JSON and HTML code blocks wrapped in triple backticks
    import re
    json_pattern = r"```json\s+(.*?)\s+```"
    html_pattern = r"```html\s+(.*?)\s+```"

    json_match = re.search(json_pattern, full_response, re.DOTALL)
    html_match = re.search(html_pattern, full_response, re.DOTALL)

    if json_match:
        json_output = json_match.group(1)
    else:
        raise ValueError("JSON output not found in the response.")

    if html_match:
        html_output = html_match.group(1)
    else:
        raise ValueError("HTML output not found in the response.")

    # Validate JSON (optional)
    try:
        parsed_json = json.loads(json_output)
    except json.JSONDecodeError as e:
        raise ValueError("Extracted JSON is not valid") from e

    # Save outputs to files in the output folder
    json_file_path = os.path.join(output_folder, "strategy_final.json")
    html_file_path = os.path.join(output_folder, "strategy_final.html")

    with open(json_file_path, "w") as f:
        json.dump(parsed_json, f, indent=2)

    with open(html_file_path, "w") as f:
        f.write(html_output)

    
    
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Strategy_Specialist"
    log_step = 14
    log_task_id = "task_014"
    log_status = "completed"
    log_process = "Strategy"
    log_details = "Upon looking at the reports, I have identified the strategy for the campaign. Which is ready to be reviewed by a human."
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Ephermal_Campaign_Overview_Report_Specialist", "Parent_Orchestrator"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________

    print("Strategy generation completed.")
    print(f"JSON strategy saved at: {json_file_path}")
    print(f"HTML strategy saved at: {html_file_path}")

# if __name__ == "__main__":
#     generate_strategy_report()
