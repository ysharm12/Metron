import os
import json
import pandas as pd
import numpy as np
import logging
from collections import Counter, defaultdict
from scipy.stats import linregress

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# -------------------------------
# CRM Interaction Data Processing
# -------------------------------
def generate_crm_summary(csv_path="synthetic_data/crm_interactions.csv"):
    """
    Processes CRM interactions data by counting interaction frequencies and extracting common themes
    from the notes.
    
    Returns:
        dict: A summary containing total interactions, counts per interaction type, and common themes.
    """
    if not os.path.exists(csv_path):
        logger.warning(f"CRM interactions file not found at {csv_path}.")
        return {"total_interactions": 0, "interaction_types": {}, "common_themes": "No data available."}
    
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        logger.error(f"Error reading CRM interactions file: {e}")
        return {"total_interactions": 0, "interaction_types": {}, "common_themes": "Error processing data."}
    
    if df.empty:
        return {"total_interactions": 0, "interaction_types": {}, "common_themes": "No interactions found."}
    
    total_interactions = len(df)
    interaction_types = df['interaction_type'].value_counts().to_dict()
    
    # Extract common themes from 'notes' (simple frequency count of words, excluding common stopwords)
    stopwords = set(["the", "and", "a", "an", "of", "to", "in", "on", "at", "for", "by", "with", "is", "are", "was", "were"])
    all_words = []
    for note in df['notes'].dropna().astype(str):
        words = note.lower().split()
        filtered = [w.strip(".,;:!?") for w in words if w not in stopwords and len(w) > 2]
        all_words.extend(filtered)
    
    if all_words:
        common_words = Counter(all_words).most_common(5)
        common_themes = ", ".join(word for word, count in common_words)
    else:
        common_themes = "No common themes extracted."
    
    crm_summary = {
        "total_interactions": total_interactions,
        "interaction_types": interaction_types,
        "common_themes": common_themes
    }
    logger.debug(f"CRM summary: {crm_summary}")
    return crm_summary

# -------------------------------
# Influencer Data Processing
# -------------------------------
def generate_influencer_summary(csv_path="synthetic_data/influencers.csv"):
    """
    Processes influencer data by filtering and ranking influencers by engagement rate and follower count.
    Targets influencers from California (CA) and Texas (TX) if available; otherwise, selects top overall.
    
    Returns:
        dict: A summary with a campaign placeholder and a list of recommended influencers.
    """
    if not os.path.exists(csv_path):
        logger.warning(f"Influencer file not found at {csv_path}.")
        return {"campaign_id": "N/A", "recommended_influencers": []}
    
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        logger.error(f"Error reading influencers file: {e}")
        return {"campaign_id": "N/A", "recommended_influencers": []}
    
    if df.empty:
        return {"campaign_id": "N/A", "recommended_influencers": []}
    
    # Convert numeric fields
    df['follower_count'] = pd.to_numeric(df['follower_count'], errors='coerce')
    df['engagement_rate'] = pd.to_numeric(df['engagement_rate'], errors='coerce')
    df = df.dropna(subset=['follower_count', 'engagement_rate'])
    
    # Filter for target states (CA and TX) if available
    target_df = df[df['primary_state'].isin(["CA", "TX"])]
    if target_df.empty:
        target_df = df  # fallback to all influencers
    
    # Sort by engagement rate then follower count (both descending)
    target_df = target_df.sort_values(by=["engagement_rate", "follower_count"], ascending=False)
    
    # Pick top 3 influencers
    recommended = target_df.head(3)[["influencer_id", "platform", "follower_count", "engagement_rate", "primary_state"]]
    recommended_list = recommended.to_dict(orient="records")
    
    influencer_summary = {
        "campaign_id": "CAMP001",  # Placeholder campaign ID
        "recommended_influencers": recommended_list
    }
    logger.debug(f"Influencer summary: {influencer_summary}")
    return influencer_summary

# -------------------------------
# Sentiment Data Processing
# -------------------------------
def generate_sentiment_summary(json_path="synthetic_data/sentiments.json"):
    """
    Processes sentiment data by aggregating average sentiment scores per state and overall.
    
    Returns:
        dict: A mapping of state to average sentiment and overall average.
    """
    if not os.path.exists(json_path):
        logger.warning(f"Sentiment file not found at {json_path}.")
        return {"overall_avg_sentiment": None, "state_sentiment": {}}
    
    try:
        with open(json_path, "r") as f:
            data = json.load(f)
    except Exception as e:
        logger.error(f"Error reading sentiment file: {e}")
        return {"overall_avg_sentiment": None, "state_sentiment": {}}
    
    if not data:
        return {"overall_avg_sentiment": None, "state_sentiment": {}}
    
    sentiments = [entry.get("sentiment_score", 0) for entry in data if entry.get("sentiment_score") is not None]
    overall_avg = np.mean(sentiments) if sentiments else None
    
    # Group by state
    state_groups = defaultdict(list)
    for entry in data:
        state = entry.get("state", "Unknown")
        score = entry.get("sentiment_score")
        if score is not None:
            state_groups[state].append(score)
    state_sentiment = {state: round(np.mean(scores), 3) for state, scores in state_groups.items()}
    
    sentiment_summary = {
        "overall_avg_sentiment": round(overall_avg, 3) if overall_avg is not None else None,
        "state_sentiment": state_sentiment
    }
    logger.debug(f"Sentiment summary: {sentiment_summary}")
    return sentiment_summary

# -------------------------------
# Social Media Analytics Processing
# -------------------------------
def generate_social_media_summary(csv_path="synthetic_data/social_media_analytics.csv"):
    """
    Processes social media analytics data by computing engagement rates and aggregating
    performance metrics per campaign and platform.
    
    Returns:
        dict: A mapping per campaign with overall average engagement rate and platform breakdown.
    """
    if not os.path.exists(csv_path):
        logger.warning(f"Social media analytics file not found at {csv_path}.")
        return {}
    
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        logger.error(f"Error reading social media analytics file: {e}")
        return {}
    
    if df.empty:
        return {}
    
    # Ensure numeric fields
    for col in ['impressions', 'likes', 'shares', 'comments']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df.dropna(subset=['impressions', 'likes', 'shares', 'comments'], inplace=True)
    
    # Calculate engagement rate per post: (likes+shares+comments) / impressions
    df['engagement_rate'] = (df['likes'] + df['shares'] + df['comments']) / df['impressions']
    
    # Group by campaign and then by platform
    campaign_summary = {}
    for campaign_id, group in df.groupby("campaign_id"):
        overall_eng_rate = group['engagement_rate'].mean()
        platform_breakdown = {}
        for platform, sub in group.groupby("platform"):
            total_impressions = sub['impressions'].sum()
            avg_eng_rate = sub['engagement_rate'].mean() if total_impressions > 0 else 0
            platform_breakdown[platform] = {
                "impressions": int(total_impressions),
                "engagement_rate": round(avg_eng_rate, 3)
            }
        campaign_summary[campaign_id] = {
            "average_engagement_rate": round(overall_eng_rate, 3),
            "platform_breakdown": platform_breakdown
        }
    logger.debug(f"Social media summary: {campaign_summary}")
    return campaign_summary

# -------------------------------
# Overall Report Generation
# -------------------------------
def generate_overall_report():
    """
    Combines the summaries from CRM, Influencer, Sentiment, and Social Media data into an
    in-depth multi-line overall report. The report is designed to help campaign strategists.
    
    Returns:
        str: The overall multi-line report.
    """
    crm_summary = generate_crm_summary()
    influencer_summary = generate_influencer_summary()
    sentiment_summary = generate_sentiment_summary()
    social_summary = generate_social_media_summary()
    
    report_lines = []
    report_lines.append("=== Overall Campaign Data Analysis Report ===")
    report_lines.append("")
    
    # CRM Section
    report_lines.append("CRM Interactions Summary:")
    report_lines.append(f"  Total Interactions: {crm_summary.get('total_interactions', 'N/A')}")
    report_lines.append(f"  Interaction Types: {crm_summary.get('interaction_types', {})}")
    report_lines.append(f"  Common Themes: {crm_summary.get('common_themes', 'N/A')}")
    report_lines.append("")
    
    # Influencer Section
    report_lines.append("Influencer Recommendations:")
    recs = influencer_summary.get("recommended_influencers", [])
    if recs:
        for rec in recs:
            report_lines.append(f"  - {rec.get('influencer_id')} on {rec.get('platform')}: {rec.get('follower_count')} followers, engagement rate {rec.get('engagement_rate')}%, state {rec.get('primary_state')}")
    else:
        report_lines.append("  No influencer recommendations available.")
    report_lines.append("")
    
    # Sentiment Section
    report_lines.append("Sentiment Analysis:")
    overall_sent = sentiment_summary.get("overall_avg_sentiment", "N/A")
    report_lines.append(f"  Overall Average Sentiment: {overall_sent}")
    state_sent = sentiment_summary.get("state_sentiment", {})
    if state_sent:
        report_lines.append("  Average Sentiment by State:")
        for state, avg in state_sent.items():
            report_lines.append(f"    - {state}: {avg}")
    else:
        report_lines.append("  No state-level sentiment data available.")
    report_lines.append("")
    
    # Social Media Section
    report_lines.append("Social Media Analytics Summary:")
    if social_summary:
        for campaign_id, details in social_summary.items():
            report_lines.append(f"  Campaign {campaign_id}:")
            report_lines.append(f"    Average Engagement Rate: {details.get('average_engagement_rate', 'N/A')}")
            pb = details.get("platform_breakdown", {})
            if pb:
                report_lines.append("    Platform Breakdown:")
                for platform, metrics in pb.items():
                    report_lines.append(f"      - {platform}: {metrics.get('impressions')} impressions, engagement rate {metrics.get('engagement_rate')}")
            else:
                report_lines.append("    No platform breakdown available.")
    else:
        report_lines.append("  No social media data available.")
    
    report_lines.append("")
    report_lines.append("Overall Recommendations:")
    # Provide simple recommendations based on available data:
    if crm_summary.get("total_interactions", 0) > 0:
        report_lines.append("  - Leverage common CRM themes to improve customer support and follow-up.")
    if influencer_summary.get("recommended_influencers"):
        report_lines.append("  - Consider partnering with top influencers to amplify campaign reach.")
    if overall_sent is not None and overall_sent < 0:
        report_lines.append("  - Address negative sentiment trends through targeted customer engagement initiatives.")
    if social_summary:
        report_lines.append("  - Optimize social media channels with high engagement rates for improved ROI.")
    else:
        report_lines.append("  - Review data gaps for social media performance to improve targeting.")
    
    overall_report = "\n".join(report_lines)
    logger.debug("Generated overall report.")
    return overall_report

def append_overall_report(report_text, output_filepath="output/combined_text_data_report.txt"):
    """
    Appends the provided multi-line report text to the specified file.
    If the file exists, the new report is appended; otherwise, a new file is created.
    
    Returns:
        str: The updated file content.
    """
    if os.path.exists(output_filepath):
        with open(output_filepath, "r") as f:
            current_content = f.read()
    else:
        current_content = ""
    
    updated_content = current_content + "\n\n" + report_text + "\n"
    with open(output_filepath, "w") as f:
        f.write(updated_content)
    logger.info(f"Overall report appended to {output_filepath}")
    return updated_content

def create_campaign_overview_report():
    output_folder = "output"
    os.makedirs(output_folder, exist_ok=True)
    report_file = os.path.join(output_folder, "combined_text_data_report.txt")
    
    overall_report = generate_overall_report()
    append_overall_report(overall_report, report_file)
    
    print("=== Overall Campaign Data Analysis Report ===")
    print(overall_report)

# if __name__ == "__main__":
#     main()
