#!/usr/bin/env python3
"""
This script generates synthetic KPI threshold data for the marketing PoC.
It creates a JSON file with sample KPI thresholds that the Performance Analysis
Agent will use to compare campaign metrics against business standards.
"""

import os
import json

# Define the directory for synthetic data
DATA_FOLDER = "synthetic_data"
if not os.path.exists(DATA_FOLDER):
    os.makedirs(DATA_FOLDER)

# Define sample KPI thresholds
kpi_thresholds = {
    "email": {
        "ctr_min": 0.03,           # Minimum click-through rate
        "open_rate_min": 0.25,     # Minimum open rate (25%)
        "bounce_rate_max": 0.10,   # Maximum bounce rate (10%)
        "conversion_rate_min": 0.02  # Minimum conversion rate (2%)
    },
    "social": {
        "engagement_rate_min": 0.05  # Minimum social engagement rate (5%)
    },
    "ad": {
        "roi_min": 2.0  # Minimum return on investment (2:1 ratio)
    }
}

# Write the KPI thresholds to a JSON file
kpi_file_path = os.path.join(DATA_FOLDER, "kpi_thresholds.json")
with open(kpi_file_path, "w") as f:
    json.dump(kpi_thresholds, f, indent=2)

print(f"KPI threshold data generated successfully at: {kpi_file_path}")
