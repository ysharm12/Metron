#!/usr/bin/env python3
"""
This script generates synthetic data for a full-fledged marketing AI PoC.
It creates multiple files in the 'synthetic_data' folder with correlations
and simulated foreign keys.
"""

import os
import csv
import json
import random
from datetime import datetime, timedelta
from faker import Faker

fake = Faker()
random.seed(42)

# Create synthetic_data folder if it doesn't exist
DATA_FOLDER = "synthetic_data"
if not os.path.exists(DATA_FOLDER):
    os.makedirs(DATA_FOLDER)

# -------------------------------
# 1. Customer Segmentation Data
# -------------------------------

# Generate customers.csv: each row contains customer_id, name, age, gender, state, segment, purchase history
num_customers = 1000
states = ["CA", "NY", "TX", "FL", "IL", "PA", "OH", "MI", "GA", "NC"]
segments = ["Urban Millennials", "High-Value Customers", "Budget Buyers", "Frequent Spenders", "Occasional Buyers"]
customers = []

with open(os.path.join(DATA_FOLDER, "customers.csv"), mode="w", newline="") as file:
    fieldnames = ["customer_id", "name", "age", "gender", "state", "segment", "num_purchases", "total_spent", "last_purchase_date"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(1000):
        customer_id = f"CUST{i+1000}"
        name = fake.name()
        age = random.randint(18, 80)
        gender = random.choice(["M", "F", "Non-binary"])
        state = random.choice(states)
        segment = random.choice(segments)
        num_purchases = random.randint(0, 20)
        total_spent = num_purchases * random.randint(20, 500)
        last_purchase = fake.date_between(start_date="-2y", end_date="today").strftime("%Y-%m-%d")
        customer = {
            "customer_id": customer_id,
            "name": name,
            "age": age,
            "gender": gender,
            "state": state,
            "segment": segment,
            "num_purchases": num_purchases,
            "total_spent": total_spent,
            "last_purchase_date": last_purchase
        }
        customers.append(customer)
        writer.writerow(customer)

# Also save segmentation definitions in segments.json
segments_def = {
    "segments": [
        {"name": "Urban Millennials", "criteria": "Age 18-35, urban areas, high social engagement"},
        {"name": "High-Value Customers", "criteria": "Total spent > $5000, frequent purchases"},
        {"name": "Budget Buyers", "criteria": "Low spending, price-sensitive"},
        {"name": "Frequent Spenders", "criteria": "High purchase frequency regardless of amount"},
        {"name": "Occasional Buyers", "criteria": "Low frequency, sporadic purchases"}
    ]
}
with open(os.path.join(DATA_FOLDER, "segments.json"), "w") as f:
    json.dump(segments_def, f, indent=2)

# -------------------------------
# 2. Sentiment Analysis Data
# -------------------------------

# Generate sentiment.json: a JSON array with individual sentiment entries (linked to a random customer)
sentiments = []
for i in range(500):
    entry = {
        "entry_id": f"SENT{i+1}",
        "customer_id": random.choice(customers)["customer_id"],
        "state": random.choice(states),
        "sentiment_score": round(random.uniform(-1, 1), 2),
        "comment": fake.sentence(nb_words=12),
        "date": (datetime.now() - timedelta(days=random.randint(0, 365))).strftime("%Y-%m-%d")
    }
    sentiments.append(entry)
with open(os.path.join(DATA_FOLDER, "sentiment.json"), "w") as f:
    json.dump(sentiments, f, indent=2)

# Generate sentiment_trends.csv: daily sentiment summary (date, avg_sentiment, volume)
start_date = datetime.now() - timedelta(days=365)
end_date = datetime.now()
delta = (end_date - start_date).days
with open(os.path.join(DATA_FOLDER, "sentiment_trends.csv"), mode="w", newline="") as file:
    fieldnames = ["date", "avg_sentiment", "volume"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(delta+1):
        day = (start_date + timedelta(days=i)).strftime("%Y-%m-%d")
        # Simulate average sentiment and volume
        avg_sent = round(random.uniform(-0.2, 0.8), 2)
        volume = random.randint(50, 150)
        writer.writerow({"date": day, "avg_sentiment": avg_sent, "volume": volume})

# -------------------------------
# 3. Campaign Performance History Data
# -------------------------------

# Generate historical_campaigns.csv: campaign_id, objective, start_date, end_date, channel, target_segment, budget, impressions, clicks, conversions, state (simulate state-specific performance)
num_campaigns = 50
campaigns = []
with open(os.path.join(DATA_FOLDER, "historical_campaigns.csv"), mode="w", newline="") as file:
    fieldnames = ["campaign_id", "objective", "start_date", "end_date", "channel", "target_segment", "budget", "impressions", "clicks", "conversions", "top_state"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(num_campaigns):
        campaign_id = f"CAMP{i+1:03d}"
        objective = random.choice(["Awareness", "Conversion", "Retention", "Upsell"])
        start_date = fake.date_between(start_date="-2y", end_date="-1y")
        end_date = fake.date_between(start_date=start_date, end_date="today")
        channel = random.choice(["Email", "Social", "DirectMail", "SMS"])
        target_segment = random.choice(segments)
        budget = random.randint(1000, 20000)
        impressions = random.randint(10000, 1000000)
        clicks = int(impressions * random.uniform(0.01, 0.1))
        conversions = int(clicks * random.uniform(0.05, 0.2))
        top_state = random.choice(states)
        campaign = {
            "campaign_id": campaign_id,
            "objective": objective,
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date": end_date.strftime("%Y-%m-%d"),
            "channel": channel,
            "target_segment": target_segment,
            "budget": budget,
            "impressions": impressions,
            "clicks": clicks,
            "conversions": conversions,
            "top_state": top_state
        }
        campaigns.append(campaign)
        writer.writerow(campaign)

# -------------------------------
# 4. Brand Guidelines & Compliance Rules Data
# -------------------------------

brand_guidelines = {
    "brand": "YourBrand",
    "tone": "Friendly, professional, and concise",
    "logo_usage": "Use the official logo with 20px clear space",
    "color_palette": {"primary": "#1D4ED8", "secondary": "#F59E0B", "accent": "#10B981"},
    "legal_disclaimers": {"email": "You can unsubscribe at any time", "sms": "Standard messaging rates apply"},
    "forbidden_phrases": ["free trial", "unlimited access"],
    "compliance_rules": {"CA": "Include California-specific disclaimer", "NY": "NY residents: special disclaimer"}
}
with open(os.path.join(DATA_FOLDER, "brand_guidelines.json"), "w") as f:
    json.dump(brand_guidelines, f, indent=2)

# -------------------------------
# 5. Competitor Analysis and Market Research Data
# -------------------------------

competitors = []
for i in range(10):
    competitor = {
        "competitor_id": f"COMP{i+1:02d}",
        "name": f"Competitor {chr(65+i)}",
        "industry": random.choice(["CRM", "Analytics", "Marketing Automation"]),
        "pricing": f"${random.randint(50,200)}/month",
        "marketing_strategy": random.choice(["Aggressive discounts", "Premium branding", "Value-based messaging"]),
        "recent_news": fake.sentence(nb_words=15)
    }
    competitors.append(competitor)
with open(os.path.join(DATA_FOLDER, "competitor_profiles.json"), "w") as f:
    json.dump({"competitors": competitors}, f, indent=2)

# -------------------------------
# 6. Influencer Marketing Data
# -------------------------------

with open(os.path.join(DATA_FOLDER, "influencers.csv"), mode="w", newline="") as file:
    fieldnames = ["influencer_id", "name", "platform", "follower_count", "engagement_rate", "primary_state"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(50):
        influencer_id = f"INFL{i+1:03d}"
        name = fake.name()
        platform = random.choice(["Instagram", "YouTube", "TikTok"])
        follower_count = random.randint(50000, 500000)
        engagement_rate = round(random.uniform(1, 15), 1)
        primary_state = random.choice(states)
        writer.writerow({
            "influencer_id": influencer_id,
            "name": name,
            "platform": platform,
            "follower_count": follower_count,
            "engagement_rate": engagement_rate,
            "primary_state": primary_state
        })

# -------------------------------
# 7. Advertising Spend and Attribution Data
# -------------------------------

with open(os.path.join(DATA_FOLDER, "advertising_spend.csv"), mode="w", newline="") as file:
    fieldnames = ["date", "campaign_id", "channel", "spend", "clicks", "conversions", "state"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(200):
        date = (datetime.now() - timedelta(days=random.randint(0, 365))).strftime("%Y-%m-%d")
        campaign = random.choice(campaigns)
        campaign_id = campaign["campaign_id"]
        channel = random.choice(["SEM", "Social", "TV", "Display"])
        spend = random.randint(200, 5000)
        clicks = int(spend * random.uniform(0.05, 0.2))
        conversions = int(clicks * random.uniform(0.05, 0.2))
        state = random.choice(states)
        writer.writerow({
            "date": date,
            "campaign_id": campaign_id,
            "channel": channel,
            "spend": spend,
            "clicks": clicks,
            "conversions": conversions,
            "state": state
        })

# -------------------------------
# 8. CRM Customer Interaction Data
# -------------------------------

with open(os.path.join(DATA_FOLDER, "crm_interactions.csv"), mode="w", newline="") as file:
    fieldnames = ["interaction_id", "customer_id", "date", "interaction_type", "notes"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    interaction_types = ["email", "phone", "web_visit", "purchase", "support_call"]
    for i in range(1500):
        interaction_id = f"INT{i+1:05d}"
        customer = random.choice(customers)
        customer_id = customer["customer_id"]
        date = (datetime.now() - timedelta(days=random.randint(0, 730))).strftime("%Y-%m-%d")
        interaction_type = random.choice(interaction_types)
        notes = fake.sentence(nb_words=10)
        writer.writerow({
            "interaction_id": interaction_id,
            "customer_id": customer_id,
            "date": date,
            "interaction_type": interaction_type,
            "notes": notes
        })

# -------------------------------
# 9. Marketing Automation Logs and Triggers Data
# -------------------------------

with open(os.path.join(DATA_FOLDER, "automation_logs.csv"), mode="w", newline="") as file:
    fieldnames = ["log_id", "timestamp", "campaign_id", "event_type", "details"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(500):
        log_id = f"LOG{i+1:05d}"
        timestamp = (datetime.now() - timedelta(minutes=random.randint(0, 1440))).strftime("%Y-%m-%d %H:%M:%S")
        campaign = random.choice(campaigns)
        campaign_id = campaign["campaign_id"]
        event_type = random.choice(["email_sent", "email_opened", "link_clicked", "sms_sent", "webinar_signup"])
        details = fake.sentence(nb_words=8)
        writer.writerow({
            "log_id": log_id,
            "timestamp": timestamp,
            "campaign_id": campaign_id,
            "event_type": event_type,
            "details": details
        })

# -------------------------------
# 10. Social Media Analytics and Engagement Data
# -------------------------------

with open(os.path.join(DATA_FOLDER, "social_media_analytics.csv"), mode="w", newline="") as file:
    fieldnames = ["post_id", "campaign_id", "platform", "datetime", "impressions", "likes", "shares", "comments"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(300):
        post_id = f"POST{i+1:04d}"
        campaign = random.choice(campaigns)
        campaign_id = campaign["campaign_id"]
        platform = random.choice(["Twitter", "LinkedIn", "Facebook"])
        dt = (datetime.now() - timedelta(days=random.randint(0, 365), hours=random.randint(0,23))).strftime("%Y-%m-%d %H:%M:%S")
        impressions = random.randint(1000, 50000)
        likes = int(impressions * random.uniform(0.01, 0.1))
        shares = int(impressions * random.uniform(0.005, 0.05))
        comments = int(impressions * random.uniform(0.002, 0.02))
        writer.writerow({
            "post_id": post_id,
            "campaign_id": campaign_id,
            "platform": platform,
            "datetime": dt,
            "impressions": impressions,
            "likes": likes,
            "shares": shares,
            "comments": comments
        })

# -------------------------------
# 11. A/B Testing Results Data
# -------------------------------

with open(os.path.join(DATA_FOLDER, "ab_testing_results.csv"), mode="w", newline="") as file:
    fieldnames = ["test_id", "campaign_id", "description", "variant_A_metric", "variant_B_metric", "winning_variant", "confidence"]
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(100):
        test_id = f"TEST{i+1:03d}"
        campaign = random.choice(campaigns)
        campaign_id = campaign["campaign_id"]
        description = random.choice(["Subject Line Test", "CTA Button Test", "Image Layout Test", "Offer Messaging Test"])
        variant_A_metric = round(random.uniform(0.01, 0.1), 3)
        variant_B_metric = round(random.uniform(0.01, 0.1), 3)
        winning_variant = "A" if variant_A_metric >= variant_B_metric else "B"
        confidence = random.randint(80, 99)
        writer.writerow({
            "test_id": test_id,
            "campaign_id": campaign_id,
            "description": description,
            "variant_A_metric": variant_A_metric,
            "variant_B_metric": variant_B_metric,
            "winning_variant": winning_variant,
            "confidence": f"{confidence}%"
        })

print("Synthetic data generated successfully in the 'synthetic_data' folder.")
