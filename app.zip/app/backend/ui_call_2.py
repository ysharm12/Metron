
import sys
import os
import logging
import traceback

# Set up logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("ui_call_2")

# Add the current directory to the path so we can import our modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    logger.info("Starting next steps in the workflow...")
    
    # Import the modules
    logger.info("Importing modules...")
    from s2_1_strategy import generate_strategy_report
    from s3_1_content_writeup import create_content_writeup
    from s4_1_banner_creation import start_banner_creation
    
    # Run the functions
    logger.info("Generating strategy report...")
    generate_strategy_report()
    
    logger.info("Creating content writeup...")
    create_content_writeup()
    
    logger.info("Starting banner creation...")
    start_banner_creation()
    
    logger.info("All steps completed successfully!")
    
    # Create a success file to indicate completion
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "output", "workflow_complete.txt"), "w") as f:
        f.write("Workflow completed successfully at " + str(logging.Formatter().formatTime(logging.LogRecord("ui_call_2", logging.INFO, "", 0, "", (), None))))
    
except Exception as e:
    logger.error(f"Error in workflow: {str(e)}")
    logger.error(traceback.format_exc())
    
    # Create an error file with details
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "output", "workflow_error.txt"), "w") as f:
        f.write(f"Error in workflow: {str(e)}\n\n{traceback.format_exc()}")
    
    sys.exit(1)
