import os
import json
from collections import defaultdict, Counter

def generate_competitor_summary():
    # Load competitor data from the JSON file in the synthetic_data folder
    file_path = os.path.join("synthetic_data", "competitor_profiles.json")
    with open(file_path, "r") as f:
        data = json.load(f)
    competitors = data.get("competitors", [])
    
    total_competitors = len(competitors)
    
    # Group competitors by industry and extract pricing as a numeric value
    industry_data = defaultdict(list)
    for comp in competitors:
        industry = comp.get("industry", "Unknown")
        pricing_str = comp.get("pricing", "$0/month")
        try:
            # Remove the '$' sign and '/month', then convert to float
            price_value = float(pricing_str.strip("$").split("/")[0])
        except Exception:
            price_value = 0.0
        comp["price_value"] = price_value
        industry_data[industry].append(comp)
    
    # Build aggregated insights per industry
    industry_summary_lines = []
    for industry, comps in industry_data.items():
        count = len(comps)
        avg_price = sum(c["price_value"] for c in comps) / count if count > 0 else 0
        strategies = [c.get("marketing_strategy", "N/A") for c in comps]
        common_strategy = Counter(strategies).most_common(1)[0][0] if strategies else "N/A"
        industry_summary_lines.append(
            f"- {industry}: Count = {count}, Average Pricing = ${avg_price:.2f}/month, "
            f"Common Strategy = {common_strategy}"
        )
    
    # Build individual competitor details summary
    competitor_details_lines = []
    for comp in competitors:
        details = (
            f"{comp.get('name')} ({comp.get('industry')}): Pricing = {comp.get('pricing')}, "
            f"Strategy = {comp.get('marketing_strategy')}, Recent News = {comp.get('recent_news')}"
        )
        competitor_details_lines.append(f"- {details}")
    
    # Assemble the final multi-line summary string
    summary_lines = [
        "Competitor Data Analysis Summary:",
        "-----------------------------------",
        f"Total Competitors: {total_competitors}",
        "",
        "Industry Overview:",
    ]
    summary_lines.extend(industry_summary_lines)
    summary_lines.append("")
    summary_lines.append("Individual Competitor Details:")
    summary_lines.extend(competitor_details_lines)
    
    return "\n".join(summary_lines)

