import os
import json
import pandas as pd
import numpy as np
import logging
from scipy.stats import linregress

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def process_advertising_spend(csv_path, conv_rate_threshold=0.05):
    """
    Reads advertising spend data from a CSV file, aggregates it by campaign and channel,
    and computes key metrics:
      - Average spend (mean of spend values)
      - Conversion rate (total conversions divided by total clicks)
      - Effective states (states in which the average conversion rate meets or exceeds a threshold)
    
    Returns:
        list: A list of JSON snippets with aggregated metrics.
    """
    if not os.path.exists(csv_path):
        logger.warning(f"CSV file not found at {csv_path}. Returning empty list.")
        return []
    
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        logger.error(f"Error reading CSV file: {e}")
        return []
    
    if df.empty:
        logger.warning("CSV file is empty.")
        return []
    
    required_cols = {"date", "campaign_id", "channel", "spend", "clicks", "conversions", "state"}
    if not required_cols.issubset(set(df.columns)):
        logger.warning("CSV file is missing required columns.")
        return []
    
    # Ensure numeric columns are numeric
    for col in ['spend', 'clicks', 'conversions']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # Group by campaign_id and channel
    aggregated = []
    group = df.groupby(["campaign_id", "channel"])
    for (campaign_id, channel), group_df in group:
        avg_spend = group_df['spend'].mean()
        total_clicks = group_df['clicks'].sum()
        total_conversions = group_df['conversions'].sum()
        conversion_rate = total_conversions / total_clicks if total_clicks > 0 else 0
        
        # For geo-analysis, group by state in this aggregated group.
        states_group = group_df.groupby("state").agg({
            "clicks": "sum",
            "conversions": "sum"
        }).reset_index()
        effective_states = []
        for _, row in states_group.iterrows():
            st_clicks = row["clicks"]
            st_conversions = row["conversions"]
            st_conv_rate = st_conversions / st_clicks if st_clicks > 0 else 0
            if st_conv_rate >= conv_rate_threshold:
                effective_states.append(row["state"])
        
        snippet = {
            "campaign_id": campaign_id,
            "channel": channel,
            "average_spend": round(avg_spend, 2),
            "conversion_rate": round(conversion_rate, 3),
            "effective_states": effective_states
        }
        aggregated.append(snippet)
        logger.debug(f"Aggregated data for {campaign_id} ({channel}): {snippet}")
    
    return aggregated

def generate_overall_ml_analysis(df):
    """
    Performs an overall ML/statistical analysis on the advertising spend data.
    For each channel, it computes:
      - The average spend,
      - Overall conversion rate,
      - Trend analysis via linear regression of spend over time.
    It also performs a geo‐analysis to determine which states have the highest conversion rates.
    
    Returns:
        str: A multi-line analysis report.
    """
    if df.empty:
        return "No advertising spend data available for overall analysis."
    
    analysis_lines = []
    analysis_lines.append("=== In-Depth Advertising Spend Analysis ===")
    channels = df['channel'].unique()
    for channel in channels:
        df_channel = df[df['channel'] == channel].copy()
        # Ensure date column is datetime
        try:
            df_channel['date'] = pd.to_datetime(df_channel['date'], errors='coerce')
            df_channel = df_channel.dropna(subset=['date'])
        except Exception as e:
            logger.error(f"Error processing dates for channel {channel}: {e}")
            continue
        if df_channel.empty:
            continue
        df_channel = df_channel.sort_values("date")
        # Convert dates to ordinal for regression analysis
        df_channel['date_ordinal'] = df_channel['date'].apply(lambda x: x.toordinal())
        slope, intercept, r_value, p_value, std_err = linregress(df_channel['date_ordinal'], df_channel['spend'])
        avg_spend = df_channel['spend'].mean()
        total_clicks = df_channel['clicks'].sum()
        total_conversions = df_channel['conversions'].sum()
        conv_rate = total_conversions / total_clicks if total_clicks > 0 else 0
        
        analysis_lines.append(f"Channel: {channel}")
        analysis_lines.append(f"  - Average Spend: {avg_spend:.2f}")
        analysis_lines.append(f"  - Overall Conversion Rate: {conv_rate:.3f}")
        analysis_lines.append(f"  - Spend Trend: slope = {slope:.2f}, p-value = {p_value:.3f} (r = {r_value:.2f})")
        if p_value < 0.05:
            analysis_lines.append("  - Trend is statistically significant.")
        else:
            analysis_lines.append("  - Trend is not statistically significant.")
        analysis_lines.append("")
    
    # Geo-analysis: aggregate conversion rates by state
    states_group = df.groupby("state").agg({
        "clicks": "sum",
        "conversions": "sum"
    }).reset_index()
    states_group["conversion_rate"] = states_group.apply(lambda r: r["conversions"]/r["clicks"] if r["clicks"] > 0 else 0, axis=1)
    top_states = states_group.sort_values("conversion_rate", ascending=False).head(3)
    analysis_lines.append("Top States by Conversion Rate:")
    for _, row in top_states.iterrows():
        analysis_lines.append(f"  - {row['state']}: Conversion Rate = {row['conversion_rate']:.3f}")
    
    return "\n".join(analysis_lines)

def append_analysis_report(report_text, output_filepath):
    """
    Appends the provided multi-line report text to the given output file.
    If the file already exists, the new report is appended to the end.
    """
    if os.path.exists(output_filepath):
        with open(output_filepath, "r") as f:
            current_content = f.read()
    else:
        current_content = ""
    
    updated_content = current_content + "\n\n" + report_text + "\n"
    with open(output_filepath, "w") as f:
        f.write(updated_content)
    logger.info(f"Analysis report appended to {output_filepath}")
    return updated_content

def create_advertising_spend_report():
    # Define file paths
    csv_path = os.path.join("synthetic_data", "advertising_spend.csv")
    output_folder = "output"
    os.makedirs(output_folder, exist_ok=True)
    final_report_file = os.path.join(output_folder, "combined_text_data_report.txt")
    
    # Process advertising spend data to generate aggregated JSON snippets.
    aggregated_snippets = process_advertising_spend(csv_path)
    
    # Save aggregated snippets for reference.
    aggregated_json_file = os.path.join(output_folder, "advertising_spend_summary.json")
    with open(aggregated_json_file, "w") as f:
        json.dump(aggregated_snippets, f, indent=4)
    logger.info(f"Aggregated advertising spend summary saved to {aggregated_json_file}")
    
    # Load the CSV data into a DataFrame for overall ML analysis.
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        logger.error(f"Error reading CSV for overall analysis: {e}")
        df = pd.DataFrame()
    
    # Convert necessary columns to numeric and ensure dates are present.
    for col in ['spend', 'clicks', 'conversions']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df.dropna(subset=['spend', 'clicks', 'conversions', 'date'], inplace=True)
    
    overall_analysis = generate_overall_ml_analysis(df)
    
    # Append the overall analysis to the combined report file.
    append_analysis_report(overall_analysis, final_report_file)
    
    # For demonstration, print the overall analysis.
    print("=== Overall In-Depth Advertising Spend Analysis ===")
    print(overall_analysis)

# if __name__ == "__main__":
#     main()
