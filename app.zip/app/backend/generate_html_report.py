import os
import json
import re
import openai
from openai import AzureOpenAI

client = AzureOpenAI(
    api_version="2024-06-01",
    azure_endpoint="https://openaiqueryit.openai.azure.com/",
    api_key="2u8gagl8riKy2RhvETKrCavz9N9HbflsTSIZX1ejO3HI8RTUBeqIJQQJ99BBACYeBjFXJ3w3AAABACOGussx"
)

def generate_html_report():
    """
    Reads the combined report and trigger data, sends them to Azure OpenAI to generate a complete HTML report
    styled with Tailwind CSS, and saves the output in the 'output' folder. The generated HTML is expected to be
    wrapped in markdown code blocks using triple backticks and the "html" tag.
    
    Returns:
        str: The generated HTML report (including markdown backticks).
    """
    # Read the combined report text from the output folder
    combined_file_path = os.path.join("output", "combined_text_data_report.txt")
    if not os.path.exists(combined_file_path):
        raise FileNotFoundError(f"Combined text file not found at {combined_file_path}")
    with open(combined_file_path, "r") as f:
        combined_text = f.read()
    
    # Read the trigger data from trigger.json
    trigger_file = "input_folder/trigger.json"
    if not os.path.exists(trigger_file):
        raise FileNotFoundError(f"Trigger file not found: {trigger_file}")
    with open(trigger_file, "r") as f:
        trigger_data = json.load(f)
    
    # Construct a detailed prompt for generating the HTML report.
    prompt = f"""
        KEEP IT VERY DETAILED COVERING EACH PART OF THE COMBINED REPORT. BEAUTIFUL, STUNNING BREATHTAKING MODERN FURUISTIC.
        You are an expert web designer and technical writer. Using Tailwind CSS, generate a complete, human-readable HTML report for a marketing campaign automation system.
        The HTML report must be wrapped in markdown code blocks using triple backticks and the "html" tag exactly as shown below:

        VERY VERY IMPORTANT: EVERY PART SHOULD HAVE PROPER DIV AND SECTIONS BEAUTIFIES WITH TAILWIND, SUBTLE ANIMATION AND IF THERE ARE SECTIONS AND BULLETPOINTS OUT THEM IN PROPER HTML CODE SO THEY LOOK BEAUTIFUL NOT JUST AS A TEXT


        ```html
        <!DOCTYPE html>
        <html lang="en">
        <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Marketing Campaign Automation Report</title>
        <!-- Include Tailwind CSS from CDN -->
        <script src="https://cdn.tailwindcss.com"></script>
        </head>
        <body class="bg-gray-50 p-6">
        <!-- Report content goes here -->
        </body>
        </html>
        ```

        DESIGN GUIDELINES:
        ;';
        Common Brand Elements:
        Logo:
        Description: Use the official Optum logo with sufficient clear space.
        Usage: Ensure the logo remains unaltered in proportion and color.
        Brand Colors:
        Primary: Optum Orange – Hex: #FF612B, RGB: 255,97,43, CMYK: 0,68,96,0, Pantone: 165 C
        Secondary: Optum Grey – Hex: #58595B, RGB: 88,89,91, CMYK: 0,2,0,64, Pantone: Cool Gray 11 C
        Typography:
        Primary Font: Arial (for headlines and banners)
        Secondary Font: Helvetica (for body copy and print materials)
        Tone & Voice:
        Professional, empathetic, clear, and actionable.
        Imagery Guidelines:
        Use high-resolution, consistently filtered images that reflect an innovative yet approachable healthcare brand.
        ;';

        At the top of the document give a metadata saying Optum RX as business, and created by Metron Framework, template blueprint of 2025.

        TAKE YOUR TIME AND CREATE A BEAUTIFUL STUNNING REPORT. PROPERLY SECTIONED WITH SUMMARY OF ALL FINDINGS AT THE END AND HOW THEY COULD WHEY IN ON THE CREATION OF STRATEGY AFTER FOR MULTI CHANNEL (LINKEDIN< INSTAGRAM< TWITTER< SMS< DIRECT MAIL).

        WHEN CREATING SUMMARY AND INSIGHTS CREATE IT FROM THE PERSPECTIVE OF OPTUM RX SINCE NOW YOU KNOW. AND FROM KNOWLADGE YOU HAVE ABOUT RX.

        REMEMBER To include and cover everything that you are given, do not exclude anything this is a executive report which needs human validation so you need to cover everything for transparency.

        Include the following sections in the report:
        1. A header with the title "Marketing Campaign Automation Report".
        2. A section displaying the trigger data in a neat, well-formatted card or table.
        3. A section presenting the combined report text for detailed analysis.
        4. A summary section that explains how the trigger data relates to the combined report, highlighting the campaign automation trigger.
        5. Each section should be properly formatted in the HTML report, based on what it is and how you want to classify that topic it should be presented properly like a table, etc. and when you give the final summary, you have to keep it very brief and talk about what was the initial campaign what we found in the analysis and how much this analysis impact the initial campaign and strategy.
        6. Not just that at the end of each summary which each summary will keep it in a different DIV and at the end of it, you will give what that summary means for the campaign data or the trigger data that we are using for the campaign.
        7. Use HIG and various design language enhancements to make it stunning.
        8. Basically, you will have the summary and then a thought note after each summary saying what it means with the campaign data or the trigger data that has to be launched. Basically what insight can we get from the summary data for regarding the campaign?.
        9. Remember the summary and insights need to be after each section so for example, example there will be in a separate DIV customer segmentation analysis and then what we found from that analysis with respect to the campaign and then clustering in a separate, DIV and what we found from it with respect to the campaign and so on.
        10. Also, you have to keep each summary for example summary one in a separate, DIV beautified it and then after it, he will give the insight and then below will be another DIV with summary to beautified, and then he will give the insight for the summary saying how it relates to the campaign, we are about to launch and what can we find from the data.
        11. IMPORTANT: You have to keep each summary for example summary one in a separate, DIV beautified it and then after it, he will give the insight and then below will be another DIV with summary to beautified, and then he will give the insight for the summary saying how it relates to the campaign, we are about to launch and what can we find from the data.

        NOTE: Be sure to make it beautiful and stunning and professional and everything should be inside a proper DIV or proper tables, etc. clearly making it extremely good at design.

        Below are the input data details:
        ------------------------------
        Trigger Data:
        {json.dumps(trigger_data, indent=4)}

        Combined Report:
        {combined_text}

        Generate the complete HTML code wrapped in a markdown code block as specified.

        Som background on RX for analysis:
        **Optum Rx Business Description for LLM**

        **Objective:** To provide a Large Language Model (LLM) with a complete understanding of Optum Rx's business model, target audiences, services, and value proposition. This information is crucial for the LLM to effectively generate marketing content, strategies, and analyses for Optum Rx, regardless of the specific campaign structure.

        **Core Business:** Optum Rx is a **Pharmacy Benefit Manager (PBM)**.  At its heart, Optum Rx manages prescription drug benefits on behalf of other organizations. They do not primarily sell medications directly to individual consumers in a retail pharmacy setting. While they have a **Home Delivery Pharmacy** (Optum Home Delivery Pharmacy), this service is still part of their PBM offering – medications are delivered to plan members who are already part of a health plan or program managed by Optum Rx's clients.

        **Key Services & Functions:**

        *   **Prescription Processing & Claims Adjudication:**  Optum Rx processes prescription claims, verifies eligibility, and manages payments to pharmacies on behalf of their clients. They act as the intermediary between pharmacies, health plans, and patients.
        *   **Pharmacy Network Management:** They build and manage networks of pharmacies (retail and mail order) where plan members can fill their prescriptions. This includes negotiating contracts and ensuring adequate pharmacy access.
        *   **Formulary Management:**  Optum Rx develops and manages formularies, which are lists of covered medications. They work with clients to design formularies that balance cost-effectiveness with clinical appropriateness. This involves decisions about which drugs are covered, at what tier, and may include utilization management strategies like prior authorizations or quantity limits.
        *   **Mail Order Pharmacy (Optum Home Delivery Pharmacy):**  They operate their own mail-order pharmacy service (Optum Home Delivery Pharmacy) that allows patients to receive medications, particularly maintenance medications for chronic conditions, delivered directly to their homes. This offers convenience and can sometimes be more cost-effective.
        *   **Specialty Pharmacy:**  Optum Rx manages specialty medications, which are often high-cost drugs for complex conditions. This includes dispensing, patient education, and clinical support programs.
        *   **Clinical Programs & Medication Therapy Management (MTM):**  They offer programs to improve medication adherence, manage chronic conditions, and optimize medication therapy. This can include pharmacist consultations, educational materials, and data analytics to identify and support patients who could benefit from intervention.
        *   **Data Analytics & Reporting:** Optum Rx provides data and reporting to their clients on drug utilization, costs, and trends, helping them to make informed decisions about their pharmacy benefits.
        *   **Rebates & Negotiations:** They negotiate rebates with drug manufacturers to lower the overall cost of medications for their clients.

        **Target Clients (Organizations, Not Individuals):**

        Optum Rx's primary customers are organizations, not individual consumers buying medications directly in a retail setting. These clients include:

        *   **Health Plans (Commercial & Government):**  Insurance companies and managed care organizations that offer health plans to individuals and employers. This includes **Medicaid** and **Medicare** plans.  For Medicaid, they help states and managed Medicaid organizations manage drug benefits for Medicaid beneficiaries.
        *   **Employers:**  Companies and organizations that provide health benefits to their employees.
        *   **Government Programs:**  In addition to Medicaid, this can include other government-sponsored health programs.
        *   **Other Healthcare Entities:** Accountable Care Organizations (ACOs), and other risk-bearing entities.

        **Value Proposition & Benefits (For Clients & Ultimately Plan Members):**

        Optum Rx aims to provide value through:

        *   **Cost Savings:**  Managing drug costs through formulary management, rebates, network negotiations, and utilization management programs.
        *   **Improved Access to Medications:** Ensuring plan members have convenient access to necessary medications through retail networks and home delivery.
        *   **Enhanced Convenience:** Offering services like home delivery and online prescription management for plan members.
        *   **Clinical Expertise & Support:** Providing clinical programs and pharmacist support to improve patient health outcomes and medication adherence.
        *   **Data-Driven Insights:** Offering data and reporting to clients to help them manage their pharmacy benefits effectively.
        *   **Simplified Pharmacy Benefit Management:**  Taking on the complexities of managing pharmacy benefits for their clients, allowing them to focus on their core business.

        **Key Differentiators & Context:**

        *   **Part of UnitedHealth Group:** Optum Rx is part of Optum, which is a health services company, and ultimately part of UnitedHealth Group, a large and diversified healthcare organization. This provides scale, integration, and resources.
        *   **Focus on Innovation & Technology:**  Likely utilizes technology to improve efficiency, patient experience, and data analysis within their PBM services.
        *   **Commitment to Affordability and Access:**  A general aim within the PBM industry, and likely a key message for Optum Rx, is to make medications more affordable and accessible.

        **Why This is Important for Marketing to Understand:**

        For the LLM to generate effective marketing materials for Optum Rx, it must understand:

        *   **Who the *real* customer is:**  It's usually *not* the individual consumer buying a single prescription at a pharmacy. It's typically a health plan, employer, or government entity making decisions about pharmacy benefits for a large group of people.
        *   **The different audiences:** Marketing may need to target health plan decision-makers, HR benefits managers at employers, or even indirectly, plan members to encourage utilization of specific Optum Rx services offered *through* their health plan (like home delivery).
        *   **The key messages that resonate:**  Messages should focus on cost savings, efficiency, improved health outcomes, convenience for *clients* (organizations) and *their* members/employees.
        *   **Appropriate marketing channels:**  Marketing to health plans or employers will use different channels than any communication aimed at individual plan members.

        **In essence, Optum Rx is a B2B (business-to-business) service provider in the healthcare industry.  While they impact individual patients' access to medication, their direct customers are organizations that pay them to manage pharmacy benefits.**

        **Please use this information as background context when generating any marketing-related content, strategies, or analyses for Optum Rx.**
        """


    # Call the Azure OpenAI completion endpoint
    response = client.chat.completions.create(
                model="o1-mini",
                messages=[
                    {"role": "assistant", "content": "You are a helpful Report Creator."},
                    {"role": "user", "content": prompt}
                ],
                timeout=300
            )
    
    raw_output = response.choices[0].message.content.strip()

    # Use regex to extract the HTML code block wrapped in markdown triple backticks with 'html'
    pattern = r"```html(.*?)```"
    match = re.search(pattern, raw_output, re.DOTALL)

    html_output = match.group(1).strip()

    
    # Save the HTML output to a file in the output folder
    output_folder = "output"
    os.makedirs(output_folder, exist_ok=True)
    html_file_path = os.path.join(output_folder, "campaign_report.html")
    with open(html_file_path, "w") as f:
        f.write(html_output)
    
    print(f"HTML report generated and saved to {html_file_path}")
    return html_output