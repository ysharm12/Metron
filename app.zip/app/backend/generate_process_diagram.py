import json
import os
import time
from datetime import datetime

def create_output_directory():
    """Create the output directory if it doesn't exist."""
    output_dir = os.path.join(os.path.dirname(__file__), 'output')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    return output_dir

def generate_process_diagram(process_data):
    """
    Generate a process diagram JSON file based on the current state of the process.
    
    Args:
        process_data: Dictionary containing information about the process
    """
    output_dir = create_output_directory()
    
    # Create nodes for the process diagram
    nodes = []
    connections = []
    
    # Add the trigger node
    trigger_node_id = "trigger-node"
    nodes.append({
        "id": trigger_node_id,
        "name": "Campaign Trigger",
        "explanation": f"Campaign '{process_data.get('campaign_name', 'Unknown')}' was triggered at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "runtime": 0.5
    })
    
    # Add the goal analysis node
    goal_node_id = "goal-analysis-node"
    nodes.append({
        "id": goal_node_id,
        "name": "Goal Analyzer",
        "explanation": f"Analyzing goal: {process_data.get('goal', 'No goal specified')}",
        "runtime": 1.2
    })
    
    # Add connection from trigger to goal analysis
    connections.append({
        "from": trigger_node_id,
        "to": goal_node_id
    })
    
    # Add the audience analysis node
    audience_node_id = "audience-analysis-node"
    nodes.append({
        "id": audience_node_id,
        "name": "Audience Specialist",
        "explanation": f"Analyzing audience: {process_data.get('audience', 'No audience specified')}",
        "runtime": 2.3
    })
    
    # Add connection from goal analysis to audience analysis
    connections.append({
        "from": goal_node_id,
        "to": audience_node_id
    })
    
    # Add the budget planning node
    budget_node_id = "budget-planning-node"
    nodes.append({
        "id": budget_node_id,
        "name": "Budget Planner",
        "explanation": f"Planning budget allocation for ${process_data.get('budget', 0)}",
        "runtime": 1.8
    })
    
    # Add connection from audience analysis to budget planning
    connections.append({
        "from": audience_node_id,
        "to": budget_node_id
    })
    
    # Add the content generation node
    content_node_id = "content-generation-node"
    nodes.append({
        "id": content_node_id,
        "name": "Content Generator",
        "explanation": "Generating marketing content based on campaign goals and audience analysis",
        "runtime": 3.5
    })
    
    # Add connections to content generation
    connections.append({
        "from": audience_node_id,
        "to": content_node_id
    })
    connections.append({
        "from": goal_node_id,
        "to": content_node_id
    })
    
    # Add the campaign scheduling node
    schedule_node_id = "schedule-node"
    nodes.append({
        "id": schedule_node_id,
        "name": "Campaign Scheduler",
        "explanation": f"Scheduling campaign for launch on {process_data.get('requested_date', 'Unknown date')}",
        "runtime": 0.9
    })
    
    # Add connections to scheduling
    connections.append({
        "from": budget_node_id,
        "to": schedule_node_id
    })
    connections.append({
        "from": content_node_id,
        "to": schedule_node_id
    })
    
    # Create the final process diagram data
    process_diagram = {
        "nodes": nodes,
        "connections": connections
    }
    
    # Write the process diagram to a JSON file
    file_path = os.path.join(output_dir, 'process_diagram.json')
    with open(file_path, 'w') as f:
        json.dump(process_diagram, f, indent=2)
    
    print(f"Process diagram generated at {file_path}")
    return process_diagram

def update_process_status(process_data, status_updates):
    """
    Update the process diagram with the current status of each node.
    
    Args:
        process_data: Dictionary containing information about the process
        status_updates: Dictionary mapping node IDs to their current status
    """
    output_dir = create_output_directory()
    file_path = os.path.join(output_dir, 'process_diagram.json')
    
    # Check if the process diagram file exists
    if not os.path.exists(file_path):
        # Generate a new process diagram if it doesn't exist
        process_diagram = generate_process_diagram(process_data)
    else:
        # Load the existing process diagram
        with open(file_path, 'r') as f:
            process_diagram = json.load(f)
    
    # Update the status of each node
    for node in process_diagram["nodes"]:
        node_id = node["id"]
        if node_id in status_updates:
            node_status = status_updates[node_id]
            node["status"] = node_status.get("status", "pending")
            node["runtime"] = node_status.get("runtime", node.get("runtime", 0))
            
            # Update the explanation if provided
            if "explanation" in node_status:
                node["explanation"] = node_status["explanation"]
    
    # Write the updated process diagram back to the file
    with open(file_path, 'w') as f:
        json.dump(process_diagram, f, indent=2)
    
    print(f"Process diagram updated at {file_path}")
    return process_diagram

# Example usage
if __name__ == "__main__":
    # Example process data
    process_data = {
        "trigger_type": "New_Campaign",
        "campaign_name": "Summer Promotion",
        "goal": "Increase sales by 15% for Medicare Advantage plans",
        "audience": "Seniors aged 65+ in Florida",
        "budget": 5000,
        "requested_date": "2025-06-01"
    }
    
    # Generate the initial process diagram
    generate_process_diagram(process_data)
    
    # Simulate status updates over time
    time.sleep(1)
    
    # Update the status of some nodes
    status_updates = {
        "trigger-node": {
            "status": "completed",
            "runtime": 0.5,
            "explanation": "Campaign 'Summer Promotion' was triggered successfully"
        },
        "goal-analysis-node": {
            "status": "in_progress",
            "runtime": 0.8,
            "explanation": "Analyzing goal: Increase sales by 15% for Medicare Advantage plans"
        }
    }
    
    update_process_status(process_data, status_updates)
    
    # Simulate more updates
    time.sleep(1)
    
    status_updates = {
        "goal-analysis-node": {
            "status": "completed",
            "runtime": 1.2,
            "explanation": "Goal analysis completed. Targeting 15% sales increase for Medicare Advantage plans."
        },
        "audience-analysis-node": {
            "status": "in_progress",
            "runtime": 1.1,
            "explanation": "Analyzing audience demographics for seniors aged 65+ in Florida"
        }
    }
    
    update_process_status(process_data, status_updates)
