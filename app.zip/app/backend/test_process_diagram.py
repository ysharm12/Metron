import json
import os
import time
from datetime import datetime

def create_output_directory():
    """Create the output directory if it doesn't exist."""
    output_dir = os.path.join(os.path.dirname(__file__), 'output')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    return output_dir

def create_test_process_diagram():
    """Create a test process diagram JSON file."""
    output_dir = create_output_directory()
    file_path = os.path.join(output_dir, 'process_diagram.json')
    
    # Create a simple process diagram
    process_diagram = {
        "nodes": [
            {
                "id": "start-node",
                "name": "Campaign Trigger",
                "explanation": f"Campaign was triggered at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                "runtime": 0.5
            },
            {
                "id": "analysis-node",
                "name": "Customer Analysis",
                "explanation": "Analyzing customer data using KMeans clustering",
                "runtime": 2.3
            },
            {
                "id": "content-node",
                "name": "Content Generator",
                "explanation": "Generating marketing content based on customer analysis",
                "runtime": 3.1
            }
        ],
        "connections": [
            {
                "from": "start-node",
                "to": "analysis-node"
            },
            {
                "from": "analysis-node",
                "to": "content-node"
            }
        ]
    }
    
    # Write to file
    with open(file_path, 'w') as f:
        json.dump(process_diagram, f, indent=2)
    
    print(f"Test process diagram created at {file_path}")
    return process_diagram

def clear_process_diagram():
    """Clear the process diagram by creating a default 'not started' diagram."""
    output_dir = create_output_directory()
    file_path = os.path.join(output_dir, 'process_diagram.json')
    
    # Create a default diagram showing process not started
    default_diagram = {
        "nodes": [
            {
                "id": "default-node",
                "name": "Process Not Started",
                "explanation": "The marketing campaign process has not been initiated yet. Use the trigger page to start a new campaign.",
                "runtime": 0
            }
        ],
        "connections": []
    }
    
    # Write to file
    with open(file_path, 'w') as f:
        json.dump(default_diagram, f, indent=2)
    
    print(f"Process diagram cleared at {file_path}")
    return default_diagram

if __name__ == "__main__":
    # Ask user what action to take
    print("What would you like to do?")
    print("1. Create a test process diagram")
    print("2. Clear the process diagram (set to 'not started')")
    
    choice = input("Enter your choice (1 or 2): ")
    
    if choice == "1":
        create_test_process_diagram()
    elif choice == "2":
        clear_process_diagram()
    else:
        print("Invalid choice. Please run again and select 1 or 2.")
