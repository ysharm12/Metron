import sys
import json
import os
import s1_trigger_creation
from s1_1_customer_segmentation_summary import generate_segmentation_summary
from s1_2_historical_campaign_summary import generate_campaign_summary
from s1_3_sentiment_analysis_summary import generate_combined_sentiment_summary
from s1_4_kpi_thresholds_summary import generate_kpi_summary
from s1_5_competitor_data_summary import generate_competitor_summary
from generate_html_report import generate_html_report
from s1_6_ab_testing_summary import create_ab_testing_report
from s1_7_advertising_spend_summary import create_advertising_spend_report
from s1_8_brand_guidelines import create_brand_guidelines_report
from s1_9_campaign_overview_report import create_campaign_overview_report
#_____ ALWAYS IMPORT________
import logging_agentic_behavior as lab
import tasks_counter
import time
import runtime_tracker
from blueprints_creator import update_process
#___________________________

def s1_main_trigger_init(action, dummy_data):
    if action.lower() == 'update':
        # Dummy trigger data to update the file.
        s1_trigger_creation.update_trigger(dummy_data)
        print("Trigger updated with dummy data.")
        return "Trigger updated with dummy data."
    elif action.lower() == 'get':
        trigger = s1_trigger_creation.get_trigger()
        if trigger:
            print("Retrieved Trigger:")
            #print(json.dumps(trigger, indent=4))
        else:
            print("No trigger data found.")
        return trigger
    else:
        print("Unknown action. Please provide 'get' or 'update' as parameter.")

def s1_1_customer_segmentation_summary_init():
    summary = generate_segmentation_summary()
    return summary

def s1_2_historical_campaign_summary_init():
    summary = generate_campaign_summary()
    return summary

def s1_3_sentiment_analysis_summary_init():
    summary = generate_combined_sentiment_summary()
    return summary

def s1_4_kpi_thresholds_summary_init():
    summary = generate_kpi_summary()
    return summary

def s1_5_competitor_data_summary_init():
    summary = generate_competitor_summary()
    return summary

def generate_html_report_init():
    summary = generate_html_report()
    return summary

def s1_6_ab_testing_summary_init():
    summary = create_ab_testing_report()
    return summary

def s1_7_advertising_spend_summary_init():
    summary = create_advertising_spend_report()
    return summary

def s1_8_brand_guidelines_init():
    summary = create_brand_guidelines_report()
    return summary

def s1_9_campaign_overview_report_init():
    summary = create_campaign_overview_report()
    return summary


def save_data_reports(summary1, summary2, summary3, summary4, summary5):
    # Append them top-to-bottom
    combined_text = "\n".join([summary1, summary2, summary3, summary4, summary5])

    # Create output folder if it doesn't exist
    output_folder = "output"
    os.makedirs(output_folder, exist_ok=True)

    # Define the output file path
    output_file = os.path.join(output_folder, "combined_text_data_report.txt")

    # Write the combined text to the file
    with open(output_file, "w") as f:
        f.write(combined_text)

    print(f"Combined text written to {output_file}")



def initiate_s1_main_trigger(dummy_data):
    start = time.time()
    import random; rand_float = random.uniform(3, 8)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Parent_Orchestrator"
    log_step = 1
    log_task_id = "task_001"
    log_status = "completed"
    log_process = "Ephermals Assemble"
    log_details = "I have identified the trigger and have assigned tasks to ephermals accordingly. Ill go ahead and update the trigger."
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
    current_node=agent_lab,
    current_node_details={"explanation": log_details},
    runtime=rounded_seconds  # runtime in seconds
    )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    out = s1_main_trigger_init('update', dummy_data)
    summary = s1_1_customer_segmentation_summary_init()
    summary_2 = s1_2_historical_campaign_summary_init()
    summary_3 = s1_3_sentiment_analysis_summary_init()
    start = time.time()
    import random; rand_float = random.uniform(3, 4)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Sentiment_Specialist"
    log_step = 5
    log_task_id = "task_005"
    log_status = "completed"
    log_process = "Sentiment_Analysis"
    log_details = "I have chosen to apply a sentiment analysis model to understand the sentiment behind customer reviews, gaining insights into customer opinions and preferences."
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator", "Ephermal_Customer_Specialist", "Ephermal_Historical_Campaign_Specialist"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    summary_4 = s1_4_kpi_thresholds_summary_init()
    start = time.time()
    import random; rand_float = random.uniform(1, 2)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_KPI_Specialist"
    log_step = 6
    log_task_id = "task_006"
    log_status = "completed"
    log_process = "KPI_Analysis"
    log_details = "I have chosen to analyze business defined KPIs to set our boundaries"
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    summary_5 = s1_5_competitor_data_summary_init()
    start = time.time()
    import random; rand_float = random.uniform(1, 2)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Competitor_Specialist"
    log_step = 7
    log_task_id = "task_007"
    log_status = "completed"
    log_process = "Competitor_Analysis"
    log_details = "I have chosen to analyze competitors to understand market trends and competitive opportunities"
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator", "Ephermal_Historical_Campaign_Specialist"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    save_data_reports(summary, summary_2, summary_3, summary_4, summary_5)
    s1_6_ab_testing_summary_init()
    start = time.time()
    import random; rand_float = random.uniform(1, 2)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_AB_Testing_Specialist"
    log_step = 8
    log_task_id = "task_008"
    log_status = "completed"
    log_process = "AB_Testing"
    log_details = "I have chosen to review our previous AB tests results"
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator", "Ephermal_KPI_Specialist", "Ephermal_Historical_Campaign_Specialist"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    s1_7_advertising_spend_summary_init()
    start = time.time()
    import random; rand_float = random.uniform(3, 6)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Advertising_Specialist"
    log_step = 9
    log_task_id = "task_009"
    log_status = "completed"
    log_process = "Advertising_Spend_Summary"
    log_details = "I have chosen to review our previous advertising spend data to evaluate our strategy and performance going forward."
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator", "Ephermal_Competitor_Specialist", "Ephermal_AB_Testing_Specialist", "Ephermal_Historical_Campaign_Specialist"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    s1_8_brand_guidelines_init()
    start = time.time()
    import random; rand_float = random.uniform(3, 6)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Brand_Guidelines_Specialist"
    log_step = 10
    log_task_id = "task_010"
    log_status = "completed"
    log_process = "Brand_Guidelines"
    log_details = "I will now structure neccesary brand guidelines for the campaign"
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    s1_9_campaign_overview_report_init()
    start = time.time()
    import random; rand_float = random.uniform(3, 6)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Campaign_Overview_Report_Specialist"
    log_step = 11
    log_task_id = "task_011"
    log_status = "completed"
    log_process = "Campaign_Overview_Report"
    log_details = "I will now generate a campaign overview report in order for the human to review before moving forward with the strategy. I believe insights on the data will be valuable to the decision-making process."
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator","Trigger_Specialist", "Ephermal_Customer_Specialist", "Ephermal_Historical_Campaign_Specialist", "Ephermal_Brand_Guidelines_Specialist", "Ephermal_KPI_Specialist", "Ephermal_AB_Testing_Specialist", "Ephermal_Advertising_Specialist", "Ephermal_Sentiment_Analysis_Specialist", "Ephermal_Competitor_Analysis_Specialist"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________

    report = generate_html_report_init()
    start = time.time()
    import random; rand_float = random.uniform(3, 6)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Campaign_Overview_Report_Specialist"
    log_step = 12
    log_task_id = "task_012"
    log_status = "completed"
    log_process = "Campaign_Overview_Report"
    log_details = "I will now gather all reports and create a single overview report to make it easier for the human to review and make a decision"
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    print(report)
    start = time.time()
    import random; rand_float = random.uniform(3, 6)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Parent_Orchestrator"
    log_step = 13
    log_task_id = "task_013"
    log_status = "completed"
    log_process = "Begin Strategy"
    log_details = "I will now begin the strategy process"
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Ephermal_Campaign_Overview_Report_Specialist"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________


# initiate_s1_main_trigger()