import json
import os

JSON_FILE = "output/logging_agentic_behavior.json"

def _load_data():
    """
    Loads data from the JSON file.
    If the file does not exist, returns a default structure.
    """
    if os.path.exists(JSON_FILE):
        with open(JSON_FILE, "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                data = {"logs": [], "status": {}}
    else:
        data = {"logs": [], "status": {}}
    # Ensure both keys exist
    if "logs" not in data:
        data["logs"] = []
    if "status" not in data:
        data["status"] = {}
    return data

def _save_data(data):
    """
    Saves the data structure to the JSON file.
    """
    with open(JSON_FILE, "w") as f:
        json.dump(data, f, indent=4)

def register_log(log_entry):
    """
    Registers a new log entry.
    The log_entry should follow the Agent Log JSON Schema:
    
    {
      "id": (optional) unique integer identifier; auto-assigned if omitted,
      "agent_name": string,
      "step": integer,
      "process": string,
      "details": string,
      "time_taken": number,
      "timestamp": string (ISO-8601),
      "status": string,
      "task_id": (optional) string
    }
    
    If "id" is not provided, it is auto-generated.
    """
    data = _load_data()
    
    # Auto-assign id if not provided
    if "id" not in log_entry:
        log_entry["id"] = len(data["logs"]) + 1
    
    data["logs"].append(log_entry)
    _save_data(data)
    print("Log entry registered.")

def update_status(status_data):
    """
    Updates the agent status.
    The status_data should follow the Agent Status JSON Schema:
    
    {
      "agent_name": string,
      "tasks_executed": integer,
      "avg_time": number,
      "last_error": string,
      "status": string,
      "current_task": string,           # The current task the agent is working on
      "timestamp": string (ISO-8601)
    }
    """
    data = _load_data()
    data["status"] = status_data
    _save_data(data)
    print("Agent status updated.")
