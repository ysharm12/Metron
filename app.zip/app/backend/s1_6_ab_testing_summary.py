import os
import json
import pandas as pd
import numpy as np
import logging
from scipy.stats import ttest_1samp

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def generate_ab_testing_summaries(csv_path):
    """
    Reads A/B testing data from a CSV file and generates a JSON summary for each test.
    Uses a simple statistical evaluation to flag significant differences.
    
    Expected CSV fields:
      test_id, campaign_id, description, variant_A_metric, variant_B_metric, winning_variant, confidence
    Returns:
        tuple: (list of test summaries, list of metric differences)
    """
    if not os.path.exists(csv_path):
        logger.warning(f"CSV file not found at {csv_path}. Returning empty summaries.")
        return [], []
    
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        logger.error(f"Error reading CSV file: {e}")
        return [], []
    
    # Check if DataFrame is empty or missing required columns
    required_columns = {"test_id", "campaign_id", "description", "variant_A_metric", "variant_B_metric", "winning_variant", "confidence"}
    if df.empty or not required_columns.issubset(df.columns):
        logger.warning("CSV file is empty or missing required columns. Returning empty summaries.")
        return [], []
    
    summaries = []
    differences = []
    diff_threshold = 0.05  # minimal difference considered significant
    confidence_threshold = 85  # minimal confidence percentage considered high
    
    for _, row in df.iterrows():
        try:
            test_id = row["test_id"]
            campaign_id = row["campaign_id"]
            description = row["description"]
            variant_A = float(row["variant_A_metric"])
            variant_B = float(row["variant_B_metric"])
            winning_variant = str(row["winning_variant"]).strip().upper()
            # Remove "%" and convert confidence to float
            confidence = float(str(row["confidence"]).replace("%", "").strip())
        except Exception as e:
            logger.error(f"Error processing row: {e}")
            continue
        
        # Compute the metric difference based on the winning variant.
        if winning_variant == "A":
            diff = variant_A - variant_B
        else:
            diff = variant_B - variant_A
        differences.append(diff)
        
        significance = "significant" if abs(diff) >= diff_threshold and confidence >= confidence_threshold else "not significant"
        insight = (f"Test {test_id} ({description}): Variant {winning_variant} "
                   f"had a metric difference of {diff:.3f} ({significance}).")
        
        summary = {
            "test_id": test_id,
            "campaign_id": campaign_id,
            "description": description,
            "winning_variant": winning_variant,
            "metric_difference": round(diff, 3),
            "confidence": f"{confidence:.0f}%",
            "insight": insight
        }
        summaries.append(summary)
        logger.debug(f"Processed test {test_id}: {summary}")
    
    return summaries, differences

def generate_overall_analysis(differences, summaries):
    """
    Performs an overall analysis on the test metric differences using a one-sample t-test.
    Returns a multi-line text report summarizing overall trends, regardless of data volume.
    """
    n_tests = len(differences)
    if n_tests == 0:
        return ("=== In-Depth A/B Testing Analysis Report ===\n"
                "No valid A/B testing data available to perform analysis.")
    
    avg_diff = np.mean(differences)
    std_diff = np.std(differences, ddof=1) if n_tests > 1 else 0.0
    # Perform a one-sample t-test (if only one test, use a fallback p-value)
    if n_tests > 1:
        t_stat, p_value = ttest_1samp(differences, 0.0)
    else:
        t_stat, p_value = 0.0, 1.0
    
    wins_A = sum(1 for s in summaries if s["winning_variant"] == "A")
    wins_B = sum(1 for s in summaries if s["winning_variant"] == "B")
    
    report_lines = [
        "=== In-Depth A/B Testing Analysis Report ===",
        f"Total tests conducted: {n_tests}",
        f"Average metric difference: {avg_diff:.3f}",
        f"Standard deviation: {std_diff:.3f}",
        f"One-sample t-test: t-statistic = {t_stat:.3f}, p-value = {p_value:.3f}",
        "",
        f"Tests won by Variant A: {wins_A}",
        f"Tests won by Variant B: {wins_B}",
        "",
        "Insights:"
    ]
    
    if p_value < 0.05:
        report_lines.append("The mean metric difference is statistically significant (p < 0.05), indicating a consistent performance difference between variants.")
    else:
        report_lines.append("The mean metric difference is not statistically significant (p >= 0.05), suggesting that observed differences might be due to chance.")
    
    if wins_A != wins_B:
        dominant_variant = "A" if wins_A > wins_B else "B"
        report_lines.append(f"Overall, Variant {dominant_variant} performed better across the tests.")
    else:
        report_lines.append("Both variants performed similarly overall.")
    
    report_lines.append("\nRecommendations:")
    if wins_A > wins_B:
        report_lines.append("Investigate the elements of Variant A to replicate its success across campaigns.")
    elif wins_B > wins_A:
        report_lines.append("Investigate the elements of Variant B to replicate its success across campaigns.")
    else:
        report_lines.append("Consider designing new tests to drive clearer performance differences.")
    
    return "\n".join(report_lines)

def append_report(report_text, output_filepath):
    """
    Appends the provided multi-line report text to the specified file.
    If the file exists, the new report is appended; otherwise, a new file is created.
    """
    if os.path.exists(output_filepath):
        with open(output_filepath, "r") as f:
            current_content = f.read()
    else:
        current_content = ""
    
    updated_content = current_content + "\n\n" + report_text + "\n"
    with open(output_filepath, "w") as f:
        f.write(updated_content)
    logger.info(f"Report appended to {output_filepath}")
    return updated_content

def create_ab_testing_report():
    csv_path = os.path.join("synthetic_data", "ab_testing_results.csv")
    output_folder = "output"
    os.makedirs(output_folder, exist_ok=True)
    report_file = os.path.join(output_folder, "combined_text_data_report.txt")
    
    summaries, differences = generate_ab_testing_summaries(csv_path)
    
    # Save individual test summaries to a JSON file for reference.
    summary_json_file = os.path.join(output_folder, "ab_testing_summary.json")
    with open(summary_json_file, "w") as f:
        json.dump(summaries, f, indent=4)
    logger.info(f"A/B testing JSON summary saved to {summary_json_file}")
    
    overall_analysis = generate_overall_analysis(differences, summaries)
    final_report = append_report(overall_analysis, report_file)
    
    print("=== Overall In-Depth Analysis Report ===")
    print(overall_analysis)

# if __name__ == "__main__":
#     main()
