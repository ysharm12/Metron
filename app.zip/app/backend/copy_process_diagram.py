import json
import os
import shutil

def copy_process_diagram():
    """
    Copy the process_diagram.json file to a location accessible by the Next.js API.
    """
    # Source file path
    source_path = os.path.join(os.path.dirname(__file__), 'output', 'process_diagram.json')
    
    # Target directory paths (try multiple locations to ensure it's accessible)
    target_dirs = [
        os.path.join(os.path.dirname(__file__), '..', 'frontend', 'public', 'data'),
        os.path.join(os.path.dirname(__file__), '..', 'frontend', 'src', 'app', 'api', 'process', 'data')
    ]
    
    # Check if source file exists
    if not os.path.exists(source_path):
        print(f"Source file not found: {source_path}")
        return False
    
    success = False
    
    # Create target directories if they don't exist and copy the file
    for target_dir in target_dirs:
        if not os.path.exists(target_dir):
            os.makedirs(target_dir)
        
        target_path = os.path.join(target_dir, 'process_diagram.json')
        try:
            shutil.copy2(source_path, target_path)
            print(f"Successfully copied process_diagram.json to {target_path}")
            success = True
        except Exception as e:
            print(f"Error copying to {target_path}: {str(e)}")
    
    return success

if __name__ == "__main__":
    copy_process_diagram()
