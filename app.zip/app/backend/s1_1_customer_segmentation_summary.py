import pandas as pd
import json
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
#_____ ALWAYS IMPORT________
import logging_agentic_behavior as lab
import tasks_counter
import time
import runtime_tracker
from blueprints_creator import update_process
#___________________________

def generate_segmentation_summary():
    start = time.time()
    # Load customer data from CSV (assumed to be large in real usage)
    customers = pd.read_csv("synthetic_data/customers.csv")
    
    # Load segments definitions from JSON
    with open("synthetic_data/segments.json", "r") as f:
        segments_data = json.load(f)
    segments_def = segments_data.get("segments", [])
    
    # Descriptive Insights:
    total_customers = len(customers)
    breakdown = customers.groupby(["segment", "state"]).size().reset_index(name="count")
    
    # Machine Learning Insight:
    # Select numeric features for clustering (e.g., age, num_purchases, total_spent)
    features = customers[["age", "num_purchases", "total_spent"]].copy()
    
    # Standardize features for clustering
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features)
    
    # Apply KMeans clustering into 3 clusters (this number can be tuned)
    kmeans = KMeans(n_clusters=3, random_state=42)
    customers["cluster"] = kmeans.fit_predict(features_scaled)
    
    # Compute summary statistics per cluster
    cluster_summary = customers.groupby("cluster").agg(
        avg_age=("age", "mean"),
        avg_purchases=("num_purchases", "mean"),
        avg_spent=("total_spent", "mean"),
        count=("customer_id", "count")
    ).reset_index().rename(columns={"cluster": "cluster"})
    
    # Build a multi-line string with the insights
    summary_lines = []
    summary_lines.append("Customer Segmentation Analysis Summary:")
    summary_lines.append("----------------------------------------")
    summary_lines.append(f"Total Customers: {total_customers}\n")
    
    summary_lines.append("Breakdown by Segment and State:")
    for _, row in breakdown.iterrows():
        summary_lines.append(f" - Segment '{row['segment']}' in {row['state']}: {row['count']} customer(s)")
    
    summary_lines.append("\nKMeans Clustering Analysis (3 clusters):")
    for _, row in cluster_summary.iterrows():
        summary_lines.append(
            f" - Cluster {int(row['cluster'])}: {int(row['count'])} customers, "
            f"Avg Age: {row['avg_age']:.1f}, Avg Purchases: {row['avg_purchases']:.1f}, "
            f"Avg Total Spent: ${row['avg_spent']:.2f}"
        )
    
    summary_lines.append("\nSegment Definitions (from segments.json):")
    for seg in segments_def:
        summary_lines.append(f" - {seg['name']}: {seg['criteria']}")
    
    # Combine all lines into a single multi-line string
    summary_text = "\n".join(summary_lines)
    import random; rand_float = random.uniform(3, 5)
    time.sleep(rand_float)
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Customer_Specialist"
    log_step = 3
    log_task_id = "task_003"
    log_status = "completed"
    log_process = "ML_Segmentation_Analysis"
    log_details = "I have chosen to apply KMeans clustering on standardized customer features (age, num_purchases, total_spent) to partition customers into 3 clusters, revealing distinct segmentation characteristics."
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    return summary_text

# if __name__ == "__main__":
#     summary = generate_segmentation_summary()
#     print(summary)
