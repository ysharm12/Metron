from s1_main_trigger import initiate_s1_main_trigger
from s2_1_strategy import generate_strategy_report
from s3_1_content_writeup import create_content_writeup
from s4_1_banner_creation import start_banner_creation


dummy_data = {
                "trigger_type": "New_Campaign",
                "campaign_name": "New Optum RX Plan Launch",
                "goal": "Increase sales by 20% for medicaid",
                "audience": "medicaid users",
                "budget": 4000,
                "requested_date": "2025-09-01"
            }
initiate_s1_main_trigger(dummy_data)
generate_strategy_report()
create_content_writeup()
start_banner_creation()
