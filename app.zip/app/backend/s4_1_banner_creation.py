import os
import re
import json
from openai import AzureOpenAI
from playwright.sync_api import sync_playwright
#_____ ALWAYS IMPORT________
import logging_agentic_behavior as lab
import tasks_counter
import time
import runtime_tracker
from blueprints_creator import update_process
#___________________________
# -------------------------
# Azure OpenAI Configuration
# -------------------------
client = AzureOpenAI(
    api_version="2024-06-01",
    azure_endpoint="https://openaiqueryit.openai.azure.com/",
    api_key="2u8gagl8riKy2RhvETKrCavz9N9HbflsTSIZX1ejO3HI8RTUBeqIJQQJ99BBACYeBjFXJ3w3AAABACOGussx"
)
deployment_name = "o1-mini"  # Update with your deployment name if needed

# -------------------------
# Helper Functions
# -------------------------
def get_dimensions(platform: str):
    """Return dimensions for known platforms."""
    sizes = {
        "twitter": (1500, 500),
        "linkedin": (1584, 396),
        "instagram": (1080, 1080),
        "email": (600, 200)
    }
    return sizes.get(platform.lower(), (1500, 500))

def generate_html_banner(user_description: str, platform: str) -> str:
    """
    Uses Azure OpenAI to generate HTML code for a banner.
    The prompt instructs the model to output HTML using Tailwind CSS,
    with dimensions and layout rules based on the specified platform.
    """
    width, height = get_dimensions(platform)
    system_prompt = f"""
    You are a professional banner designer. Generate HTML code (using Tailwind CSS) for an enterprise-level marketing banner for the '{platform}' platform. The banner dimensions are {width}px by {height}px.

    Always remember to stretch with aspect ratio intact the image to fit the dimensions and position text accordingly within it so for whatever channel required it seems enterprise like and professional.

    Requirements:
    1. The banner must include:
    - A logo at the top-left (use: https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/Optum_logo_2021.svg/2560px-Optum_logo_2021.svg.png).
    2. Use public image URLs (from Unsplash, Pexels, or Pixabay) for the background, ensuring the image fills the container while preserving its aspect ratio.
    3. Ensure text overlays are clearly visible and highlighted, and fill any excessive whitespace with subtle graphic elements.
    4. Use sophisticated, enterprise-level styling with Tailwind CSS. The HTML must include the Tailwind CDN reference.
    5. Output only the final HTML code without any commentary.

    Input Description:
    {user_description}

    Generate the complete, detailed HTML code now.

    Example:
    ```html
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>Optum RX Plan Banner</title>
    <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body>
    <div class="w-[1500px] h-[500px] relative">
        <img src="https://images.unsplash.com/photo-1595152772835-219674b2a8a6?fit=crop&w=1500&q=80" alt="Background" class="w-full h-full object-cover">
        <div class="absolute top-0 left-0 w-full h-full bg-black bg-opacity-40"></div>
        <div class="absolute top-0 left-0 p-6 z-10 flex flex-col">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/Optum_logo_2021.svg/2560px-Optum_logo_2021.svg.png" alt="Optum Logo" class="w-32 mb-4">
        <div class="bg-[#FF6900] px-4 py-2 rounded">
            <h1 class="text-2xl font-bold text-white">New Optum RX Plan for Medicaid Users</h1>
            <h2 class="text-lg text-gray-300 mt-2">Transforming Your Pharmacy Experience</h2>
        </div>
        </div>
        <div class="absolute top-1/2 right-6 transform -translate-y-1/2 z-10 text-gray-200 max-w-lg">
        <p class="mb-4">Experience personalized care, better prescription management, and cost savings with our new Optum RX plan.</p>
        <button class="bg-white text-[#FF6900] font-semibold py-2 px-4 rounded hover:bg-gray-200">Enroll Today!</button>
        </div>
    </div>
    </body>
    </html>
    ```
    """


    response = client.chat.completions.create(
        model=deployment_name,
        messages=[
            {"role": "assistant", "content": system_prompt},
            {"role": "user", "content": user_description}
        ],
        timeout=300
    )
    raw_output = response.choices[0].message.content.strip()
    # Try to extract HTML code from markdown block if present
    pattern = r"```html(.*?)```"
    match = re.search(pattern, raw_output, re.DOTALL)
    if match:
        html_output = match.group(1).strip()
    else:
        html_output = raw_output  # fallback if no markdown block is found
    return html_output

def html_to_png_playwright(html_code: str, platform: str, output_dir: str = "output/images"):
    """
    Converts HTML code to PNG using Playwright.
    """
    width, height = get_dimensions(platform)
    os.makedirs(output_dir, exist_ok=True)
    output_filename = os.path.join(output_dir, f"banner_{platform.lower()}.png")
    
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={'width': width, 'height': height})
        page.set_content(html_code, wait_until="networkidle")
        # Capture a screenshot of the banner container (full page if needed)
        page.screenshot(path=output_filename, full_page=False)
        browser.close()
    
    print(f"Banner saved as {output_filename}")

# -------------------------
# Main Flow
# -------------------------
def create_banner(user_description: str, platform: str):
    # Generate HTML using Azure OpenAI model
    html_code = generate_html_banner(user_description, platform)
    print("Generated HTML code:")
    print(html_code)
    # Convert the HTML to PNG and save it using Playwright
    html_to_png_playwright(html_code, platform)





def start_banner_creation():
    start = time.time()
    # Replace 'input.json' with your actual JSON file path.
    input_file = "output/final_content_writeup.json"
    
    # Load JSON data from file.
    with open(input_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    # For each channel (excluding SMS), extract the banner details as a multi-line string.
    banner_email = ""
    banner_linkedin = ""
    banner_instagram = ""
    banner_twitter = ""
    banner_directmail = ""
    
    for channel, details in data.items():
        if channel.lower() == "sms":
            continue
        banner = details.get("banner")
        # Convert the banner dict to a formatted multi-line string if present
        banner_str = json.dumps(banner, indent=2) if banner else f"No banner section for channel: {channel}"
        if channel.lower() == "email":
            banner_email = banner_str
        elif channel.lower() == "linkedin":
            banner_linkedin = banner_str
        elif channel.lower() == "instagram":
            banner_instagram = banner_str
        elif channel.lower() == "twitter":
            banner_twitter = banner_str
        elif channel.lower() == "directmail":
            banner_directmail = banner_str

    
    


    print("\nLinkedIn Banner:\n", banner_linkedin)
    # Specify platform: "twitter", "linkedin", "instagram", or "email"
    platform = "linkedin"
    create_banner(banner_linkedin, platform)
    
    
    print("\nInstagram Banner:\n", banner_instagram)
    # Specify platform: "twitter", "linkedin", "instagram", or "email"
    platform = "instagram"
    create_banner(banner_instagram, platform)
    
    
    
    print("\nTwitter Banner:\n", banner_twitter)
    # Specify platform: "twitter", "linkedin", "instagram", or "email"
    platform = "twitter"
    create_banner(banner_twitter, platform)
    
    
    
    print("\nDirect Mail Banner:\n", banner_directmail)
    # Specify platform: "twitter", "linkedin", "instagram", or "email"
    platform = "directmail"
    create_banner(banner_directmail, platform)

    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Ephermal_Banner_Generator_Specialist"
    log_step = 16
    log_task_id = "task_016"
    log_status = "completed"
    log_process = "Banner"
    log_details = "The request and requirement for each channel had been fulfilled, I have gone ahead and created the banners."
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Ephermal_Content_Writer", "Parent_Orchestrator"],
        runtime=rounded_seconds  # runtime in seconds
        )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________

# start_banner_creation()