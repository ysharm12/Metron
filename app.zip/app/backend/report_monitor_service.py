from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
import os
import time
import json
import asyncio
import uvicorn
import subprocess
from pathlib import Path
from datetime import datetime
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("report_monitor")

app = FastAPI()

# Add CORS middleware to allow frontend connections
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],  # Explicitly allow POST
    allow_headers=["Content-Type", "Authorization"],  # Explicitly allow Content-Type
    expose_headers=["Content-Type"],
)

# Path to monitor
REPORT_PATH = Path(os.path.join(os.path.dirname(os.path.abspath(__file__)), "output", "campaign_report.html"))
logger.info(f"Monitoring file: {REPORT_PATH}")

# Store connected clients
connected_clients = set()

# Store seen reports to prevent duplicate notifications
seen_reports = {}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    client_id = id(websocket)
    logger.info(f"Client {client_id} connected")
    
    # Add to connected clients
    connected_clients.add(websocket)
    
    try:
        # Send initial status
        await send_report_status(websocket)
        
        # Keep connection alive and handle client messages
        while True:
            # Wait for any message from client (like reset commands)
            data = await websocket.receive_text()
            message = json.loads(data)
            
            if message.get("action") == "reset":
                logger.info("Received reset command")
                # Clear seen reports
                seen_reports.clear()
                # Send updated status
                await send_report_status(websocket)
            
            # Sleep to prevent high CPU usage
            await asyncio.sleep(0.1)
            
    except WebSocketDisconnect:
        logger.info(f"Client {client_id} disconnected")
        connected_clients.remove(websocket)
    except Exception as e:
        logger.error(f"Error in websocket connection: {e}")
        connected_clients.discard(websocket)

async def send_report_status(websocket):
    """Send current report status to a specific client"""
    status = check_report_status()
    await websocket.send_json(status)

async def broadcast_report_status():
    """Send report status to all connected clients"""
    if not connected_clients:
        return
        
    status = check_report_status()
    
    # Only broadcast if there's a report and we haven't seen it before
    report_id = status.get("reportId")
    if status.get("exists") and report_id and report_id not in seen_reports:
        logger.info(f"Broadcasting new report status: {status}")
        seen_reports[report_id] = datetime.now().isoformat()
        
        # Send to all connected clients
        disconnected = set()
        for client in connected_clients:
            try:
                await client.send_json(status)
            except Exception as e:
                logger.error(f"Error sending to client: {e}")
                disconnected.add(client)
        
        # Remove disconnected clients
        for client in disconnected:
            connected_clients.discard(client)

def check_report_status():
    """Check if the report file exists and get its status"""
    try:
        if REPORT_PATH.exists():
            last_modified = datetime.fromtimestamp(REPORT_PATH.stat().st_mtime)
            last_modified_iso = last_modified.isoformat()
            
            # Create a unique identifier for this report
            report_id = f"campaign_report.html-{last_modified_iso}"
            
            return {
                "exists": True,
                "lastModified": last_modified_iso,
                "path": str(REPORT_PATH),
                "reportId": report_id,
                "isRecent": True
            }
        else:
            return {
                "exists": False,
                "path": str(REPORT_PATH)
            }
    except Exception as e:
        logger.error(f"Error checking report status: {e}")
        return {
            "exists": False,
            "error": str(e),
            "path": str(REPORT_PATH)
        }

@app.get("/status")
async def get_status():
    """REST endpoint to check report status"""
    return check_report_status()

@app.post("/approve")
async def approve_report():
    """Endpoint to approve a report and run the next steps"""
    logger.info("Approve endpoint called")
    try:
        logger.info("Report approved, running next steps...")
        script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui_call_2.py")
        logger.info(f"Running script: {script_path}")
        
        # Check if the script exists
        if not os.path.exists(script_path):
            logger.error(f"Script not found: {script_path}")
            return {"success": False, "error": f"Script not found: {script_path}"}
        
        # Run the script as a subprocess
        logger.info("Starting subprocess...")
        result = subprocess.run(["python", script_path], capture_output=True, text=True)
        logger.info(f"Subprocess completed with return code: {result.returncode}")
        
        if result.returncode != 0:
            logger.error(f"Error executing script: {result.stderr}")
            return {"success": False, "error": result.stderr}
        
        logger.info(f"Script output: {result.stdout}")
        return {"success": True, "message": "Report approved and next steps initiated", "output": result.stdout}
    except Exception as e:
        logger.error(f"Error approving report: {str(e)}")
        return {"success": False, "error": str(e)}

@app.post("/reset")
async def reset_seen_reports():
    """Reset the seen reports list"""
    seen_reports.clear()
    return {"success": True, "message": "Seen reports reset successfully"}

async def monitor_report_file():
    """Background task to monitor the report file"""
    last_check = None
    
    while True:
        try:
            # Check if file exists
            if REPORT_PATH.exists():
                # Get last modified time
                current_mtime = REPORT_PATH.stat().st_mtime
                
                # If file is new or modified since last check
                if last_check is None or current_mtime > last_check:
                    logger.info(f"Report file changed: {REPORT_PATH}")
                    last_check = current_mtime
                    
                    # Broadcast to all clients
                    await broadcast_report_status()
            
            # Sleep to prevent high CPU usage
            await asyncio.sleep(1)
            
        except Exception as e:
            logger.error(f"Error monitoring file: {e}")
            await asyncio.sleep(5)  # Sleep longer on error

@app.on_event("startup")
async def startup_event():
    """Start the file monitoring task when the app starts"""
    asyncio.create_task(monitor_report_file())
    logger.info("Report monitoring service started")

if __name__ == "__main__":
    uvicorn.run("report_monitor_service:app", host="0.0.0.0", port=8000, reload=True)
