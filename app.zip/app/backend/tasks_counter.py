import os
import json

OUTPUT_FOLDER = "output"
OUTPUT_FILE = os.path.join(OUTPUT_FOLDER, "tasks_counter.json")

def _load_agent_tasks():
    """
    Loads the tasks counter data from the JSON file.
    If the file or folder doesn't exist, returns an empty dictionary.
    """
    if not os.path.exists(OUTPUT_FOLDER):
        os.makedirs(OUTPUT_FOLDER)
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError:
                data = {}
    else:
        data = {}
    return data

def _save_agent_tasks(data):
    """
    Saves the tasks counter dictionary to the JSON file.
    """
    with open(OUTPUT_FILE, "w") as f:
        json.dump(data, f, indent=4)

def update_agent_tasks_count(agent_name, increment=1):
    """
    Updates the tasks_executed counter for the given agent.
    
    Parameters:
        agent_name (str): The unique identifier for the agent (e.g., "StrategyAgent").
        increment (int, optional): The amount by which to increment the count (default is 1).
        
    Returns:
        int: The updated tasks count for the specified agent.
    """
    data = _load_agent_tasks()
    current_count = data.get(agent_name, 0)
    new_count = current_count + increment
    data[agent_name] = new_count
    _save_agent_tasks(data)
    print(f"Tasks count for {agent_name} updated to {new_count}.")
    return new_count

def get_agent_tasks_count(agent_name):
    """
    Retrieves the current tasks_executed count for the specified agent.
    
    Parameters:
        agent_name (str): The unique identifier for the agent.
    
    Returns:
        int: The current tasks count for the specified agent, or 0 if not present.
    """
    data = _load_agent_tasks()
    count = data.get(agent_name, 0)
    print(f"Current tasks count for {agent_name}: {count}.")
    return count