import os
import json
#_____ ALWAYS IMPORT________
import logging_agentic_behavior as lab
import tasks_counter
import time
import runtime_tracker
from blueprints_creator import update_process
#___________________________

def get_json_file_path():
    """
    Ensure the input_folder exists and return the full path for trigger.json.
    """
    folder = "input_folder"
    if not os.path.exists(folder):
        os.makedirs(folder)
    return os.path.join(folder, "trigger.json")

def update_trigger(trigger_data):
    """
    Write the provided trigger_data dictionary to trigger.json.
    """
    start = time.time()
    file_path = get_json_file_path()
    with open(file_path, "w") as f:
        json.dump(trigger_data, f, indent=4)
    print(f"Trigger data updated at {file_path}")
    elapsed = time.time() - start

    #_________________________________________
    agent_lab = "Trigger_Specialist"
    log_step = 2
    log_task_id = "task_002"
    log_status = "completed"
    log_process = "Updating Trigger"
    log_details = "Updating Trigger with new campaign"
    status_status = "running"
    status_current_task = log_process
    rounded_seconds = round(elapsed, 5)
    date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
    update_process(
    current_node=agent_lab,
    current_node_details={"explanation": log_details},
    from_nodes=["Parent_Orchestrator"],
    runtime=rounded_seconds  # runtime in seconds
    )
    # One-line call to register a log entry
    lab.register_log({
        "agent_name": agent_lab,
        "step": log_step,
        "process": log_process,
        "details": log_details,
        "time_taken": rounded_seconds,
        "timestamp": date_str,
        "status": log_status,
        "task_id": log_task_id
    })
    # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
    tasks_counter.update_agent_tasks_count(agent_lab, 1)
    current_count = tasks_counter.get_agent_tasks_count(agent_lab)
    # One-line call to update the runtime for "StrategyAgent"
    runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
    # One-line call to fetch and display the current total runtime for "StrategyAgent"
    current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
    # One-line call to update the agent's status (including the current task)
    lab.update_status({
        "agent_name": agent_lab,
        "tasks_executed": current_count,
        "avg_time": current_runtime,
        "last_error": "",
        "status": status_status,
        "current_task": status_current_task,
        "timestamp": date_str
    })
    #_________________________________________
    

def get_trigger():
    """
    Read and return the trigger JSON from trigger.json.
    Returns None if the file does not exist.
    """
    start = time.time()
    file_path = get_json_file_path()
    if os.path.exists(file_path):
        with open(file_path, "r") as f:
            data = json.load(f)
        elapsed = time.time() - start
        #_________________________________________
        agent_lab = "Trigger_Specialist"
        log_step = 2
        log_task_id = "task_002"
        log_status = "completed"
        log_process = "Getting Trigger"
        log_details = "Getting Trigger from Trigger Repository"
        status_status = "running"
        status_current_task = log_process
        rounded_seconds = round(elapsed, 5)
        date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator"],
        runtime=rounded_seconds  # runtime in seconds
        )
        # One-line call to register a log entry
        lab.register_log({
            "agent_name": agent_lab,
            "step": log_step,
            "process": log_process,
            "details": log_details,
            "time_taken": rounded_seconds,
            "timestamp": date_str,
            "status": log_status,
            "task_id": log_task_id
        })
        # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
        tasks_counter.update_agent_tasks_count(agent_lab, 1)
        current_count = tasks_counter.get_agent_tasks_count(agent_lab)
        # One-line call to update the runtime for "StrategyAgent"
        runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
        # One-line call to fetch and display the current total runtime for "StrategyAgent"
        current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
        # One-line call to update the agent's status (including the current task)
        lab.update_status({
            "agent_name": agent_lab,
            "tasks_executed": current_count,
            "avg_time": current_runtime,
            "last_error": "",
            "status": status_status,
            "current_task": status_current_task,
            "timestamp": date_str
        })
        #_________________________________________
        return data
    else:
        start = time.time()
        print("No trigger found. Please update the trigger first.")
        elapsed = time.time() - start
        #_________________________________________
        agent_lab = "Trigger_Specialist"
        log_step = 2
        log_task_id = "task_002"
        log_status = "completed"
        log_process = "No Trigger Found"
        log_details = "No Trigger Found"
        status_status = "running"
        status_current_task = log_process
        rounded_seconds = round(elapsed, 5)
        date_str = __import__('datetime').datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        update_process(
        current_node=agent_lab,
        current_node_details={"explanation": log_details},
        from_nodes=["Parent_Orchestrator"],
        runtime=rounded_seconds  # runtime in seconds
        )
        # One-line call to register a log entry
        lab.register_log({
            "agent_name": agent_lab,
            "step": log_step,
            "process": log_process,
            "details": log_details,
            "time_taken": rounded_seconds,
            "timestamp": date_str,
            "status": log_status,
            "task_id": log_task_id
        })
        # One-line call to update the tasks count for the "Parent_Orchestrator" by 1 (default increment)
        tasks_counter.update_agent_tasks_count(agent_lab, 1)
        current_count = tasks_counter.get_agent_tasks_count(agent_lab)
        # One-line call to update the runtime for "StrategyAgent"
        runtime_tracker.update_agent_runtime(agent_lab, rounded_seconds)
        # One-line call to fetch and display the current total runtime for "StrategyAgent"
        current_runtime = runtime_tracker.get_agent_runtime(agent_lab)
        # One-line call to update the agent's status (including the current task)
        lab.update_status({
            "agent_name": agent_lab,
            "tasks_executed": current_count,
            "avg_time": current_runtime,
            "last_error": "",
            "status": status_status,
            "current_task": status_current_task,
            "timestamp": date_str
        })
        #_________________________________________
        return None
