import logging_agentic_behavior as lab

# One-line call to register a log entry
lab.register_log({
    "agent_name": "StrategyAgent",
    "step": 1,
    "process": "Data Extraction",
    "details": "Extracted data from source X with output: `{ \"records\": 150 }`",
    "time_taken": 3.5,
    "timestamp": "2025-03-04T12:00:00Z",
    "status": "completed",
    "task_id": "task_001"
})

# One-line call to update the agent's status (including the current task)
lab.update_status({
    "agent_name": "StrategyAgent",
    "tasks_executed": 1,
    "avg_time": 3.5,
    "last_error": "",
    "status": "running",
    "current_task": "Data Extraction",  # New field showing the current task
    "timestamp": "2025-03-04T12:01:00Z"
})
