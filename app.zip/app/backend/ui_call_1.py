from s1_main_trigger import initiate_s1_main_trigger



dummy_data = {
                "trigger_type": "New_Campaign",
                "campaign_name": "New Optum RX Plan Launch",
                "goal": "Increase sales by 20% for medicaid",
                "audience": "medicaid users",
                "budget": 4000,
                "requested_date": "2025-09-01"
            }
initiate_s1_main_trigger(dummy_data)

