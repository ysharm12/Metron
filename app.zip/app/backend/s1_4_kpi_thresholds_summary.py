import json

def generate_kpi_summary():
    """
    Loads KPI thresholds from 'synthetic_data/kpi_thresholds.json' and generates a concise multi-line summary.
    This version does not use any LLM summarization; it simply formats the data into a human-readable summary.
    """
    # Load KPI thresholds from JSON file
    with open("synthetic_data/kpi_thresholds.json", "r") as f:
        kpi_data = json.load(f)
    
    # Build the multi-line summary from the KPI data
    summary_lines = ["KPI Thresholds Analysis Summary:", "---------------------------------"]
    
    for channel, thresholds in kpi_data.items():
        channel_upper = channel.upper()
        if channel == "email":
            summary_lines.append(
                f"For {channel_upper}: minimum CTR is {thresholds['ctr_min']*100:.0f}%, "
                f"minimum open rate is {thresholds['open_rate_min']*100:.0f}%, "
                f"maximum bounce rate is {thresholds['bounce_rate_max']*100:.0f}%, and "
                f"minimum conversion rate is {thresholds['conversion_rate_min']*100:.0f}%."
            )
        elif channel == "social":
            summary_lines.append(
                f"For {channel_upper}: minimum engagement rate is {thresholds['engagement_rate_min']*100:.0f}%."
            )
        elif channel == "ad":
            summary_lines.append(
                f"For {channel_upper}: minimum ROI is {thresholds['roi_min']}."
            )
    
    # Return the complete multi-line summary as a single string
    return "\n".join(summary_lines)

# if __name__ == "__main__":
#     summary = generate_kpi_summary()
#     print(summary)
