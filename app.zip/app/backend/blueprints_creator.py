import json, os, uuid

JSON_PATH = "output/process_diagram.json"

def update_process(current_node, current_node_details, from_nodes=None, runtime=None):
    """
    Updates the JSON process diagram with the current node and its connections.

    Parameters:
      current_node (str): Name of the node being processed.
      current_node_details (dict): A dictionary of details for the current node.
      from_nodes (list, optional): A list of names (str) of nodes that connect to the current node.
                                   If empty or None, no parent connection is added.
      runtime (float, optional): Runtime in seconds to be added to the current node's details.

    Behavior:
      - The current node is added or updated in the JSON file.
      - If runtime is provided, it is converted to a float and stored.
      - For each name in from_nodes (if provided), a connection is created from that node to the current node.
      - If no from_nodes are provided, the current node is added/updated without any connections.
    """
    # Load or initialize the process diagram.
    if os.path.exists(JSON_PATH):
        with open(JSON_PATH, "r") as f:
            data = json.load(f)
    else:
        data = {"nodes": [], "connections": []}

    # Add runtime info (ensuring it's a float) to the current node details.
    if runtime is not None:
        try:
            current_node_details["runtime"] = float(runtime)
        except ValueError:
            raise ValueError("Runtime must be convertible to a float.")

    # Helper function: Find an existing node by name or create a new one.
    def get_or_create_node(name, details=None):
        details = details or {}
        for node in data["nodes"]:
            if node.get("name") == name:
                node.update(details)  # Update with any new details.
                return node["id"]
        node_id = str(uuid.uuid4())
        new_node = {"id": node_id, "name": name}
        new_node.update(details)
        data["nodes"].append(new_node)
        return node_id

    # Get or create the current node.
    current_node_id = get_or_create_node(current_node, current_node_details)

    # If from_nodes are provided, create connections from each to the current node.
    if from_nodes:
        for from_name in from_nodes:
            from_node_id = get_or_create_node(from_name)
            connection = {"from": from_node_id, "to": current_node_id}
            data["connections"].append(connection)

    # Save updated data to the JSON file.
    with open(JSON_PATH, "w") as f:
        json.dump(data, f, indent=2)
