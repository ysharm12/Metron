"use client";

import React, { useEffect, useState, useRef } from 'react';
import ReviewPopup from './ReviewPopup';

interface ReportStatus {
  exists: boolean;
  lastModified?: string;
  path?: string;
  reportId?: string;
  isRecent?: boolean;
  error?: string;
}

export default function WebSocketReportMonitor() {
  const [showPopup, setShowPopup] = useState(false);
  const [reportStatus, setReportStatus] = useState<ReportStatus | null>(null);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const seenReportsRef = useRef<Set<string>>(new Set());
  
  // Load seen reports from localStorage on component mount
  useEffect(() => {
    try {
      const storedReports = localStorage.getItem('optumMarketing_seenReports');
      if (storedReports) {
        seenReportsRef.current = new Set(JSON.parse(storedReports));
        console.log('Loaded seen reports from localStorage:', Array.from(seenReportsRef.current));
      }
    } catch (err) {
      console.error('Error loading seen reports from localStorage:', err);
    }
  }, []);
  
  // Save seen reports to localStorage
  const saveSeenReports = () => {
    try {
      localStorage.setItem(
        'optumMarketing_seenReports', 
        JSON.stringify(Array.from(seenReportsRef.current))
      );
    } catch (err) {
      console.error('Error saving seen reports to localStorage:', err);
    }
  };
  
  // Connect to WebSocket server
  useEffect(() => {
    const connectWebSocket = () => {
      // Close existing connection if any
      if (wsRef.current) {
        wsRef.current.close();
      }
      
      // Create new WebSocket connection
      const ws = new WebSocket('ws://localhost:8000/ws');
      wsRef.current = ws;
      
      ws.onopen = () => {
        console.log('WebSocket connected');
        setConnected(true);
        setError(null);
      };
      
      ws.onclose = () => {
        console.log('WebSocket disconnected');
        setConnected(false);
        
        // Try to reconnect after a delay
        setTimeout(connectWebSocket, 3000);
      };
      
      ws.onerror = (event) => {
        console.error('WebSocket error:', event);
        setError('Failed to connect to report monitoring service');
      };
      
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data) as ReportStatus;
          console.log('Received report status:', data);
          setReportStatus(data);
          
          // If report exists and we haven't seen it before, show popup
          if (data.exists && data.reportId && !seenReportsRef.current.has(data.reportId)) {
            console.log('New report detected, showing popup');
            setShowPopup(true);
            
            // Mark as seen
            if (data.reportId) {
              seenReportsRef.current.add(data.reportId);
              saveSeenReports();
            }
          }
        } catch (err) {
          console.error('Error processing WebSocket message:', err);
        }
      };
    };
    
    // Initial connection
    connectWebSocket();
    
    // Cleanup on unmount
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);
  
  // Handle dismissing the popup
  const dismissPopup = () => {
    setShowPopup(false);
    
    // Ensure the current report is marked as seen
    if (reportStatus?.reportId) {
      seenReportsRef.current.add(reportStatus.reportId);
      saveSeenReports();
    }
  };
  
  // Reset seen reports
  const resetSeenReports = () => {
    seenReportsRef.current.clear();
    saveSeenReports();
    
    // Notify the server
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ action: 'reset' }));
    }
    
    console.log('Reset seen reports');
  };
  
  // Handle viewing the report
  const handleViewReport = () => {
    if (reportStatus?.path) {
      // Open the report in a new tab/window
      window.open('/report-viewer', '_blank');
      dismissPopup();
    }
  };
  
  // Handle approving the report
  const handleApproveReport = async () => {
    console.log('Approving report...');
    try {
      alert('Sending approval request to FastAPI server...');
      
      const response = await fetch('http://localhost:8000/approve', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        // Add mode: 'cors' to explicitly request CORS
        mode: 'cors',
      });
      
      console.log('Response received:', response);
      
      const data = await response.json();
      console.log('Response data:', data);
      
      if (data.success) {
        // Show success message
        alert('Report approved! Next steps have been initiated.');
        dismissPopup();
      } else {
        throw new Error(data.error || 'Failed to approve report');
      }
    } catch (err) {
      console.error('Error approving report:', err);
      alert('Error approving report: ' + (err instanceof Error ? err.message : 'Unknown error'));
    }
  };
  
  return (
    <>
      {showPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full shadow-xl">
            <div className="flex items-center mb-4">
              <div className="bg-blue-100 p-2 rounded-full mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h2 className="text-xl font-bold text-gray-800">Human Review Required</h2>
            </div>
            
            <div className="mb-6">
              <p className="text-gray-600 mb-3">
                A campaign report has been generated and requires human review before proceeding.
              </p>
              <p className="text-gray-600">
                Please review the campaign report to ensure all details are correct and meet your requirements.
              </p>
            </div>
            
            <div className="flex justify-between">
              <button
                onClick={dismissPopup}
                className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded"
              >
                Close
              </button>
              
              <div className="space-x-2">
                <button
                  onClick={handleViewReport}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                >
                  View Report
                </button>
                
                <button
                  onClick={handleApproveReport}
                  className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
                >
                  Approve & Continue
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {error && (
        <div className="fixed bottom-4 left-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          <p className="font-bold">Connection Error</p>
          <p>{error}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="mt-2 bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded text-sm"
          >
            Reconnect
          </button>
        </div>
      )}
      
      {!connected && !error && (
        <div className="fixed bottom-4 left-4 bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded">
          <p>Connecting to report monitoring service...</p>
        </div>
      )}
    </>
  );
}
