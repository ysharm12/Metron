"use client";

import React, { useEffect } from 'react';
import { useReportMonitor } from '../contexts/ReportMonitorContext';
import ReviewPopup from './ReviewPopup';

export default function ClientReportMonitor() {
  const { showPopup, dismissPopup, reportStatus, isPolling, seenReports } = useReportMonitor();
  
  // Log when component mounts
  useEffect(() => {
    console.log('ClientReportMonitor mounted');
    return () => console.log('ClientReportMonitor unmounted');
  }, []);
  
  // Log when popup state changes
  useEffect(() => {
    console.log('Popup state in ClientReportMonitor:', showPopup);
  }, [showPopup]);
  
  // Log when report status changes
  useEffect(() => {
    console.log('Report status in ClientReportMonitor:', reportStatus);
  }, [reportStatus]);
  
  // Log when polling state changes
  useEffect(() => {
    console.log('Polling state in ClientReportMonitor:', isPolling);
  }, [isPolling]);
  
  // Log seen reports
  useEffect(() => {
    console.log('Seen reports in ClientReportMonitor:', seenReports);
  }, [seenReports]);
  
  if (!showPopup) {
    return null;
  }
  
  console.log('Rendering popup component');
  return <ReviewPopup onClose={dismissPopup} />;
}
