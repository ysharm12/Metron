import { useState, useEffect } from 'react';

interface AgentRuntime {
  agent_name: string;
  runtime: number;
  runtime_formatted: string;
}

interface RuntimeMetricsProps {
  className?: string;
}

export default function RuntimeMetrics({ className = '' }: RuntimeMetricsProps) {
  const [runtimeData, setRuntimeData] = useState<AgentRuntime[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [totalRuntime, setTotalRuntime] = useState<number>(0);

  useEffect(() => {
    const fetchRuntimeData = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/logs/runtime-tracker');
        const data = await response.json();
        
        if (data.exists && !data.isEmpty && data.data && data.data.formatted) {
          setRuntimeData(data.data.formatted);
          
          // Calculate total runtime
          const total = data.data.formatted.reduce(
            (sum: number, agent: AgentRuntime) => sum + agent.runtime, 
            0
          );
          setTotalRuntime(total);
        } else {
          setError(data.error || 'No runtime data available');
        }
      } catch (err) {
        setError('Failed to fetch runtime data');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchRuntimeData();
    
    // Set up polling for real-time updates
    const intervalId = setInterval(fetchRuntimeData, 10000); // Poll every 10 seconds
    
    return () => clearInterval(intervalId);
  }, []);

  // Function to calculate percentage of total runtime
  const calculatePercentage = (runtime: number) => {
    if (totalRuntime === 0) return 0;
    return (runtime / totalRuntime) * 100;
  };

  // Function to get a color based on runtime percentage
  const getBarColor = (percentage: number) => {
    if (percentage > 30) return 'bg-red-500';
    if (percentage > 15) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  if (loading) {
    return (
      <div className={`flex justify-center items-center h-64 ${className}`}>
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`bg-red-50 dark:bg-red-900 p-4 rounded-md ${className}`}>
        <p className="text-red-800 dark:text-red-200">{error}</p>
      </div>
    );
  }

  return (
    <div className={className}>
      <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Agent Runtime Distribution</h3>
      
      <div className="mb-4">
        <div className="flex justify-between mb-1">
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Total Runtime</span>
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{totalRuntime.toFixed(2)}s</span>
        </div>
      </div>
      
      <div className="space-y-4">
        {runtimeData.map((agent) => {
          const percentage = calculatePercentage(agent.runtime);
          const barColor = getBarColor(percentage);
          
          return (
            <div key={agent.agent_name} className="space-y-1">
              <div className="flex justify-between">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {agent.agent_name.replace('_', ' ')}
                </span>
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {agent.runtime_formatted} ({percentage.toFixed(1)}%)
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div 
                  className={`${barColor} h-2.5 rounded-full`} 
                  style={{ width: `${percentage}%` }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>
      
      {runtimeData.length === 0 && (
        <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-md mt-4">
          <p className="text-gray-500 dark:text-gray-400">No runtime data available.</p>
        </div>
      )}
    </div>
  );
}
