import { useState, useEffect } from 'react';

interface AgentLog {
  id: number;
  agent_name: string;
  step: number;
  process: string;
  details: string;
  time_taken: number;
  timestamp: string;
  status: string;
  task_id: string;
}

interface AgentBehaviorLogsProps {
  className?: string;
}

export default function AgentBehaviorLogs({ className = '' }: AgentBehaviorLogsProps) {
  const [logs, setLogs] = useState<AgentLog[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/logs/agentic-behavior');
        const data = await response.json();
        
        if (data.exists && !data.isEmpty && data.data && data.data.logs) {
          setLogs(data.data.logs);
        } else {
          setError(data.error || 'No logs available');
        }
      } catch (err) {
        setError('Failed to fetch logs');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchLogs();
    
    // Set up polling for real-time updates
    const intervalId = setInterval(fetchLogs, 10000); // Poll every 10 seconds
    
    return () => clearInterval(intervalId);
  }, []);

  // Filter logs based on status
  const filteredLogs = statusFilter === 'all' 
    ? logs 
    : logs.filter(log => log.status === statusFilter);

  // Function to get status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'running':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'failed':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  if (loading) {
    return (
      <div className={`flex justify-center items-center h-64 ${className}`}>
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`bg-red-50 dark:bg-red-900 p-4 rounded-md ${className}`}>
        <p className="text-red-800 dark:text-red-200">{error}</p>
      </div>
    );
  }

  return (
    <div className={className}>
      <div className="mb-4 flex flex-wrap gap-2">
        <button 
          className={`px-3 py-1 rounded-lg transition-colors ${
            statusFilter === 'all' 
              ? 'bg-blue-600 text-white' 
              : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
          }`}
          onClick={() => setStatusFilter('all')}
        >
          All Statuses
        </button>
        <button 
          className={`px-3 py-1 rounded-lg transition-colors ${
            statusFilter === 'completed' 
              ? 'bg-blue-600 text-white' 
              : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
          }`}
          onClick={() => setStatusFilter('completed')}
        >
          Completed
        </button>
        <button 
          className={`px-3 py-1 rounded-lg transition-colors ${
            statusFilter === 'running' 
              ? 'bg-blue-600 text-white' 
              : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
          }`}
          onClick={() => setStatusFilter('running')}
        >
          Running
        </button>
        <button 
          className={`px-3 py-1 rounded-lg transition-colors ${
            statusFilter === 'failed' 
              ? 'bg-blue-600 text-white' 
              : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600'
          }`}
          onClick={() => setStatusFilter('failed')}
        >
          Failed
        </button>
      </div>

      <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
            <tr>
              <th scope="col" className="px-6 py-3">ID</th>
              <th scope="col" className="px-6 py-3">Agent</th>
              <th scope="col" className="px-6 py-3">Step</th>
              <th scope="col" className="px-6 py-3">Process</th>
              <th scope="col" className="px-6 py-3">Details</th>
              <th scope="col" className="px-6 py-3">Time (s)</th>
              <th scope="col" className="px-6 py-3">Timestamp</th>
              <th scope="col" className="px-6 py-3">Status</th>
              <th scope="col" className="px-6 py-3">Task ID</th>
            </tr>
          </thead>
          <tbody>
            {filteredLogs.map((log) => (
              <tr key={log.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                <td className="px-6 py-4 font-mono text-xs">
                  {log.id}
                </td>
                <td className="px-6 py-4">
                  {log.agent_name.replace('_', ' ')}
                </td>
                <td className="px-6 py-4">
                  {log.step}
                </td>
                <td className="px-6 py-4">
                  {log.process.replace('_', ' ')}
                </td>
                <td className="px-6 py-4 max-w-xs truncate">
                  {log.details}
                </td>
                <td className="px-6 py-4 font-mono text-xs">
                  {log.time_taken.toFixed(2)}
                </td>
                <td className="px-6 py-4 font-mono text-xs">
                  {new Date(log.timestamp).toLocaleString()}
                </td>
                <td className="px-6 py-4">
                  <span className={`text-xs font-medium px-2.5 py-0.5 rounded ${getStatusColor(log.status)}`}>
                    {log.status}
                  </span>
                </td>
                <td className="px-6 py-4 font-mono text-xs">
                  {log.task_id}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {filteredLogs.length === 0 && (
        <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-md mt-4">
          <p className="text-gray-500 dark:text-gray-400">No logs found with the selected filter.</p>
        </div>
      )}
    </div>
  );
}
