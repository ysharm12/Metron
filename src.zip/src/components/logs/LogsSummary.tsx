import { useState, useEffect } from 'react';

interface LogsSummary {
  total_tasks: number;
  total_runtime: number;
  agents_count: number;
  avg_task_time: number;
  completed_tasks: number;
  running_tasks: number;
  failed_tasks: number;
}

interface LogsSummaryProps {
  className?: string;
}

export default function LogsSummaryComponent({ className = '' }: LogsSummaryProps) {
  const [summary, setSummary] = useState<LogsSummary | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSummary = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/logs/combined');
        const data = await response.json();
        
        if (data.combinedData && data.combinedData.summary) {
          setSummary(data.combinedData.summary);
        } else {
          setError('No summary data available');
        }
      } catch (err) {
        setError('Failed to fetch summary data');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchSummary();
    
    // Set up polling for real-time updates
    const intervalId = setInterval(fetchSummary, 10000); // Poll every 10 seconds
    
    return () => clearInterval(intervalId);
  }, []);

  if (loading) {
    return (
      <div className={`flex justify-center items-center h-32 ${className}`}>
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error || !summary) {
    return (
      <div className={`bg-red-50 dark:bg-red-900 p-4 rounded-md ${className}`}>
        <p className="text-red-800 dark:text-red-200">{error || 'Failed to load summary'}</p>
      </div>
    );
  }

  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 ${className}`}>
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Total Tasks</h3>
        <p className="text-2xl font-bold text-gray-900 dark:text-white">{summary.total_tasks}</p>
      </div>
      
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Total Runtime</h3>
        <p className="text-2xl font-bold text-gray-900 dark:text-white">{summary.total_runtime.toFixed(2)}s</p>
      </div>
      
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Active Agents</h3>
        <p className="text-2xl font-bold text-gray-900 dark:text-white">{summary.agents_count}</p>
      </div>
      
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Avg Task Time</h3>
        <p className="text-2xl font-bold text-gray-900 dark:text-white">{summary.avg_task_time.toFixed(2)}s</p>
      </div>
      
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 md:col-span-2 lg:col-span-4">
        <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-2">Task Status</h3>
        <div className="flex flex-wrap gap-4 mt-2">
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
            <span className="text-sm text-gray-700 dark:text-gray-300">Completed: {summary.completed_tasks}</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
            <span className="text-sm text-gray-700 dark:text-gray-300">Running: {summary.running_tasks}</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
            <span className="text-sm text-gray-700 dark:text-gray-300">Failed: {summary.failed_tasks}</span>
          </div>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700 mt-4">
          {summary.total_tasks > 0 && (
            <>
              <div 
                className="bg-green-500 h-2.5 rounded-l-full" 
                style={{ 
                  width: `${(summary.completed_tasks / summary.total_tasks) * 100}%`,
                  display: 'inline-block'
                }}
              ></div>
              <div 
                className="bg-blue-500 h-2.5" 
                style={{ 
                  width: `${(summary.running_tasks / summary.total_tasks) * 100}%`,
                  display: 'inline-block'
                }}
              ></div>
              <div 
                className="bg-red-500 h-2.5 rounded-r-full" 
                style={{ 
                  width: `${(summary.failed_tasks / summary.total_tasks) * 100}%`,
                  display: 'inline-block'
                }}
              ></div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
