import React from 'react';
import {
  SmsPreview,
  LinkedinPreview,
  TwitterPreview,
  InstagramPreview,
  DirectMailPreview
} from './previews';

interface ChannelPreviewProps {
  channel: string;
  textContent: string;
  imagePath: string;
  imageExists: boolean;
}

export default function ChannelPreview({ channel, textContent, imagePath, imageExists }: ChannelPreviewProps) {
  return (
    <div className="h-full w-full flex items-start justify-center overflow-y-auto p-4">
      {channel === 'sms' && (
        <SmsPreview textContent={textContent} />
      )}
      
      {channel === 'linkedin' && (
        <LinkedinPreview 
          textContent={textContent} 
          imagePath={imagePath} 
          imageExists={imageExists} 
        />
      )}
      
      {channel === 'twitter' && (
        <TwitterPreview 
          textContent={textContent} 
          imagePath={imagePath} 
          imageExists={imageExists} 
        />
      )}
      
      {channel === 'instagram' && (
        <InstagramPreview 
          textContent={textContent} 
          imagePath={imagePath} 
          imageExists={imageExists} 
        />
      )}
      
      {channel === 'directmail' && (
        <DirectMailPreview 
          textContent={textContent} 
          imagePath={imagePath} 
          imageExists={imageExists} 
        />
      )}
    </div>
  );
}
