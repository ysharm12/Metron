import React from 'react';

interface InstagramPreviewProps {
  textContent: string;
  imagePath: string;
  imageExists: boolean;
}

export default function InstagramPreview({ textContent, imagePath, imageExists }: InstagramPreviewProps) {
  return (
    <div className="border border-gray-300 rounded-lg overflow-hidden bg-white max-w-md mx-auto">
      {/* Instagram Header */}
      <div className="flex items-center p-3 border-b">
        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">O</div>
        <div className="ml-3">
          <p className="font-bold">optum</p>
        </div>
        <div className="ml-auto">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z" />
          </svg>
        </div>
      </div>
      
      {/* Image */}
      {imageExists && (
        <div className="w-full">
          <img 
            src={imagePath} 
            alt="Instagram post" 
            className="w-full h-auto"
            onLoad={(e) => {
              // Make container square based on image width
              const img = e.target as HTMLImageElement;
              const container = img.parentElement;
              if (container && img.naturalWidth > 0) {
                // For Instagram, maintain square aspect ratio
                container.style.height = `${container.offsetWidth}px`;
              }
            }}
          />
        </div>
      )}
      
      {/* Instagram Actions */}
      <div className="p-3 flex justify-between">
        <div className="flex space-x-4">
          <button className="text-gray-800">
            <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
          </button>
          <button className="text-gray-800">
            <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
          </button>
          <button className="text-gray-800">
            <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
          </button>
        </div>
        <button className="text-gray-800">
          <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
          </svg>
        </button>
      </div>
      
      {/* Likes */}
      <div className="px-4 pb-2">
        <p className="font-bold text-sm">128 likes</p>
      </div>
      
      {/* Caption */}
      <div className="px-4 pb-4 max-h-[200px] overflow-y-auto">
        <p className="text-sm">
          <span className="font-bold mr-1">optum</span>
          <span className="whitespace-pre-line">{textContent || 'Instagram caption will appear here'}</span>
        </p>
        <p className="text-gray-500 text-xs mt-1">View all 24 comments</p>
      </div>
    </div>
  );
}
