"use client";

import React, { useState, useEffect } from 'react';
import { IconType } from 'react-icons';

// Define types for our data structures
interface Agent {
  id: string;
  name: string;
  explanation?: string;
  runtime?: number;
  executionIndex?: number;
  isHypothetical?: boolean;
  isSimulated?: boolean;
}

interface Step {
  id: number;
  name: string;
  description?: string;
  nodeId?: string;
  nodeName?: string;
  explanation?: string;
  runtime?: number;
  executionIndex?: number;
  status?: string;
  inDevelopment?: boolean;
  phase?: string;
  completed?: boolean;
  agents?: Agent[];
  hasRealAgents?: boolean;
  tags?: string[];
  isSimulated?: boolean;
}

interface Phase {
  name: string;
  steps: Step[];
}

interface ProcessData {
  pptSteps: any[];
  nodes: any[];
  connections: any[];
  activeSteps: Step[];
  phases: Phase[];
  executionOrder: Agent[];
  animationSequence: number[];
  lastUpdated: string;
}
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FaFlag, FaFileAlt, FaDatabase, FaUsers, FaPalette, 
  FaChartBar, FaChartLine, FaCogs, FaCheckCircle, 
  FaClipboardCheck, FaEnvelope, FaRocket, FaPhoneAlt, 
  FaChartPie, FaLightbulb, FaRegThumbsUp, FaCircleNotch
} from 'react-icons/fa';

// Map step names to icons
const stepIcons: { [key: string]: IconType } = {
  "Campaign Strategy & Planning": FaFlag,
  "Intake": FaFileAlt,
  "Data Discovery": FaDatabase,
  "BRD Kick-Off": FaUsers,
  "Campaign Creative Development": FaPalette,
  "Data Request": FaDatabase,
  "Analytics Requests": FaChartBar,
  "Campaign Build & Test": FaCogs,
  "Peer QC": FaCheckCircle,
  "Counts Approval": FaClipboardCheck,
  "Approval Except Email": FaRegThumbsUp,
  "Sending Production Proofs": FaEnvelope,
  "Creating Deployment Details and Approval": FaEnvelope,
  "Approval": FaRegThumbsUp,
  "Go Live": FaRocket,
  "Campaign Inquiries Inbound Calls": FaPhoneAlt,
  "Performance Measurement": FaChartPie,
  "Optimization": FaLightbulb
};

const ProgressAnimation = ({ processData }: { processData: ProcessData }) => {
  const [activeStepIndex, setActiveStepIndex] = useState(-1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [animationSpeed, setAnimationSpeed] = useState(2000); // milliseconds per step

  const pptSteps = processData?.pptSteps || [];
  const activeSteps = processData?.activeSteps || [];
  const executionOrder = processData?.executionOrder || [];
  const phases = processData?.phases || [
    { name: "Planning Phase", steps: [] },
    { name: "Execution Phase", steps: [] },
    { name: "Delivery Phase", steps: [] }
  ];
  
  // Check if data is live (has been updated within the last 30 seconds)
  const isLiveData = processData?.lastUpdated && 
    (new Date().getTime() - new Date(processData.lastUpdated).getTime()) < 30000;
  
  // Auto-play the animation
  useEffect(() => {
    if (!isPlaying || !activeSteps.length) return;
    
    // Use the animation sequence from the API if available
    const animationSequence = processData?.animationSequence || activeSteps.map(step => step.id);
    const orderedSteps = animationSequence.map((id: number) => {
      const stepIndex = activeSteps.findIndex(step => step.id === id);
      return stepIndex !== -1 ? stepIndex : null;
    }).filter((index: number | null) => index !== null);
    
    // If we've reached the end of the animation sequence, complete the animation
    if (orderedSteps.indexOf(activeStepIndex) === orderedSteps.length - 1) {
      setIsComplete(true);
      setIsPlaying(false);
      return;
    }
    
    const timer = setTimeout(() => {
      if (activeStepIndex < activeSteps.length - 1) {
        // Find the next step in the animation sequence
        const currentPosition = orderedSteps.indexOf(activeStepIndex);
        if (currentPosition !== -1 && currentPosition < orderedSteps.length - 1) {
          // Move to the next step in the sequence
          setActiveStepIndex(orderedSteps[currentPosition + 1]);
        } else {
          // If not found in sequence, just go to the next step
          setActiveStepIndex(prev => prev + 1);
        }
      } else {
        setIsComplete(true);
        setIsPlaying(false);
      }
    }, animationSpeed); // Animation speed per step
    
    return () => clearTimeout(timer);
  }, [activeStepIndex, isPlaying, activeSteps.length, animationSpeed, processData]);
  
  // Reset animation when processData changes (backend file updated)
  useEffect(() => {
    if (processData?.animationSequence) {
      console.log('Animation sequence updated from backend:', processData.animationSequence);
      
      // If animation is currently playing, restart it with the new sequence
      if (isPlaying) {
        setIsPlaying(false);
        setTimeout(() => {
          // Start with the first step in the new animation sequence
          if (processData.animationSequence.length > 0) {
            const firstStepId = processData.animationSequence[0];
            const firstStepIndex = activeSteps.findIndex(step => step.id === firstStepId);
            if (firstStepIndex !== -1) {
              setActiveStepIndex(firstStepIndex);
            } else {
              setActiveStepIndex(0);
            }
          } else {
            setActiveStepIndex(0);
          }
          setIsPlaying(true);
          setIsComplete(false);
        }, 100);
      }
    }
  }, [processData?.animationSequence?.toString()]);

  const handlePlay = () => {
    // Reset animation state
    setIsComplete(false);
    
    // Start with the first step in the animation sequence if available
    if (processData?.animationSequence && processData.animationSequence.length > 0) {
      const firstStepId = processData.animationSequence[0];
      const firstStepIndex = activeSteps.findIndex(step => step.id === firstStepId);
      if (firstStepIndex !== -1) {
        setActiveStepIndex(firstStepIndex);
      } else {
        setActiveStepIndex(0);
      }
    } else {
      setActiveStepIndex(0);
    }
    setIsPlaying(true);
    setIsComplete(false);
  };

  const handleReset = () => {
    setActiveStepIndex(-1);
    setIsPlaying(false);
    setIsComplete(false);
  };

  const handleStepClick = (index) => {
    setActiveStepIndex(index);
    setIsPlaying(false);
  };

  if (!processData) {
    return <div>No process data available</div>;
  }

  return (
    <div className="py-4">
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md mb-4">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">About This Visualization</h2>
        <p className="text-gray-700 dark:text-gray-300 text-sm">
          This page visualizes the marketing workflow process in a vertical column layout. The steps are organized in columns based on their sequence in the marketing campaign process.
          Each step is represented by an icon and label. The highlighted steps show completed processes.
        </p>
        <div className="mt-2 p-2 bg-blue-50 dark:bg-blue-900/20 rounded border border-blue-200 dark:border-blue-800">
          <p className="text-sm text-blue-800 dark:text-blue-200">
            <strong>Note:</strong> The visualization updates automatically as processes complete in the backend. 
            The "Execution Order" shows the actual sequence of steps as they occurred in the system.
          </p>
        </div>
      </div>
      
      <div className="flex justify-between items-center mb-8">
        <div>
          <div className="flex items-center">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              Marketing Operations Workflow
            </h2>
            {isLiveData && (
              <div className="ml-3 flex items-center px-2 py-1 bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300 text-xs font-medium rounded-full">
                <div className="relative mr-1.5">
                  <FaCircleNotch className="w-3 h-3 animate-spin" />
                  <div className="absolute top-0 left-0 w-full h-full bg-green-400 rounded-full opacity-30 animate-ping"></div>
                </div>
                Live Data
              </div>
            )}
          </div>
          <p className="text-gray-600 dark:text-gray-400">
            Visualizing the automated marketing process from strategy to optimization
          </p>
        </div>
        <div className="flex space-x-3">
          <div className="flex items-center mr-4">
            <label htmlFor="speed-selector" className="mr-2 text-sm text-gray-600 dark:text-gray-400">Speed:</label>
            <select 
              id="speed-selector"
              value={animationSpeed}
              onChange={(e) => setAnimationSpeed(Number(e.target.value))}
              className="bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md px-2 py-1 text-sm"
              disabled={isPlaying}
            >
              <option value="4000">Slow</option>
              <option value="2000">Normal</option>
              <option value="1000">Fast</option>
              <option value="500">Very Fast</option>
            </select>
          </div>
          <button
            onClick={handlePlay}
            disabled={isPlaying}
            className={`px-4 py-2 rounded-md ${
              isPlaying
                ? 'bg-gray-300 cursor-not-allowed'
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            {isComplete ? 'Replay' : 'Campaign Progress'}
          </button>
          {/* <button
            onClick={handleReset}
            disabled={activeStepIndex === -1}
            className={`px-4 py-2 rounded-md ${
              activeStepIndex === -1
                ? 'bg-gray-300 cursor-not-allowed'
                : 'bg-gray-600 hover:bg-gray-700 text-white'
            }`}
          >
            Reset
          </button> */}
        </div>
      </div>

      {/* Vertical Column Layout */}
      <div className="relative w-full mb-8 bg-gray-50 dark:bg-gray-800 p-6 rounded-lg border border-gray-200 dark:border-gray-700">
        <div className="flex justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Process Flow</h3>
          <div className="flex items-center">
            <div className="flex items-center mr-4">
              <div className="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
              <span className="text-xs text-gray-600 dark:text-gray-400">Completed</span>
            </div>
            <div className="flex items-center mr-4">
              <div className="w-3 h-3 rounded-full bg-blue-600 mr-1"></div>
              <span className="text-xs text-gray-600 dark:text-gray-400">Current</span>
            </div>
            <div className="flex items-center mr-4">
              <div className="w-3 h-3 rounded-full bg-gray-300 mr-1"></div>
              <span className="text-xs text-gray-600 dark:text-gray-400">Pending</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-yellow-500 mr-1"></div>
              <span className="text-xs text-gray-600 dark:text-gray-400">Simulated (In Development)</span>
            </div>
          </div>
        </div>
        
        {/* Column headers */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          {phases.map((phase: Phase, index: number) => (
            <div key={`phase-${index}`} className="text-center">
              <h4 className="font-semibold text-blue-600 dark:text-blue-400 pb-2 border-b border-blue-200 dark:border-blue-800">
                {phase.name}
              </h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {phase.steps.length} step{phase.steps.length !== 1 ? 's' : ''}
              </p>
            </div>
          ))}
        </div>

        {/* Steps organized in columns */}
        <div className="grid grid-cols-4 gap-4 min-h-[600px]">
          {phases.map((phase: Phase, phaseIndex: number) => (
            <div key={`phase-column-${phaseIndex}`} className="flex flex-col space-y-6 items-center">
              {phase.steps.map((step: Step, stepIndex: number) => {
                // Calculate the global index for this step based on its position in the overall activeSteps array
                const globalIndex = activeSteps.findIndex(s => s.id === step.id);
                const StepIcon = stepIcons[step.name] || FaFlag;
                const isActive = globalIndex <= activeStepIndex && globalIndex !== -1;
                const isCurrent = globalIndex === activeStepIndex;
                
                return (
                  <motion.div
                    key={`step-${step.id}`}
                    className="w-full"
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ 
                      delay: stepIndex * 0.1,
                      duration: 0.5
                    }}
                  >
                    <div 
                      className={`flex flex-col p-3 rounded-lg cursor-pointer ${step.inDevelopment ? 'bg-yellow-50 dark:bg-yellow-900/20' : isActive ? 'bg-white dark:bg-gray-700' : 'bg-gray-100 dark:bg-gray-800'} border ${step.inDevelopment ? 'border-yellow-200 dark:border-yellow-800' : isActive ? 'border-blue-200 dark:border-blue-800' : 'border-gray-200 dark:border-gray-700'} shadow-sm hover:shadow-md transition-all duration-200`}
                      onClick={() => handleStepClick(globalIndex)}
                    >
                      <div className="flex items-center">
                        <motion.div
                          className={`relative rounded-full p-3 mr-3 flex-shrink-0 ${step.inDevelopment ? 'bg-yellow-500 text-white' : isActive ? isCurrent ? 'bg-blue-600 text-white' : 'bg-green-500 text-white' : 'bg-gray-200 text-gray-500'}`}
                          animate={{ 
                            scale: isCurrent ? [1, 1.1, 1] : 1,
                          }}
                          transition={{ 
                            scale: { 
                              repeat: isCurrent ? Infinity : 0, 
                              repeatType: "reverse", 
                              duration: 1.5 
                            }
                          }}
                        >
                          <StepIcon className="w-5 h-5" />
                          {isCurrent && (
                            <motion.div
                              className="absolute inset-0 rounded-full bg-blue-400 -z-10"
                              initial={{ scale: 1, opacity: 0.3 }}
                              animate={{ scale: 1.5, opacity: 0 }}
                              transition={{ 
                                repeat: Infinity, 
                                duration: 1.5,
                                ease: "easeOut" 
                              }}
                            />
                          )}
                        </motion.div>
                        <div className="flex-grow">
                          <div className="flex items-center">
                            <p className={`font-medium text-sm ${step.inDevelopment ? 'text-yellow-800 dark:text-yellow-200' : isActive ? 'text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}>
                              {step.name}
                            </p>
                            {step.inDevelopment && (
                              <span className="ml-2 px-2 py-0.5 text-xs font-medium bg-yellow-100 dark:bg-yellow-800 text-yellow-800 dark:text-yellow-200 rounded-full">
                                In Development
                              </span>
                            )}
                          </div>
                          {step.executionIndex !== undefined && (
                            <p className={`text-xs mt-1 ${step.completed ? 'text-green-600 dark:text-green-400' : 'text-blue-600 dark:text-blue-400'}`}>
                              {step.completed ? 'Completed' : 'Execution Order'}: {step.executionIndex + 1}
                            </p>
                          )}
                        </div>
                        {isActive && !step.inDevelopment && (
                          <div className="ml-2 flex-shrink-0">
                            {isCurrent ? (
                              <div className="relative">
                                <div className="w-3 h-3 rounded-full bg-blue-600"></div>
                                <div className="absolute top-0 left-0 w-full h-full rounded-full bg-blue-400 animate-ping opacity-75"></div>
                              </div>
                            ) : (
                              <div className="w-3 h-3 rounded-full bg-green-500"></div>
                            )}
                          </div>
                        )}
                      </div>
                      
                      {/* Agent information */}
                      {step.agents && step.agents.length > 0 && (
                        <div className="mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
                          <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mb-1">
                            Agents: {step.agents?.length || 0}
                          </p>
                          <div className="flex flex-wrap gap-1">
                            {step.agents?.map((agent, agentIndex) => (
                              <span 
                                key={`agent-${agent.id}`}
                                className="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
                                title={agent.name}
                              >
                                {agent.name.replace('Ephermal_', '').replace('_Specialist', '').replace('_', ' ')}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                );
              })}
              
              {/* Empty state for columns with no steps */}
              {phase.steps.length === 0 && (
                <div className="w-full h-32 flex items-center justify-center border border-dashed border-gray-300 dark:border-gray-700 rounded-lg">
                  <p className="text-sm text-gray-500 dark:text-gray-400">No steps in this phase</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Current step details */}
      <AnimatePresence mode="wait">
        {activeStepIndex >= 0 && (
          <motion.div
            key={`detail-${activeStepIndex}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className={`mt-8 p-6 rounded-lg border shadow-md ${activeSteps[activeStepIndex]?.inDevelopment ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800' : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700'}`}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0 mr-6">
                <div className={`rounded-full p-4 ${activeSteps[activeStepIndex]?.inDevelopment || activeSteps[activeStepIndex]?.isSimulated ? 'bg-yellow-500' : 'bg-blue-600'} text-white relative`}>
                  {activeStepIndex === activeSteps.findIndex(s => !s.completed) && (
                    <div className="absolute top-0 left-0 w-full h-full rounded-full bg-blue-400 animate-ping opacity-50"></div>
                  )}
                  {(() => {
                    const IconComponent = stepIcons[activeSteps[activeStepIndex]?.name] || FaFlag;
                    return <IconComponent className="w-7 h-7" />;
                  })()}
                </div>
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                      {activeSteps[activeStepIndex]?.name}
                    </h3>
                    {(activeSteps[activeStepIndex]?.inDevelopment || activeSteps[activeStepIndex]?.isSimulated) && (
                      <span className="ml-3 px-2 py-1 text-xs font-medium bg-yellow-100 dark:bg-yellow-800 text-yellow-800 dark:text-yellow-200 rounded-full">
                        {activeSteps[activeStepIndex]?.isSimulated ? 'Simulated (In Development)' : 'In Development'}
                      </span>
                    )}
                  </div>
                  {activeSteps[activeStepIndex]?.executionIndex !== undefined && (
                    <div className={`${activeSteps[activeStepIndex]?.completed ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200' : 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200'} text-xs font-medium px-2.5 py-1 rounded-full flex items-center`}>
                      {!activeSteps[activeStepIndex]?.completed && activeStepIndex === activeSteps.findIndex(s => !s.completed) && (
                        <FaCircleNotch className="w-3 h-3 mr-1.5 animate-spin" />
                      )}
                      {activeSteps[activeStepIndex]?.completed ? 'Completed' : 'Execution Order'}: {activeSteps[activeStepIndex]?.executionIndex + 1}
                    </div>
                  )}
                </div>
                
                <p className="text-gray-600 dark:text-gray-400 mt-2 leading-relaxed">
                  {activeSteps[activeStepIndex]?.description || "This step is part of the marketing campaign workflow process."}
                </p>
                
                {/* Agents involved in this step */}
                {activeSteps[activeStepIndex]?.agents && activeSteps[activeStepIndex]?.agents.length > 0 && (
                  <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-700/30 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-semibold text-gray-700 dark:text-gray-300">
                        Agents Involved:
                      </h4>
                      {activeSteps[activeStepIndex]?.isSimulated && (
                        <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300 text-xs font-medium rounded">
                          Simulated Workflow
                        </span>
                      )}
                    </div>
                    <div className="space-y-3">
                      {activeSteps[activeStepIndex]?.agents.map((agent, idx) => (
                        <div key={`detail-agent-${agent.id || idx}`} className="flex items-start">
                          <div className="flex-shrink-0 mr-2 mt-1">
                            <div className={`w-2 h-2 rounded-full ${agent.isSimulated ? 'bg-yellow-500' : 'bg-blue-500'}`}></div>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center">
                              <p className="text-gray-800 dark:text-gray-200 text-sm font-medium">
                                {agent.name.replace('Ephermal_', '').replace('_Specialist', '').replace('_', ' ')}
                              </p>
                              {agent.isSimulated && (
                                <span className="ml-2 px-1.5 py-0.5 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300 text-xs rounded">
                                  Simulated
                                </span>
                              )}
                            </div>
                            {agent.explanation && (
                              <p className="text-gray-600 dark:text-gray-400 text-sm mt-1">
                                {agent.explanation}
                              </p>
                            )}
                            <div className="flex justify-between items-center mt-1">
                              {agent.runtime !== undefined && agent.runtime > 0 && (
                                <p className="text-gray-500 dark:text-gray-500 text-xs">
                                  Runtime: {agent.runtime.toFixed(2)}s
                                </p>
                              )}
                              {agent.isSimulated && (agent.runtime === undefined || agent.runtime === 0) && (
                                <p className="text-yellow-600 dark:text-yellow-400 text-xs italic">
                                  Estimated runtime will be available in future versions
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Single agent explanation (for backward compatibility) */}
                {!activeSteps[activeStepIndex]?.agents && activeSteps[activeStepIndex]?.explanation && (
                  <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/30 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-semibold text-blue-700 dark:text-blue-300">
                        Agent Explanation:
                      </h4>
                      {activeSteps[activeStepIndex]?.isSimulated && (
                        <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300 text-xs font-medium rounded">
                          Simulated
                        </span>
                      )}
                    </div>
                    <p className="text-blue-800 dark:text-blue-200 text-sm">
                      {activeSteps[activeStepIndex]?.explanation}
                    </p>
                    {activeSteps[activeStepIndex]?.runtime > 0 && (
                      <p className="text-blue-600 dark:text-blue-300 text-xs mt-2">
                        Runtime: {activeSteps[activeStepIndex]?.runtime.toFixed(2)}s
                      </p>
                    )}
                    {activeSteps[activeStepIndex]?.isSimulated && activeSteps[activeStepIndex]?.runtime === 0 && (
                      <p className="text-yellow-600 dark:text-yellow-400 text-xs mt-2 italic">
                        Estimated runtime will be available in future versions
                      </p>
                    )}
                  </div>
                )}
                
                <div className="mt-4 flex items-center">
                  <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-blue-600"
                      initial={{ width: 0 }}
                      animate={{ 
                        width: `${((activeStepIndex + 1) / activeSteps.length) * 100}%` 
                      }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                  <span className="ml-3 text-sm text-gray-600 dark:text-gray-400">
                    {activeStepIndex + 1}/{activeSteps.length}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Step timeline */}
      <div className="mt-8 overflow-x-auto pb-4">
        <div className="flex justify-between mb-2">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Timeline</h3>
          <div className="flex space-x-4">
            <div className="flex items-center">
              <div className="relative">
                <div className="w-3 h-3 rounded-full bg-blue-600 mr-2"></div>
                <div className="absolute top-0 left-0 w-full h-full rounded-full bg-blue-400 animate-ping opacity-75"></div>
              </div>
              <span className="text-xs text-gray-600 dark:text-gray-400">In Progress</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
              <span className="text-xs text-gray-600 dark:text-gray-400">Completed</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-gray-300 mr-2"></div>
              <span className="text-xs text-gray-600 dark:text-gray-400">Pending</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
              <span className="text-xs text-gray-600 dark:text-gray-400">In Development</span>
            </div>
          </div>
        </div>
        <div className="flex space-x-2 min-w-max">
          {activeSteps.map((step, index) => {
            const isActive = index <= activeStepIndex;
            const isCurrent = index === activeStepIndex;
            const StepIcon = stepIcons[step.name] || FaFlag;
            
            return (
              <motion.button
                key={`timeline-${index}`}
                className={`flex flex-col items-center px-3 py-2 rounded-md ${
                  isCurrent 
                    ? 'bg-blue-100 dark:bg-blue-900/30' 
                    : isActive 
                      ? 'bg-green-100 dark:bg-green-900/30' 
                      : 'bg-gray-100 dark:bg-gray-800'
                }`}
                onClick={() => handleStepClick(index)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <div className={`rounded-full p-2 ${
                  isActive 
                    ? isCurrent 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-green-500 text-white' 
                    : 'bg-gray-300 text-gray-500'
                }`}>
                  <StepIcon className="w-4 h-4" />
                </div>
                <div className="flex flex-col items-center">
                  <span className={`text-xs mt-1 ${
                    isActive ? 'font-medium' : 'text-gray-500'
                  }`}>
                    {step.id}
                  </span>
                  {step.executionIndex !== undefined && (
                    <span className="text-xs text-blue-600 dark:text-blue-400">
                      ({step.executionIndex + 1})
                    </span>
                  )}
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProgressAnimation;
