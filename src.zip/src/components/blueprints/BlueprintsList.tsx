import React, { useState, useEffect } from 'react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import SearchBar from '../ui/SearchBar';
import StatusBadge from '../ui/StatusBadge';
import BlueprintEditor from './BlueprintEditor';

interface Blueprint {
  id: number;
  name: string;
  description: string;
  status: string;
  steps: number;
  lastUpdated: string;
  author: string;
  specialists?: string[];
}

// Sample data based on process_diagram.json
const blueprintsData: Blueprint[] = [
  {
    id: 1,
    name: 'Marketing Campaign Strategy',
    description: 'Complete workflow for creating marketing campaigns with AI specialists',
    status: 'Active',
    steps: 16,
    lastUpdated: '2025-03-01',
    author: 'Parent Orchestrator',
    specialists: [
      'Customer Specialist',
      'Historical Campaign Specialist',
      'Sentiment Specialist',
      'KPI Specialist',
      'Competitor Specialist',
      'AB Testing Specialist',
      'Advertising Specialist',
      'Brand Guidelines Specialist',
      'Content Writer',
      'Banner Generator Specialist'
    ]
  },
  {
    id: 2,
    name: 'Customer Analysis Blueprint',
    description: 'Analyze customer data using KMeans clustering to identify segments',
    status: 'Active',
    steps: 3,
    lastUpdated: '2025-02-28',
    author: 'Data Science Team',
    specialists: [
      'Customer Specialist',
      'Sentiment Specialist',
      'KPI Specialist'
    ]
  },
  {
    id: 3,
    name: 'Content Creation Pipeline',
    description: 'Automated content generation for marketing campaigns',
    status: 'Draft',
    steps: 4,
    lastUpdated: '2025-02-25',
    author: 'Content Team',
    specialists: [
      'Content Writer',
      'Brand Guidelines Specialist',
      'Banner Generator Specialist',
      'Strategy Specialist'
    ]
  },
  {
    id: 4,
    name: 'Competitor Analysis Workflow',
    description: 'Analyze competitors to understand market trends and opportunities',
    status: 'Pending Review',
    steps: 3,
    lastUpdated: '2025-02-20',
    author: 'Strategy Team',
    specialists: [
      'Competitor Specialist',
      'Competitor Analysis Specialist',
      'Strategy Specialist'
    ]
  },
  {
    id: 5,
    name: 'Campaign Performance Blueprint',
    description: 'Evaluate campaign performance and generate comprehensive reports',
    status: 'Active',
    steps: 5,
    lastUpdated: '2025-02-15',
    author: 'Analytics Team',
    specialists: [
      'AB Testing Specialist',
      'Advertising Specialist',
      'KPI Specialist',
      'Campaign Overview Report Specialist',
      'Historical Campaign Specialist'
    ]
  },
  {
    id: 6,
    name: 'Banner Generation Process',
    description: 'Automated banner creation based on brand guidelines and campaign strategy',
    status: 'Draft',
    steps: 3,
    lastUpdated: '2025-02-10',
    author: 'Creative Team',
    specialists: [
      'Brand Guidelines Specialist',
      'Content Writer',
      'Banner Generator Specialist'
    ]
  }
];

export default function BlueprintsList() {
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [isProcessRunning, setIsProcessRunning] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Check if the process is running by fetching the process diagram
  const checkProcessStatus = async () => {
    try {
      setIsRefreshing(true);
      const response = await fetch('/api/blueprints/process-diagram');
      const data = await response.json();
      
      // If we have more than one node and it's not the default node, process is running
      setIsProcessRunning(
        data.nodes.length > 1 || 
        (data.nodes.length === 1 && data.nodes[0].id !== 'default-node')
      );
      
      // Update the last refreshed timestamp
      setLastUpdated(new Date().toLocaleTimeString());
    } catch (error) {
      console.error('Error checking process status:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Check process status on component mount
  useEffect(() => {
    checkProcessStatus();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
            Blueprint Editor
          </h2>
          <div className="flex items-center space-x-2">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Interactive Unreal Engine-style blueprint visualization
            </p>
            {lastUpdated && (
              <p className="text-xs text-gray-500 dark:text-gray-500">
                Last updated: {lastUpdated}
              </p>
            )}
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${isProcessRunning ? 'bg-green-500' : 'bg-gray-400'}`}></div>
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {isProcessRunning ? 'Process Running' : 'Process Not Started'}
            </span>
          </div>
          <Button 
            variant="secondary" 
            onClick={checkProcessStatus}
            disabled={isRefreshing}
          >
            {isRefreshing ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Refreshing...
              </>
            ) : 'Refresh'}
          </Button>
          <Button variant="primary">Create New Blueprint</Button>
        </div>
      </div>
      
      <div className="mt-4">
        <BlueprintEditor showDetailsPanel={true} />
      </div>
    </div>
  );
}
