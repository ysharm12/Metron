import Navbar from './Navbar';
import Sidebar from './Sidebar';
import Footer from './Footer';

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <Navbar />
      <Sidebar />
      <div className="sm:ml-64 pt-16 pb-16">
        <main className="p-4 h-full">
          {children}
        </main>
      </div>
      <Footer />
    </div>
  );
}
