import React, { useState, useEffect } from 'react';
import Button from '../ui/Button';

type DocumentViewerProps = {
  documentId: string;
  documentName: string;
  documentType: string;
  onClose: () => void;
};

export default function DocumentViewer({ documentId, documentName, documentType, onClose }: DocumentViewerProps) {
  const [content, setContent] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeJsonNode, setActiveJsonNode] = useState<string | null>(null);

  useEffect(() => {
    const fetchDocument = async () => {
      try {
        setLoading(true);
        const response = await fetch(`/api/documents/${documentId}`);
        
        if (!response.ok) {
          throw new Error('Failed to fetch document');
        }
        
        const data = await response.text();
        setContent(data);
        setError(null);
      } catch (err) {
        setError('Error loading document. Please try again.');
        console.error('Error fetching document:', err);
      } finally {
        setLoading(false);
      }
    };

    if (documentId) {
      fetchDocument();
    }
  }, [documentId]);

  // Function to render CSV as a spreadsheet-like view
  const renderCsvContent = () => {
    try {
      const rows = content.split('\n').filter(row => row.trim() !== '');
      const headers = rows[0].split(',').map(header => header.trim());
      
      return (
        <div className="overflow-auto max-h-[60vh] border border-gray-200 dark:border-gray-700 rounded-lg">
          <div className="spreadsheet-container">
            <table className="w-full border-collapse">
              {/* Column Headers (A, B, C, etc.) */}
              <thead>
                <tr className="bg-gray-100 dark:bg-gray-800">
                  <th className="w-10 border border-gray-300 dark:border-gray-600 p-2 text-center sticky top-0 left-0 z-20 bg-gray-100 dark:bg-gray-800"></th>
                  {headers.map((_, index) => (
                    <th 
                      key={index} 
                      className="min-w-[100px] border border-gray-300 dark:border-gray-600 p-2 text-center sticky top-0 z-10 bg-gray-100 dark:bg-gray-800 text-xs font-medium text-gray-500 dark:text-gray-300"
                    >
                      {String.fromCharCode(65 + index)} {/* A, B, C, etc. */}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Header Row */}
                <tr className="bg-blue-50 dark:bg-blue-900/20">
                  <td className="border border-gray-300 dark:border-gray-600 p-2 text-center font-medium sticky left-0 z-10 bg-blue-50 dark:bg-blue-900/20">1</td>
                  {headers.map((header, index) => (
                    <td 
                      key={index} 
                      className="border border-gray-300 dark:border-gray-600 p-2 font-medium text-blue-700 dark:text-blue-300"
                    >
                      {header}
                    </td>
                  ))}
                </tr>
                
                {/* Data Rows */}
                {rows.slice(1).map((row, rowIndex) => {
                  const cells = row.split(',').map(cell => cell.trim());
                  return (
                    <tr key={rowIndex} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="border border-gray-300 dark:border-gray-600 p-2 text-center font-medium sticky left-0 bg-white dark:bg-gray-800 z-10">{rowIndex + 2}</td>
                      {cells.map((cell, cellIndex) => (
                        <td 
                          key={cellIndex} 
                          className="border border-gray-300 dark:border-gray-600 p-2 text-sm text-gray-700 dark:text-gray-300"
                        >
                          {cell}
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      );
    } catch (error) {
      console.error('Error rendering CSV:', error);
      return (
        <pre className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg overflow-auto max-h-[60vh] text-sm whitespace-pre-wrap">
          {content}
        </pre>
      );
    }
  };

  // Function to render JSON with structure viewer
  const renderJsonContent = () => {
    try {
      const jsonData = JSON.parse(content);
      
      // Generate the structure tree
      const renderJsonTree = (data: any, path: string = '') => {
        if (typeof data === 'object' && data !== null) {
          return (
            <ul className="pl-4">
              {Object.keys(data).map((key) => {
                const currentPath = path ? `${path}.${key}` : key;
                const isArray = Array.isArray(data);
                const displayKey = isArray ? `[${key}]` : key;
                const isObject = typeof data[key] === 'object' && data[key] !== null;
                
                return (
                  <li key={currentPath} className="my-1">
                    <div 
                      className={`flex items-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 p-1 rounded ${activeJsonNode === currentPath ? 'bg-blue-100 dark:bg-blue-900/30' : ''}`}
                      onClick={() => setActiveJsonNode(currentPath)}
                    >
                      <span className="mr-2">{isObject ? '▶' : '•'}</span>
                      <span className="font-medium">{displayKey}</span>
                      {!isObject && (
                        <span className="ml-2 text-gray-500 dark:text-gray-400 text-xs">
                          ({typeof data[key]})
                        </span>
                      )}
                    </div>
                    {isObject && renderJsonTree(data[key], currentPath)}
                  </li>
                );
              })}
            </ul>
          );
        }
        return null;
      };
      
      // Get the selected node value
      const getNodeValue = (data: any, path: string | null) => {
        if (!path) return data;
        
        const parts = path.split('.');
        let current = data;
        
        for (const part of parts) {
          if (current === undefined || current === null) return undefined;
          current = current[part];
        }
        
        return current;
      };
      
      const selectedValue = getNodeValue(jsonData, activeJsonNode);
      const formattedSelectedValue = typeof selectedValue === 'object' && selectedValue !== null
        ? JSON.stringify(selectedValue, null, 2)
        : String(selectedValue);
      
      return (
        <div className="grid grid-cols-2 gap-4 h-[60vh]">
          {/* Structure Tree */}
          <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg overflow-auto border border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-semibold mb-2 text-gray-700 dark:text-gray-300">JSON Structure</h3>
            {renderJsonTree(jsonData)}
          </div>
          
          {/* Content Viewer */}
          <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg overflow-auto border border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-semibold mb-2 text-gray-700 dark:text-gray-300">
              {activeJsonNode ? `Value: ${activeJsonNode}` : 'Full JSON'}
            </h3>
            <pre className="text-sm whitespace-pre-wrap">
              {formattedSelectedValue}
            </pre>
          </div>
        </div>
      );
    } catch (error) {
      console.error('Error parsing JSON:', error);
      return (
        <pre className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg overflow-auto max-h-[60vh] text-sm whitespace-pre-wrap">
          {content}
        </pre>
      );
    }
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        </div>
      );
    }

    if (error) {
      return (
        <div className="text-center text-red-500 p-4">
          <p>{error}</p>
        </div>
      );
    }

    if (documentType === 'JSON') {
      return renderJsonContent();
    }

    if (documentType === 'CSV') {
      return renderCsvContent();
    }

    if (documentType === 'HTML') {
      return (
        <div 
          className="bg-white dark:bg-gray-800 p-4 rounded-lg overflow-auto max-h-[60vh] border border-gray-200 dark:border-gray-700"
          dangerouslySetInnerHTML={{ __html: content }}
        />
      );
    }

    // Default: Plain text
    return (
      <pre className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg overflow-auto max-h-[60vh] text-sm whitespace-pre-wrap border border-gray-200 dark:border-gray-700">
        {content}
      </pre>
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4">
      <div className="bg-white dark:bg-gray-900 rounded-lg shadow-xl w-full max-w-5xl max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center p-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
            <span className="mr-2">{documentName}</span> 
            <span className="text-sm px-2 py-1 bg-gray-100 rounded-md font-medium dark:bg-gray-700 text-gray-600 dark:text-gray-300">
              {documentType.toLowerCase()}
            </span>
          </h2>
          <div className="flex space-x-2">
            <Button 
              variant="primary" 
              size="sm" 
              onClick={() => window.open(`/api/documents/${documentId}`, '_blank')}
            >
              Download
            </Button>
            <Button variant="secondary" size="sm" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
        
        <div className="p-4">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}
