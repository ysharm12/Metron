import React, { useState, useEffect } from 'react';
import DataTable from '../ui/DataTable';
import StatusBadge from '../ui/StatusBadge';
import SearchBar from '../ui/SearchBar';
import Button from '../ui/Button';
import Pagination from '../ui/Pagination';
import DocumentViewer from './DocumentViewer';

type Document = {
  id: string;
  name: string;
  type: string;
  size: string;
  status: string;
  lastModified: string;
  author: string;
  path?: string;
};

export default function DocumentsTable() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const itemsPerPage = 10;

  // Fetch documents from API
  useEffect(() => {
    const fetchDocuments = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/documents');
        
        if (!response.ok) {
          throw new Error('Failed to fetch documents');
        }
        
        const data = await response.json();
        setDocuments(data.documents);
        setError(null);
      } catch (err) {
        setError('Error loading documents. Please try again.');
        console.error('Error fetching documents:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchDocuments();
  }, []);

  // Filter documents based on search query
  const filteredDocuments = documents.filter(doc => 
    doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Calculate pagination
  const totalPages = Math.ceil(filteredDocuments.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedDocuments = filteredDocuments.slice(startIndex, startIndex + itemsPerPage);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentPage(1); // Reset to first page on new search
  };

  const handleViewDocument = (document: Document) => {
    setSelectedDocument(document);
  };

  const handleCloseViewer = () => {
    setSelectedDocument(null);
  };

  const handleDownloadDocument = (documentId: string) => {
    window.open(`/api/documents/${documentId}`, '_blank');
  };

  // Define columns for the data table
  const columns = [
    { header: 'Name', accessor: 'name' },
    { header: 'Type', accessor: (doc: Document) => (
      <span className="px-2 py-1 bg-gray-100 rounded-md text-xs font-medium dark:bg-gray-700">
        {doc.type}
      </span>
    )},
    { header: 'Size', accessor: 'size' },
    { header: 'Status', accessor: (doc: Document) => (
      <StatusBadge status={doc.status} />
    )},
    { header: 'Last Modified', accessor: 'lastModified' },
    { header: 'Author', accessor: 'author' },
    { header: 'Actions', accessor: (doc: Document) => (
      <div className="flex space-x-2">
        <Button variant="primary" size="sm" onClick={() => handleViewDocument(doc)}>View</Button>
        <Button variant="secondary" size="sm" onClick={() => handleDownloadDocument(doc.id)}>Download</Button>
      </div>
    )}
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-red-500 p-4">
        <p>{error}</p>
        <Button variant="primary" className="mt-4" onClick={() => window.location.reload()}>Retry</Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <SearchBar 
          placeholder="Search documents..." 
          onSearch={handleSearch} 
          className="w-full sm:w-64"
        />
        
        <div className="flex flex-wrap gap-2">
          <Button variant="primary">Upload Document</Button>
          <Button variant="secondary">Export List</Button>
        </div>
      </div>
      
      {documents.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500 dark:text-gray-400">No documents found.</p>
        </div>
      ) : (
        <>
          <DataTable 
            columns={columns} 
            data={paginatedDocuments} 
            onRowClick={handleViewDocument}
          />
          
          <Pagination 
            currentPage={currentPage}
            totalPages={totalPages > 0 ? totalPages : 1}
            onPageChange={setCurrentPage}
          />
        </>
      )}
      
      {selectedDocument && (
        <DocumentViewer 
          documentId={selectedDocument.id}
          documentName={selectedDocument.name}
          documentType={selectedDocument.type}
          onClose={handleCloseViewer}
        />
      )}
    </div>
  );
}
