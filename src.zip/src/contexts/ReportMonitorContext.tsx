"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface ReportStatus {
  exists: boolean;
  lastModified?: string;
  isRecent?: boolean;
  path?: string;
}

interface ReportMonitorContextType {
  reportStatus: ReportStatus | null;
  showPopup: boolean;
  error: string | null;
  isPolling: boolean;
  dismissPopup: () => void;
  resetMonitor: () => void;
  startPolling: () => void;
  stopPolling: () => void;
  seenReports: Set<string>;
}

const ReportMonitorContext = createContext<ReportMonitorContextType | undefined>(undefined);

export function useReportMonitor() {
  const context = useContext(ReportMonitorContext);
  if (context === undefined) {
    throw new Error('useReportMonitor must be used within a ReportMonitorProvider');
  }
  return context;
}

interface ReportMonitorProviderProps {
  children: ReactNode;
  pollingInterval?: number;
}

// Key for localStorage
const SEEN_REPORTS_KEY = 'optumMarketing_seenReports';

// Helper function to get seen reports from localStorage
const getSeenReportsFromStorage = (): Set<string> => {
  if (typeof window === 'undefined') return new Set();
  
  try {
    const storedReports = localStorage.getItem(SEEN_REPORTS_KEY);
    if (storedReports) {
      return new Set(JSON.parse(storedReports));
    }
  } catch (err) {
    console.error('Error reading from localStorage:', err);
  }
  return new Set();
};

// Helper function to save seen reports to localStorage
const saveSeenReportsToStorage = (reports: Set<string>) => {
  if (typeof window === 'undefined') return;
  
  try {
    localStorage.setItem(SEEN_REPORTS_KEY, JSON.stringify(Array.from(reports)));
  } catch (err) {
    console.error('Error saving to localStorage:', err);
  }
};

export function ReportMonitorProvider({ 
  children, 
  pollingInterval = 1000 // Reduced to 1 second for more real-time monitoring
}: ReportMonitorProviderProps) {
  const [reportStatus, setReportStatus] = useState<ReportStatus | null>(null);
  const [isPolling, setIsPolling] = useState(true);
  const [showPopup, setShowPopup] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [seenReports, setSeenReports] = useState<Set<string>>(() => {
    // Initialize from localStorage on component mount
    return getSeenReportsFromStorage();
  });

  // Function to check for the report
  const checkForReport = async () => {
    try {
      // Add a cache-busting parameter to prevent browser caching
      const cacheBuster = new Date().getTime();
      console.log('Checking for report file...', cacheBuster);
      const response = await fetch(`/api/check-report?t=${cacheBuster}`);
      
      if (!response.ok) {
        throw new Error('Failed to check for report');
      }
      
      const data = await response.json();
      console.log('Report check response:', data);
      
      // Update the report status
      setReportStatus(data);
      
      console.log('API response data:', data);
      console.log('Current seenReports:', Array.from(seenReports));
      
      // If the report exists and we haven't seen it before, show the popup
      if (data.exists) {
        // Use just the path as the identifier - this way once we've seen a report at this path,
        // we won't show it again even if it's deleted and recreated
        const reportPath = data.path;
        console.log('Report path:', reportPath);
        console.log('Has seen this report before?', seenReports.has(reportPath));
        
        // Only show popup if we haven't seen a report at this path before
        if (!seenReports.has(reportPath) && !showPopup) {
          console.log('New report detected! Showing popup...', reportPath);
          setShowPopup(true);
          
          // Add this report path to the seen reports
          const updatedSeenReports = new Set(seenReports);
          updatedSeenReports.add(reportPath);
          setSeenReports(updatedSeenReports);
          
          // Save to localStorage
          saveSeenReportsToStorage(updatedSeenReports);
          console.log('Updated seenReports:', Array.from(updatedSeenReports));
        } else {
          console.log('Report already seen or popup already showing. No action needed.');
        }
      } else {
        console.log('Report does not exist. No action needed.');
      }
      
      setError(null);
    } catch (err) {
      console.error('Error checking for report:', err);
      setError(err instanceof Error ? err.message : 'Unknown error');
    }
  };

  // Start/stop polling
  useEffect(() => {
    if (!isPolling) return;
    
    // Check immediately on mount
    checkForReport();
    
    // Set up polling interval
    const intervalId = setInterval(checkForReport, pollingInterval);
    
    // Clean up on unmount
    return () => clearInterval(intervalId);
  }, [isPolling, pollingInterval]);

  // Reset function to start polling again
  const resetMonitor = () => {
    setShowPopup(false);
    setReportStatus(null);
    setIsPolling(true);
    
    // Clear the seen reports both in state and localStorage
    setSeenReports(new Set());
    saveSeenReportsToStorage(new Set());
  };

  // Function to dismiss the popup
  const dismissPopup = () => {
    setShowPopup(false);
    
    // Ensure the current report path is saved to localStorage
    if (reportStatus?.path) {
      const updatedSeenReports = new Set(seenReports);
      updatedSeenReports.add(reportStatus.path);
      setSeenReports(updatedSeenReports);
      saveSeenReportsToStorage(updatedSeenReports);
    }
  };

  const value = {
    reportStatus,
    showPopup,
    error,
    isPolling,
    dismissPopup,
    resetMonitor,
    startPolling: () => setIsPolling(true),
    stopPolling: () => setIsPolling(false),
    seenReports,
  };

  return (
    <ReportMonitorContext.Provider value={value}>
      {children}
    </ReportMonitorContext.Provider>
  );
}
