"use client"
import MainLayout from '../../components/MainLayout';
import BlueprintsList from '../../components/blueprints/BlueprintsList';
import Card from '../../components/ui/Card';

export default function BlueprintsPage() {
  return (
    <MainLayout>
      <Card>
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Campaign Blueprints</h1>
        </div>
        
        <BlueprintsList />
      </Card>
    </MainLayout>
  );
}
