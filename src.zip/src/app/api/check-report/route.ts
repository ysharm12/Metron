import { NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

// Path to the campaign report file
const REPORT_FILE_PATH = path.resolve(process.cwd(), '..', 'backend', 'output', 'campaign_report.html');
console.log('Looking for report file at:', REPORT_FILE_PATH);

export const dynamic = 'force-dynamic'; // Disable caching for this route

export async function GET() {
  try {
    // Check if the report file exists
    try {
      // Force a fresh check of the file system
      await fs.access(REPORT_FILE_PATH, fs.constants.F_OK);
      
      // Get file stats to check when it was last modified
      const stats = await fs.stat(REPORT_FILE_PATH);
      const lastModified = stats.mtime;
      
      // Consider files modified in the last 30 minutes as recent
      // This gives more time for users to see the notification
      const thirtyMinutesAgo = new Date(Date.now() - 30 * 60 * 1000);
      const isRecent = lastModified > thirtyMinutesAgo;
      
      // Create a unique identifier for this report - use just the filename and timestamp
      // This makes it more consistent across different environments
      const filename = REPORT_FILE_PATH.split('/').pop() || 'campaign_report.html';
      const reportId = `${filename}-${lastModified.toISOString()}`;
      
      return NextResponse.json({
        exists: true,
        lastModified: lastModified.toISOString(),
        isRecent,
        path: REPORT_FILE_PATH,
        reportId
      });
    } catch (error) {
      // File doesn't exist
      console.log('File not found, returning exists=false');
      
      return NextResponse.json({
        exists: false,
        path: REPORT_FILE_PATH
      });
    }
  } catch (error) {
    console.error('Error checking for report file:', error);
    return NextResponse.json(
      { error: 'Failed to check for report file', details: String(error) },
      { status: 500 }
    );
  }
}
