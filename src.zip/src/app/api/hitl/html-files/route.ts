import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET() {
  try {
    // Path to the backend output directory
    const outputDir = path.join(process.cwd(), '..', 'backend', 'output');
    
    // Check if the directory exists
    if (!fs.existsSync(outputDir)) {
      return NextResponse.json({ files: [] });
    }
    
    // Get all HTML files in the directory
    const files = fs.readdirSync(outputDir)
      .filter(file => file.endsWith('.html'))
      .map(file => ({
        name: file,
        path: `/api/hitl/file-content?filename=${encodeURIComponent(file)}`,
        lastModified: fs.statSync(path.join(outputDir, file)).mtime.toISOString()
      }));
    
    return NextResponse.json({ files });
  } catch (error) {
    console.error('Error fetching HTML files:', error);
    return NextResponse.json({ error: 'Failed to fetch HTML files' }, { status: 500 });
  }
}
