import { NextResponse } from 'next/server';
import path from 'path';
import fs from 'fs/promises';
import { spawn } from 'child_process';

// Helper function to execute a Python script and return a promise
function executePython(scriptPath: string, args: string[], cwd: string): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    let stdout = '';
    let stderr = '';
    
    console.log(`Executing Python in directory: ${cwd}`);
    console.log(`Command: python ${scriptPath} ${args.join(' ')}`);
    
    const process = spawn('python', [scriptPath, ...args], {
      cwd: cwd // Set the working directory for the Python process
    });
    
    process.stdout.on('data', (data) => {
      const output = data.toString();
      stdout += output;
      console.log(`Python stdout: ${output}`);
    });
    
    process.stderr.on('data', (data) => {
      const output = data.toString();
      stderr += output;
      console.error(`Python stderr: ${output}`);
    });
    
    process.on('close', (code) => {
      console.log(`Python process exited with code ${code}`);
      if (code === 0) {
        resolve({ stdout, stderr });
      } else {
        reject(new Error(`Python process exited with code ${code}\n${stderr}`));
      }
    });
    
    process.on('error', (err) => {
      console.error(`Python process error: ${err.message}`);
      reject(err);
    });
  });
}

export async function POST(request: Request) {
  let tempDataFile = '';
  
  try {
    // Parse the request body
    const data = await request.json();
    
    // Validate required fields
    const requiredFields = ['trigger_type', 'campaign_name', 'goal', 'audience', 'budget', 'requested_date'];
    for (const field of requiredFields) {
      if (!data[field]) {
        return NextResponse.json(
          { error: `Missing required field: ${field}` },
          { status: 400 }
        );
      }
    }
    
    // Create a temporary JSON file with the form data in the backend directory
    const backendDir = path.resolve(process.cwd(), '..', 'backend');
    tempDataFile = path.join(backendDir, `temp_campaign_data_${Date.now()}.json`);
    await fs.writeFile(tempDataFile, JSON.stringify(data, null, 2));
    
    console.log('Created temporary data file:', tempDataFile);
    console.log('Form data:', JSON.stringify(data, null, 2));
    
    // For debugging - log the current working directory
    console.log('Current working directory:', process.cwd());
    
    // We already defined backendDir above when creating the temp file
    console.log('Backend directory:', backendDir);
    
    // Path to the Python script (using relative path from backend directory)
    const scriptName = 'execute_campaign.py';
    const scriptPath = path.join(backendDir, scriptName);
    console.log('Python script path:', scriptPath);
    
    // Check if the script exists
    try {
      await fs.access(scriptPath);
      console.log('Python script exists');
    } catch (err) {
      console.error('Python script does not exist:', err);
      return NextResponse.json(
        { error: 'Python script not found', details: scriptPath },
        { status: 500 }
      );
    }
    
    // Execute the Python script with the path to our data file
    console.log('Executing Python script...');
    const { stdout, stderr } = await executePython(scriptName, [tempDataFile], backendDir);
    
    console.log('Python script output:', stdout);
    
    if (stderr) {
      console.error('Error executing Python script:', stderr);
    }
    
    // Clean up the temporary file
    try {
      await fs.unlink(tempDataFile);
      console.log('Temporary file deleted');
    } catch (err) {
      console.error('Error deleting temporary file:', err);
    }
    
    return NextResponse.json({ 
      success: true, 
      message: 'Campaign started successfully',
      details: stdout
    });
    
  } catch (error) {
    console.error('API error:', error);
    
    // Clean up the temporary file if it exists
    if (tempDataFile) {
      try {
        await fs.unlink(tempDataFile);
        console.log('Temporary file deleted after error');
      } catch (err) {
        console.error('Error deleting temporary file after error:', err);
      }
    }
    
    return NextResponse.json(
      { 
        error: 'Failed to process request', 
        message: error instanceof Error ? error.message : String(error),
        details: String(error) 
      },
      { status: 500 }
    );
  }
}
