import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

// Default node structure to return when the process hasn't been started
const defaultNodeStructure = {
  nodes: [
    {
      id: 'default-node',
      name: 'Process Not Started',
      explanation: 'The marketing campaign process has not been initiated yet. Use the trigger page to start a new campaign.',
      runtime: 0
    }
  ],
  connections: []
};

export async function GET() {
  try {
    // Path to the process_diagram.json file
    const filePath = path.join(process.cwd(), '..', 'backend', 'output', 'process_diagram.json');
    const alternativePath = path.join(process.cwd(), 'backend', 'output', 'process_diagram.json');
    
    let fileExists = fs.existsSync(filePath);
    let actualPath = filePath;
    
    // Try alternative path if the first one doesn't exist
    if (!fileExists) {
      fileExists = fs.existsSync(alternativePath);
      actualPath = alternativePath;
    }
    
    // If file doesn't exist in either location, return default structure
    if (!fileExists) {
      console.log('Process diagram file not found, returning default structure');
      return NextResponse.json(defaultNodeStructure);
    }
    
    // Read the file contents
    const fileContents = fs.readFileSync(actualPath, 'utf8');
    
    // Check if file is empty
    if (!fileContents || fileContents.trim() === '') {
      console.log('Process diagram file is empty, returning default structure');
      return NextResponse.json(defaultNodeStructure);
    }
    
    try {
      // Parse the JSON
      const processData = JSON.parse(fileContents);
      
      // Validate that the JSON has the expected structure
      if (!processData.nodes || !Array.isArray(processData.nodes) || processData.nodes.length === 0) {
        console.log('Process diagram has invalid structure, returning default');
        return NextResponse.json(defaultNodeStructure);
      }
      
      // Return the data
      return NextResponse.json(processData);
    } catch (parseError) {
      console.error('Error parsing JSON:', parseError);
      return NextResponse.json(defaultNodeStructure);
    }
  } catch (error) {
    console.error('Error reading process diagram:', error);
    
    // Return the default structure in case of any error
    return NextResponse.json(defaultNodeStructure);
  }
}
