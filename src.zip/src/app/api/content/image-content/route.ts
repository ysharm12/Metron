import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const channel = searchParams.get('channel');
  
  if (!channel) {
    return NextResponse.json({ error: 'Channel parameter is required' }, { status: 400 });
  }
  
  const validChannels = ['linkedin', 'twitter', 'instagram', 'directmail'];
  if (!validChannels.includes(channel)) {
    return NextResponse.json({ error: 'Invalid channel' }, { status: 400 });
  }
  
  const outputDir = path.join(process.cwd(), '..', 'backend', 'output', 'images');
  const filename = `banner_${channel}.png`;
  const filePath = path.join(outputDir, filename);
  
  try {
    if (!fs.existsSync(filePath)) {
      return NextResponse.json({ exists: false }, { status: 200 });
    }
    
    // We'll just check if the file exists and return the path
    // The actual image will be served via a separate endpoint
    return NextResponse.json({ 
      imagePath: `/api/content/image/${filename}`,
      exists: true 
    }, { status: 200 });
  } catch (error) {
    console.error('Error checking image:', error);
    return NextResponse.json({ error: 'Failed to check image' }, { status: 500 });
  }
}
