import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function POST(request: Request) {
  try {
    const { channel, content } = await request.json();
    
    if (!channel || content === undefined) {
      return NextResponse.json({ error: 'Channel and content are required' }, { status: 400 });
    }
    
    const validChannels = ['sms', 'linkedin', 'twitter', 'instagram', 'directmail'];
    if (!validChannels.includes(channel)) {
      return NextResponse.json({ error: 'Invalid channel' }, { status: 400 });
    }
    
    const outputDir = path.join(process.cwd(), '..', 'backend', 'output');
    
    // Ensure the output directory exists
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    
    const filename = `${channel}.txt`;
    const filePath = path.join(outputDir, filename);
    
    fs.writeFileSync(filePath, content, 'utf8');
    
    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    console.error('Error saving content:', error);
    return NextResponse.json({ error: 'Failed to save content' }, { status: 500 });
  }
}
