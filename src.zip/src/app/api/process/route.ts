import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET() {
  try {
    // Try multiple possible paths to find the process_diagram.json file
    const possiblePaths = [
      // Local copies (preferred)
      path.join(process.cwd(), 'src/app/api/process/data/process_diagram.json'),
      path.join(process.cwd(), 'public/data/process_diagram.json'),
      // Original locations (fallback)
      path.join(process.cwd(), '../../../backend/output/process_diagram.json'),
      path.join(process.cwd(), '../../backend/output/process_diagram.json'),
      path.join(process.cwd(), '../backend/output/process_diagram.json'),
      '/Users/yash/Documents/optummarketing/backend/output/process_diagram.json'
    ];
    
    console.log('Attempting to find process_diagram.json in the following paths:');
    possiblePaths.forEach(p => console.log('- ' + p));
    
    let filePath = null;
    let fileContent = null;
    
    // Try each path until we find one that exists
    for (const p of possiblePaths) {
      if (fs.existsSync(p)) {
        filePath = p;
        console.log('Found process_diagram.json at:', filePath);
        fileContent = fs.readFileSync(filePath, 'utf8');
        break;
      }
    }
    
    // If no file was found, try to use the sample data
    if (!filePath || !fileContent) {
      console.warn('Process diagram file not found in any of the attempted paths, using sample data');
      try {
        const sampleDataPath = path.join(process.cwd(), 'src/app/api/process/sample-data.json');
        if (fs.existsSync(sampleDataPath)) {
          fileContent = fs.readFileSync(sampleDataPath, 'utf8');
          console.log('Successfully loaded sample data');
        } else {
          console.error('Sample data file not found either');
          return NextResponse.json({ 
            error: 'Process diagram file not found', 
            attemptedPaths: [...possiblePaths, sampleDataPath] 
          }, { status: 404 });
        }
      } catch (sampleError) {
        console.error('Error loading sample data:', sampleError);
        return NextResponse.json({ 
          error: 'Failed to load process diagram data and sample data', 
          message: sampleError instanceof Error ? sampleError.message : String(sampleError)
        }, { status: 500 });
      }
    }
    
    // Parse the JSON content
    const processData = JSON.parse(fileContent);
    
    // Return the data
    return NextResponse.json(processData, { status: 200 });
  } catch (error) {
    console.error('Error fetching process diagram data:', error);
    return NextResponse.json({ 
      error: 'Failed to fetch process diagram data', 
      message: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
