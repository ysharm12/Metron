import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

// Define the PPT steps in order with their business-friendly names
const pptSteps = [
  { id: 1, name: "Campaign Strategy & Planning", description: "Company goals, target audience & KPIs" },
  { id: 2, name: "Intake", description: "By MPM & IMM, AHA/Rally/Workfront/ServiceNow" },
  { id: 3, name: "Data Discovery", description: "By MPM & IMM, Data availability: Target audience/Segmentation" },
  { id: 4, name: "BRD Kick-Off", description: "Business requirements definition" },
  { id: 5, name: "Campaign Creative Development", description: "Creative Content, Messages, Videos, Images" },
  { id: 6, name: "Data Request", description: "Data ingestion, Transformations, Loading, Scheduling" },
  { id: 7, name: "Analytics Requests", description: "Segment Journey, Sizing, Market Assessment" },
  { id: 8, name: "Campaign Build & Test", description: "Campaign Journey Workflow" },
  { id: 9, name: "Peer QC", description: "Quality control review" },
  { id: 10, name: "Counts Approval", description: "Measures & PM" },
  { id: 11, name: "Approval Except Email", description: "Review and approval of non-email content" },
  { id: 11.1, name: "Sending Production Proofs", description: "Email" },
  { id: 11.2, name: "Creating Deployment Details and Approval", description: "Only for emails" },
  { id: 12, name: "Approval", description: "Final approval before launch" },
  { id: 13, name: "Go Live", description: "Campaign launch" },
  { id: 13.1, name: "Campaign Inquiries Inbound Calls", description: "Customer support" },
  { id: 14, name: "Performance Measurement", description: "Analytics and reporting" },
  { id: 15, name: "Optimization", description: "Continuous improvement" }
];

// Dynamic mapping rules based on node name patterns according to the document
function mapNodeToPptStep(nodeName) {
  // 1. Campaign Strategy & Planning
  if (nodeName.includes('Parent_Orchestrator')) return "Campaign Strategy & Planning";
  if (nodeName.includes('Trigger_Specialist')) return "Campaign Strategy & Planning";
  if (nodeName.includes('Ephermal_Market_Research_Agent')) return "Campaign Strategy & Planning";
  
  // 2. Data Discovery & Analysis
  if (nodeName.includes('Ephermal_Customer_Specialist') || nodeName.includes('Customer_Specialist')) return "Data Discovery";
  if (nodeName.includes('Ephermal_Historical_Campaign_Specialist') || nodeName.includes('Historical_Campaign_Specialist')) return "Data Discovery";
  if ((nodeName.includes('Ephermal_Sentiment_Specialist') || nodeName.includes('Sentiment_Specialist')) && !nodeName.includes('Analysis')) return "Data Discovery";
  if (nodeName.includes('Ephermal_KPI_Specialist') || nodeName.includes('KPI_Specialist')) return "Data Discovery";
  if ((nodeName.includes('Ephermal_Competitor_Specialist') || nodeName.includes('Competitor_Specialist')) && !nodeName.includes('Analysis')) return "Data Discovery";
  if (nodeName.includes('Ephermal_AB_Testing_Specialist') || nodeName.includes('AB_Testing_Specialist')) return "Data Discovery";
  if (nodeName.includes('Ephermal_Advertising_Specialist') || nodeName.includes('Advertising_Specialist')) return "Data Discovery";
  if (nodeName.includes('Ephermal_Influencer_Discovery_Agent')) return "Data Discovery";
  
  // 3. Creating/Deployment Checks and Approval
  if (nodeName.includes('Ephermal_Brand_Guidelines_Specialist') || nodeName.includes('Brand_Guidelines_Specialist')) return "Creating Deployment Details and Approval";
  if (nodeName.includes('Ephermal_Campaign_Overview_Report_Specialist') || nodeName.includes('Campaign_Overview_Report_Specialist')) return "Creating Deployment Details and Approval";
  if (nodeName.includes('Ephermal_Strategy_Specialist') || nodeName.includes('Strategy_Specialist')) return "Creating Deployment Details and Approval";
  if (nodeName.includes('Ephermal_Legal_Approval_Agent')) return "Creating Deployment Details and Approval";
  if (nodeName.includes('Ephermal_Compliance_Agent')) return "Creating Deployment Details and Approval";
  
  // 4. Data Proof
  if (nodeName.includes('Ephermal_Data_Validation_Agent')) return "Data Request";
  if (nodeName.includes('Ephermal_Budget_Allocation_Agent')) return "Data Request";
  
  // 6. Campaign Build & Test
  if (nodeName.includes('Ephermal_Content_Writer') || nodeName.includes('Content_Writer')) return "Campaign Build & Test";
  if (nodeName.includes('Ephermal_Banner_Generator_Specialist') || nodeName.includes('Banner_Generator_Specialist')) return "Campaign Build & Test";
  if (nodeName.includes('Ephermal_Email_Templating_Agent')) return "Campaign Build & Test";
  if (nodeName.includes('Ephermal_QA_Agent')) return "Campaign Build & Test";
  
  // 7. Creative Deployment Proofs
  if (nodeName.includes('Ephermal_Proofing_Agent')) return "Sending Production Proofs";
  if (nodeName.includes('Ephermal_Translation_Agent')) return "Sending Production Proofs";
  if (nodeName.includes('Ephermal_Sentiment_Analysis_Specialist') || nodeName.includes('Sentiment_Analysis_Specialist')) return "Sending Production Proofs";
  
  // 8. Custom Approval
  if (nodeName.includes('Ephermal_Stakeholder_Review_Agent')) return "Approval";
  if (nodeName.includes('Ephermal_Feedback_Processor')) return "Approval";
  
  // 9. Go Live
  if (nodeName.includes('Ephermal_Deployment_Orchestrator')) return "Go Live";
  
  // 10. Performance Measurement
  if (nodeName.includes('Ephermal_RealTime_Monitoring_Agent')) return "Performance Measurement";
  if (nodeName.includes('Ephermal_KPI_Tracking_Agent')) return "Performance Measurement";
  
  // 11. Optimization
  if (nodeName.includes('Ephermal_Auto_A_B_Testing_Agent')) return "Optimization";
  if (nodeName.includes('Ephermal_Budget_Reallocation_Agent')) return "Optimization";
  
  // 12. Performance Measurement (Final Stage)
  if (nodeName.includes('Ephermal_Campaign_Simulation_Agent')) return "Campaign Inquiries Inbound Calls";
  if (nodeName.includes('Ephermal_Performance_Report_Agent')) return "Campaign Inquiries Inbound Calls";
  
  // Legacy mappings for backward compatibility
  if (nodeName.includes('Ephermal_Competitor_Analysis_Specialist') || nodeName.includes('Competitor_Analysis_Specialist')) return "Analytics Requests";
  
  // If no match found, return null
  return null;
}

// Function to get the execution index based on the step name from pptSteps array
function getStepExecutionIndex(stepName: string): number {
  const step = pptSteps.find(s => s.name === stepName);
  return step ? step.id : 999; // Default to a high number if not found
}

// Function to check if an agent is hypothetical (in development)
function isHypotheticalAgent(agentName: string): boolean {
  // List of hypothetical agents based on the provided documentation
  const hypotheticalAgents = [
    'Ephermal_Market_Research_Agent',
    'Ephermal_Influencer_Discovery_Agent',
    'Ephermal_Legal_Approval_Agent',
    'Ephermal_Compliance_Agent',
    'Ephermal_Data_Validation_Agent',
    'Ephermal_Budget_Allocation_Agent',
    'Ephermal_Email_Templating_Agent',
    'Ephermal_QA_Agent',
    'Ephermal_Proofing_Agent',
    'Ephermal_Translation_Agent',
    'Ephermal_Stakeholder_Review_Agent',
    'Ephermal_Feedback_Processor',
    'Ephermal_Deployment_Orchestrator',
    'Ephermal_RealTime_Monitoring_Agent',
    'Ephermal_KPI_Tracking_Agent',
    'Ephermal_Auto_A_B_Testing_Agent',
    'Ephermal_Budget_Reallocation_Agent',
    'Ephermal_Campaign_Simulation_Agent',
    'Ephermal_Performance_Report_Agent'
  ];
  
  return hypotheticalAgents.some(hypothetical => agentName.includes(hypothetical));
}

// Function to get simulated agents for steps that don't have real agents
function getSimulatedAgentsForStep(step) {
  // Handle both string and object inputs
  const stepName = typeof step === 'string' ? step : step.name;
  // Map of step names to arrays of simulated agent names based on the provided document
  const simulatedAgents = {
    // 1. Campaign Strategy & Planning
    "Campaign Strategy & Planning": ["Ephermal_Market_Research_Agent"],
    
    // 2. Data Discovery & Analysis
    "Data Discovery": ["Ephermal_Influencer_Discovery_Agent"],
    
    // 3. Creating/Deployment Checks and Approval
    "Creating Deployment Details and Approval": ["Ephermal_Legal_Approval_Agent", "Ephermal_Compliance_Agent"],
    
    // 4. Data Proof
    "Data Request": ["Ephermal_Data_Validation_Agent", "Ephermal_Budget_Allocation_Agent"],
    
    // 6. Campaign Build & Test
    "Campaign Build & Test": ["Ephermal_Email_Templating_Agent", "Ephermal_QA_Agent"],
    
    // 7. Creative Deployment Proofs
    "Sending Production Proofs": ["Ephermal_Proofing_Agent", "Ephermal_Translation_Agent"],
    
    // 8. Custom Approval
    "Approval": ["Ephermal_Stakeholder_Review_Agent", "Ephermal_Feedback_Processor"],
    
    // 9. Go Live
    "Go Live": ["Ephermal_Deployment_Orchestrator"],
    
    // 10. Performance Measurement
    "Performance Measurement": ["Ephermal_RealTime_Monitoring_Agent", "Ephermal_KPI_Tracking_Agent"],
    
    // 11. Optimization
    "Optimization": ["Ephermal_Auto_A_B_Testing_Agent", "Ephermal_Budget_Reallocation_Agent"],
    
    // 12. Performance Measurement (Final Stage)
    "Campaign Inquiries Inbound Calls": ["Ephermal_Campaign_Simulation_Agent", "Ephermal_Performance_Report_Agent"]
  };
  
  return simulatedAgents[stepName] || [];
}

// Function to determine execution order from connections
function determineExecutionOrder(nodes, connections) {
  // Create a map of node IDs to node objects for quick lookup
  const nodeMap = new Map();
  nodes.forEach(node => nodeMap.set(node.id, { ...node, inDegree: 0, outDegree: 0 }));
  
  // Count incoming and outgoing connections for each node
  connections.forEach(conn => {
    const sourceNode = nodeMap.get(conn.from);
    const targetNode = nodeMap.get(conn.to);
    
    if (sourceNode) sourceNode.outDegree++;
    if (targetNode) targetNode.inDegree++;
  });
  
  // Find start nodes (nodes with no incoming connections or lowest inDegree)
  const startNodes = Array.from(nodeMap.values())
    .filter(node => node.inDegree === 0 || (node.name && node.name.includes('Parent_Orchestrator')));
  
  // If no clear start nodes, use nodes with lowest inDegree
  if (startNodes.length === 0) {
    const minInDegree = Math.min(...Array.from(nodeMap.values()).map(n => n.inDegree));
    Array.from(nodeMap.values())
      .filter(node => node.inDegree === minInDegree)
      .forEach(node => startNodes.push(node));
  }
  
  // Build adjacency list for topological sort
  const adjacencyList = new Map();
  nodes.forEach(node => adjacencyList.set(node.id, []));
  connections.forEach(conn => {
    if (adjacencyList.has(conn.from)) {
      adjacencyList.get(conn.from).push(conn.to);
    }
  });
  
  // Perform a modified topological sort
  const visited = new Set();
  const result = [];
  
  function dfs(nodeId) {
    if (visited.has(nodeId)) return;
    visited.add(nodeId);
    
    const neighbors = adjacencyList.get(nodeId) || [];
    for (const neighbor of neighbors) {
      dfs(neighbor);
    }
    
    if (nodeMap.has(nodeId)) {
      result.unshift(nodeMap.get(nodeId));
    }
  }
  
  // Start DFS from all start nodes
  startNodes.forEach(node => dfs(node.id));
  
  // If not all nodes were visited, add remaining nodes
  nodes.forEach(node => {
    if (!visited.has(node.id) && nodeMap.has(node.id)) {
      result.push(nodeMap.get(node.id));
    }
  });
  
  return result;
}

export async function GET() {
  try {
  console.log('STEP 1: Starting GET request to /api/progress/data');
  
  // Initialize variables at the top to make them available in the catch block
  let processData: { nodes: any[]; connections: any[] } = { nodes: [], connections: [] };
  let executionOrder: any[] = [];
  let activeSteps: any[] = [];
  let unmappedAgents: any[] = [];
  let inDevSteps: any[] = [];
  // Create a Set to track unique phases
  let phaseSet = new Set<string>();
  let phases = [
    { name: "Strategy Phase", steps: [] },
    { name: "Planning Phase", steps: [] },
    { name: "Execution Phase", steps: [] },
    { name: "Optimization Phase", steps: [] }
  ];
  let lastUpdated = new Date().toISOString();
  let animationSequence: any[] = [];
  
  try {
    console.log('STEP 2: Checking for process diagram file');
    // Path to the process diagram JSON file
    const filePath = path.join(process.cwd(), '..', 'backend', 'output', 'process_diagram.json');
    console.log('File path:', filePath);
    
    // Check if the file exists
    if (!fs.existsSync(filePath)) {
      console.log('STEP 2 ERROR: File does not exist');
      return NextResponse.json(
        { 
          error: 'Process diagram file not found',
          pptSteps: pptSteps,
          nodes: [],
          connections: [],
          activeSteps: [],
          executionOrder: []
        }, 
        { status: 404 }
      );
    }
    
    // Read the file
    console.log('STEP 3: Reading file from path:', filePath);
    const fileContent = fs.readFileSync(filePath, 'utf8');
    console.log('File content length:', fileContent.length);
    
    // Parse the JSON
    console.log('STEP 4: Parsing JSON data');
    try {
      processData = JSON.parse(fileContent);
      console.log('JSON parsed successfully, nodes count:', processData.nodes?.length || 0);
    } catch (parseError) {
      console.log('STEP 4 ERROR: JSON parse error:', parseError.message);
      throw parseError;
    }
    
    // Validate the data structure
    console.log('STEP 5: Validating data structure');
    if (!processData.nodes || !Array.isArray(processData.nodes) || 
        !processData.connections || !Array.isArray(processData.connections)) {
      console.log('STEP 5 ERROR: Invalid data structure');
      return NextResponse.json(
        { 
          error: 'Invalid process diagram data structure',
          pptSteps: pptSteps,
          nodes: [],
          connections: [],
          activeSteps: [],
          executionOrder: []
        }, 
        { status: 400 }
      );
    }
    
    // Determine execution order based on connections
    console.log('STEP 6: Determining execution order');
    try {
      executionOrder = determineExecutionOrder(processData.nodes, processData.connections);
      console.log('Execution order determined, length:', executionOrder.length);
    } catch (executionOrderError) {
      console.log('STEP 6 ERROR: Failed to determine execution order:', executionOrderError.message);
      throw executionOrderError;
    }
    
    // Map nodes to PPT steps based on execution order
    console.log('STEP 7: Mapping nodes to PPT steps');
    activeSteps = [];
    const mappedStepNames = new Set(); // Track which PPT steps have been mapped
    const executionIndices = new Map(); // Track execution indices for each step
    
    // Track all agents involved in each step
    const stepAgents = new Map();
    const unmappedAgents = [];
    
    // First pass: Identify all agents and their mappings
    executionOrder.forEach((node, index) => {
      const pptStepName = mapNodeToPptStep(node.name);
      
      if (pptStepName) {
        // This agent maps to a known step
        if (!stepAgents.has(pptStepName)) {
          stepAgents.set(pptStepName, []);
        }
        stepAgents.get(pptStepName).push({
          id: node.id,
          name: node.name,
          explanation: node.explanation,
          runtime: node.runtime,
          executionIndex: index,
          isReal: true, // Mark as a real agent from the JSON
          isHypothetical: isHypotheticalAgent(node.name) // Mark if this is a hypothetical agent (in dev)
        });
        
        if (!executionIndices.has(pptStepName)) {
          executionIndices.set(pptStepName, index);
        }
      } else {
        // This agent doesn't map to any known step - track it separately
        unmappedAgents.push({
          id: node.id,
          name: node.name,
          explanation: node.explanation,
          runtime: node.runtime,
          executionIndex: index,
          // Create a more descriptive name based on the agent name
          tempStepName: node.name.replace('Ephermal_', '').replace('_Specialist', '').replace('_', ' '),
          status: "In Development",
          isReal: true, // Mark as a real agent from the JSON
          isHypothetical: isHypotheticalAgent(node.name) // Mark if this is a hypothetical agent (in dev)
        });
      }
    });
    
    // Second pass: Create active steps from mapped agents
    stepAgents.forEach((agents, pptStepName) => {
      if (!mappedStepNames.has(pptStepName)) {
        mappedStepNames.add(pptStepName);
        
        const matchingStep = pptSteps.find(step => step.name === pptStepName);
        if (matchingStep) {
          // Sort agents by execution index
          agents.sort((a, b) => a.executionIndex - b.executionIndex);
          
          // Determine if this step is completed based on execution order
          // A step is completed if it's not the most recent one in the execution order
          const isCompleted = agents[0].executionIndex < executionOrder.length - 1;
          
          // Create a phase for this step
          let stepPhase = "Execution Phase"; // Default
          
          // Assign phase based on step name
          if (matchingStep.name === "Campaign Strategy & Planning" || 
              matchingStep.name === "Intake" || 
              matchingStep.name === "Data Discovery" || 
              matchingStep.name === "BRD Kick-Off") {
            stepPhase = "Strategy Phase";
          } 
          else if (matchingStep.name === "Campaign Creative Development" || 
                  matchingStep.name === "Data Request" || 
                  matchingStep.name === "Analytics Requests" || 
                  matchingStep.name === "Campaign Build & Test") {
            stepPhase = "Planning Phase";
          } 
          else if (matchingStep.name === "Peer QC" || 
                  matchingStep.name === "Counts Approval" || 
                  matchingStep.name === "Approval Except Email" || 
                  matchingStep.name === "Sending Production Proofs" || 
                  matchingStep.name === "Creating Deployment Details and Approval" || 
                  matchingStep.name === "Approval" || 
                  matchingStep.name === "Go Live" || 
                  matchingStep.name === "Campaign Inquiries Inbound Calls") {
            stepPhase = "Execution Phase";
          } 
          else if (matchingStep.name === "Performance Measurement" || 
                  matchingStep.name === "Optimization") {
            stepPhase = "Optimization Phase";
          }
            
          // Add the phase to the phase set for reporting
          phaseSet.add(stepPhase);
          
          // Check if any agents are hypothetical
          const hasHypotheticalAgents = agents.some((agent: any) => agent.isHypothetical);
          
          activeSteps.push({
            ...matchingStep,
            nodeId: agents[0].id, // Use the first agent's ID
            nodeName: agents[0].name,
            explanation: agents[0].explanation,
            runtime: agents.reduce((total, agent) => total + (agent.runtime || 0), 0),
            executionIndex: agents[0].executionIndex,
            agents: agents, // Store all agents involved in this step
            phase: stepPhase, // Use the determined phase
            tags: hasHypotheticalAgents ? [stepPhase, "Has Hypothetical Agents"] : [stepPhase],
            completed: isCompleted, // Mark as completed if not the most recent step
            hasRealAgents: true, // Flag indicating this step has real agents from the JSON
            hasHypotheticalAgents: hasHypotheticalAgents // Flag indicating if any agents are hypothetical (in dev)
          });
        }
      }
    });
    
    // Add simulated agents for PPT steps that don't have real agents
    pptSteps.forEach(step => {
      if (!mappedStepNames.has(step.name)) {
        // This step doesn't have any real agents - create simulated ones
        const simulatedAgents = getSimulatedAgentsForStep(step.name);
        
        if (simulatedAgents.length > 0 || step.id <= 15) { // Only add if we have simulated agents or it's a core step
          // For steps without simulated agents defined, create a generic one
          const agentsToUse = simulatedAgents.length > 0 ? simulatedAgents : [`${step.name} Specialist`];
          
          // Create a phase for this step
          let stepPhase = "Execution Phase"; // Default
          
          // Assign phase based on step name
          if (step.name === "Campaign Strategy & Planning" || 
              step.name === "Intake" || 
              step.name === "Data Discovery" || 
              step.name === "BRD Kick-Off") {
            stepPhase = "Strategy Phase";
          } 
          else if (step.name === "Campaign Creative Development" || 
                  step.name === "Data Request" || 
                  step.name === "Analytics Requests" || 
                  step.name === "Campaign Build & Test") {
            stepPhase = "Planning Phase";
          } 
          else if (step.name === "Peer QC" || 
                  step.name === "Counts Approval" || 
                  step.name === "Approval Except Email" || 
                  step.name === "Sending Production Proofs" || 
                  step.name === "Creating Deployment Details and Approval" || 
                  step.name === "Approval" || 
                  step.name === "Go Live" || 
                  step.name === "Campaign Inquiries Inbound Calls") {
            stepPhase = "Execution Phase";
          } 
          else if (step.name === "Performance Measurement" || 
                  step.name === "Optimization") {
            stepPhase = "Optimization Phase";
          }
            
          // Add the phase to the phase set for reporting
          phaseSet.add(stepPhase);
          
          // Create simulated agent objects with specific explanations based on the document
          const simulatedAgentObjects = agentsToUse.map((agentName, idx) => {
            // Get agent-specific explanation based on name
            let explanation = `This is a simulated agent for the ${step.name} step. (In Development)`;
            let role = "";
            
            // Assign specific explanations based on agent name
            if (agentName === "Ephermal_Market_Research_Agent") {
              explanation = "Gathers external market data, relevant news, or macroeconomic trends.";
              role = "Provides up-to-date market context before the strategy is finalized.";
            } else if (agentName === "Ephermal_Influencer_Discovery_Agent") {
              explanation = "Mines social data to find potential influencers.";
              role = "Suggests influencer partnerships for the upcoming campaign.";
            } else if (agentName === "Ephermal_Legal_Approval_Agent") {
              explanation = "Checks compliance with healthcare regulations, disclaimers, HIPAA, etc.";
              role = "Flags content that may violate legal or regulatory guidelines.";
            } else if (agentName === "Ephermal_Compliance_Agent") {
              explanation = "Overlaps with legal, but specifically focuses on brand compliance and disclaimers.";
              role = "Ensures disclaimers and brand usage meet all internal policy standards.";
            } else if (agentName === "Ephermal_Data_Validation_Agent") {
              explanation = "Checks for data inconsistencies or missing fields in the final stage.";
              role = "Confirms data correctness before the campaign is built.";
            } else if (agentName === "Ephermal_Budget_Allocation_Agent") {
              explanation = "Verifies that final budgets align with the allocated amounts from finance.";
              role = "Cross-checks marketing spend vs. forecast to avoid overrun.";
            } else if (agentName === "Ephermal_Email_Templating_Agent") {
              explanation = "Builds the HTML email templates.";
              role = "Ensures the correct brand styling in the email layout.";
            } else if (agentName === "Ephermal_QA_Agent") {
              explanation = "Automatically checks for broken links, placeholder text, or layout issues.";
              role = "Minimizes errors before final deployment.";
            } else if (agentName === "Ephermal_Proofing_Agent") {
              explanation = "Generates previews of each ad, email, banner.";
              role = "Allows human reviewers to see how the final assets will look.";
            } else if (agentName === "Ephermal_Translation_Agent") {
              explanation = "If multi-lingual campaigns are needed, handles translations.";
              role = "Ensures consistent brand voice across languages.";
            } else if (agentName === "Ephermal_Stakeholder_Review_Agent") {
              explanation = "Waits for designated stakeholders (e.g., brand manager, compliance officer) to review.";
              role = "Tracks sign-offs or requests for revision.";
            } else if (agentName === "Ephermal_Feedback_Processor") {
              explanation = "Ingests stakeholder feedback and either automatically applies changes or routes them to the relevant agent.";
              role = "Closes the loop on feedback.";
            } else if (agentName === "Ephermal_Deployment_Orchestrator") {
              explanation = "Handles final push of content to each channel (e.g., scheduling social posts, sending emails).";
              role = "Ensures the campaign goes live at the correct times with the correct assets.";
            } else if (agentName === "Ephermal_RealTime_Monitoring_Agent") {
              explanation = "Monitors early engagement metrics, error logs, unsubscribes, etc.";
              role = "Flags anomalies or immediate performance issues.";
            } else if (agentName === "Ephermal_KPI_Tracking_Agent") {
              explanation = "Continuously compares performance metrics to KPI thresholds.";
              role = "Alerts if CTR or conversions are below target.";
            } else if (agentName === "Ephermal_Auto_A_B_Testing_Agent") {
              explanation = "Creates new test variants on-the-fly, rotating them to find better results.";
              role = "Adjusts creative or targeting in real-time to maximize performance.";
            } else if (agentName === "Ephermal_Budget_Reallocation_Agent") {
              explanation = "Reallocates budget from underperforming channels to high-performing ones.";
              role = "Aims to improve ROI mid-campaign.";
            } else if (agentName === "Ephermal_Campaign_Simulation_Agent") {
              explanation = "Replays the campaign with hypothetical adjustments to see if different decisions would yield better results.";
              role = "Post-mortem analysis to inform future strategy.";
            } else if (agentName === "Ephermal_Performance_Report_Agent") {
              explanation = "Produces a final campaign performance deck.";
              role = "Summarizes metrics, compares them to goals, and archives data in historical_campaigns.";
            }
            
            // Combine explanation and role if both are available
            const fullExplanation = role ? `${explanation} ${role}` : explanation;
            
            return {
              id: `simulated-${step.id}-${idx}`,
              name: agentName,
              explanation: fullExplanation,
              runtime: 0,
              executionIndex: getStepExecutionIndex(step.name) + (idx * 0.01), // Use proper step order with slight offset for multiple agents
              isSimulated: true, // Mark as simulated
              isHypothetical: isHypotheticalAgent(agentName) // Mark if this is a hypothetical agent (in dev)
            };
          });
          
          // Check if any simulated agents are hypothetical
          const hasHypotheticalAgents = simulatedAgentObjects.some((agent: any) => agent.isHypothetical);
          
          activeSteps.push({
            ...step,
            nodeId: `simulated-${step.id}`,
            nodeName: agentsToUse[0],
            explanation: `This step is currently simulated for demonstration purposes. (In Development)`,
            runtime: 0,
            executionIndex: getStepExecutionIndex(step.name), // Use proper step order based on pptSteps
            agents: simulatedAgentObjects,
            tags: hasHypotheticalAgents ? [stepPhase, "Simulated", "Has Hypothetical Agents"] : [stepPhase, "Simulated"],
            hasHypotheticalAgents: hasHypotheticalAgents, // Flag indicating if any agents are hypothetical (in dev)
            completed: false,
            hasRealAgents: false,
            isSimulated: true
          });
        }
      }
    });
    
    // Add unmapped agents as temporary steps
    unmappedAgents.forEach(agent => {
      // Create a temporary step ID that won't conflict with existing steps
      const tempId = 100 + agent.executionIndex;
      
      // Determine if this step is completed based on execution order
      const isCompleted = agent.executionIndex < executionOrder.length - 1;
      
      // Create a more descriptive name for the agent
      const displayName = agent.name
        .replace('Ephermal_', '')
        .replace('_Specialist', '')
        .split('_')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
      
      // Determine phase based on agent name
      let phase = "Execution Phase"; // Default phase
      const agentName = agent.name || "";
      
      if (agentName.includes("Market_Research") || 
          agentName.includes("Customer_Specialist") || 
          agentName.includes("Historical_Campaign")) {
        phase = "Strategy Phase";
      } 
      else if (agentName.includes("Content_Writer") || 
               agentName.includes("Data_Validation") || 
               agentName.includes("Budget_Allocation") || 
               agentName.includes("Email_Templating") || 
               agentName.includes("QA_Agent")) {
        phase = "Planning Phase";
      } 
      else if (agentName.includes("Proofing") || 
               agentName.includes("Translation") || 
               agentName.includes("Legal_Approval") || 
               agentName.includes("Compliance") || 
               agentName.includes("Stakeholder_Review") || 
               agentName.includes("Feedback_Processor") || 
               agentName.includes("Deployment_Orchestrator")) {
        phase = "Execution Phase";
      } 
      else if (agentName.includes("RealTime_Monitoring") || 
               agentName.includes("KPI_Tracking") || 
               agentName.includes("Auto_A_B_Testing") || 
               agentName.includes("Budget_Reallocation") || 
               agentName.includes("Campaign_Simulation") || 
               agentName.includes("Performance_Report")) {
        phase = "Optimization Phase";
      }
      
      activeSteps.push({
        id: tempId,
        name: displayName,
        description: `This step represents the ${displayName} in the workflow. (In Development)`,
        nodeId: agent.id,
        nodeName: agent.name,
        explanation: agent.explanation || `This agent (${displayName}) is still being integrated into the workflow. (In Development)`,
        runtime: agent.runtime,
        executionIndex: agent.executionIndex,
        status: "In Development",
        inDevelopment: true,
        phase: phase, // Set the phase here
        completed: isCompleted, // Mark as completed if not the most recent step
        agents: [agent],
        hasRealAgents: true,
        tags: [phase, "In Development", "Agent Activity"]
      });
    });
    
    // Sort active steps by their execution order first, then by PPT step ID
    activeSteps.sort((a, b) => {
      // If both have execution indices, sort by that
      if (a.executionIndex !== undefined && b.executionIndex !== undefined) {
        return a.executionIndex - b.executionIndex;
      }
      // Otherwise fall back to PPT step ID
      return a.id - b.id;
    });
    
    // Categorize steps into phases for the column layout according to the document
    console.log('STEP 8: Categorizing steps into phases');
    const phases = [
      { name: "Strategy Phase", steps: [] },
      { name: "Planning Phase", steps: [] },
      { name: "Execution Phase", steps: [] },
      { name: "Optimization Phase", steps: [] }
    ];
    
    // Distribute steps into phases based on their names and purposes
    console.log('Active steps count before phase assignment:', activeSteps.length);
    activeSteps.forEach((step, index) => {
      try {
        console.log(`Processing step ${index}: ${step.name || 'unnamed'}`);
        // Ensure step has all required properties
        if (!step) {
          console.log(`STEP 8 ERROR: Step at index ${index} is undefined`);
          return;
        }
        // Ensure step has a phase property
        if (!step.phase) {
          step.phase = "Execution Phase"; // Default phase
        }
        // Map step names to phases based on the document structure
      if (step.name === "Campaign Strategy & Planning" || 
          step.name === "Intake" || 
          step.name === "Data Discovery" || 
          step.name === "BRD Kick-Off") {
        // Strategy Phase
        step.phase = "Strategy Phase";
        phases[0].steps.push(step);
      } 
      else if (step.name === "Campaign Creative Development" || 
               step.name === "Data Request" || 
               step.name === "Analytics Requests" || 
               step.name === "Campaign Build & Test") {
        // Planning Phase
        step.phase = "Planning Phase";
        phases[1].steps.push(step);
      } 
      else if (step.name === "Peer QC" || 
               step.name === "Counts Approval" || 
               step.name === "Approval Except Email" || 
               step.name === "Sending Production Proofs" || 
               step.name === "Creating Deployment Details and Approval" || 
               step.name === "Approval" || 
               step.name === "Go Live" || 
               step.name === "Campaign Inquiries Inbound Calls") {
        // Execution Phase
        step.phase = "Execution Phase";
        phases[2].steps.push(step);
      } 
      else if (step.name === "Performance Measurement" || 
               step.name === "Optimization") {
        // Optimization Phase
        step.phase = "Optimization Phase";
        phases[3].steps.push(step);
      } 
      else if (step.inDevelopment) {
        // For in-development steps, use agent name to determine phase
        const agentName = step.nodeName || "";
        
        if (agentName.includes("Market_Research") || 
            agentName.includes("Customer_Specialist") || 
            agentName.includes("Historical_Campaign")) {
          step.phase = "Strategy Phase";
          phases[0].steps.push(step);
        } 
        else if (agentName.includes("Content_Writer") || 
                 agentName.includes("Data_Validation") || 
                 agentName.includes("Budget_Allocation") || 
                 agentName.includes("Email_Templating") || 
                 agentName.includes("QA_Agent")) {
          step.phase = "Planning Phase";
          phases[1].steps.push(step);
        } 
        else if (agentName.includes("Proofing") || 
                 agentName.includes("Translation") || 
                 agentName.includes("Legal_Approval") || 
                 agentName.includes("Compliance") || 
                 agentName.includes("Stakeholder_Review") || 
                 agentName.includes("Feedback_Processor") || 
                 agentName.includes("Deployment_Orchestrator")) {
          step.phase = "Execution Phase";
          phases[2].steps.push(step);
        } 
        else if (agentName.includes("RealTime_Monitoring") || 
                 agentName.includes("KPI_Tracking") || 
                 agentName.includes("Auto_A_B_Testing") || 
                 agentName.includes("Budget_Reallocation") || 
                 agentName.includes("Campaign_Simulation") || 
                 agentName.includes("Performance_Report")) {
          step.phase = "Optimization Phase";
          phases[3].steps.push(step);
        } 
        else {
          // Default to Execution Phase if no match
          step.phase = "Execution Phase";
          phases[2].steps.push(step);
        }
      } 
      else {
        // Default fallback based on step ID for any other steps
        if (step.id <= 4) {
          step.phase = "Strategy Phase";
          phases[0].steps.push(step);
        } else if (step.id <= 8) {
          step.phase = "Planning Phase";
          phases[1].steps.push(step);
        } else if (step.id <= 13) {
          step.phase = "Execution Phase";
          phases[2].steps.push(step);
        } else {
          step.phase = "Optimization Phase";
          phases[3].steps.push(step);
        }
      }
      } catch (phaseError) {
        console.log(`STEP 8 ERROR: Error processing step ${index}:`, phaseError.message);
      }
    });
    
    // Add lastUpdated timestamp to indicate live data
    console.log('STEP 9: Adding timestamp and creating animation sequence');
    const lastUpdated = new Date().toISOString();
    
    // Add animation sequence based on the execution order from process_diagram.json
    let animationSequence: number[] = [];
    try {
      // First, create a mapping of node IDs to their execution indices
      const nodeExecutionIndices: {[key: string]: number} = {};
      executionOrder.forEach((node, index) => {
        nodeExecutionIndices[node.id] = index;
      });
      
      // Map each node in the execution order to its corresponding step
      animationSequence = executionOrder.map(node => {
        // Find the corresponding step in activeSteps
        const matchingStep = activeSteps.find(step => 
          step.agents && step.agents.some(agent => agent.id === node.id)
        );
        
        return matchingStep ? matchingStep.id : null;
      }).filter(id => id !== null);
      
      // Add any steps that weren't mapped directly but should be part of the animation
      // (like simulated steps) in their proper order based on executionIndex
      const unmappedSteps = activeSteps.filter(step => 
        !animationSequence.includes(step.id) && 
        step.executionIndex !== undefined
      );
      
      // Sort unmapped steps by execution index
      unmappedSteps.sort((a, b) => a.executionIndex - b.executionIndex);
      
      // Add them to the animation sequence
      unmappedSteps.forEach(step => {
        // Find the right position to insert this step based on its execution index
        const insertIndex = animationSequence.findIndex(stepId => {
          const foundStep = activeSteps.find(s => s.id === stepId);
          return foundStep && foundStep.executionIndex !== undefined && step.executionIndex !== undefined && 
                 foundStep.executionIndex > step.executionIndex;
        });
        
        if (insertIndex === -1) {
          // Add to the end if no position found
          animationSequence.push(step.id);
        } else {
          // Insert at the right position
          animationSequence.splice(insertIndex, 0, step.id);
        }
      });
    } catch (animationError) {
      console.log('STEP 9 ERROR: Error creating animation sequence:', animationError.message);
      animationSequence = [];
    }
    
    // Return the combined data
    console.log('STEP 10: Preparing final response');
    try {
      return NextResponse.json({
      pptSteps: pptSteps,
      nodes: processData.nodes,
      connections: processData.connections,
      activeSteps: activeSteps,
      phases: phases,
      executionOrder: executionOrder.map(node => ({
        id: node.id,
        name: node.name,
        explanation: node.explanation,
        runtime: node.runtime
      })),
      animationSequence: animationSequence, // Add animation sequence for frontend
      lastUpdated: lastUpdated // Include timestamp for live data indicator
    });
    } catch (responseError) {
      console.log('STEP 10 ERROR: Error creating response:', responseError.message);
      return NextResponse.json(
        { 
          error: 'Failed to create response: ' + responseError.message,
          pptSteps: pptSteps,
          nodes: [],
          connections: [],
          activeSteps: [],
          executionOrder: []
        }, 
        { status: 500 }
      );
    }
    
  } catch (error) {
    console.error('Error reading process diagram:', error);
    console.error('Error stack:', error.stack);
    
    // Create a safe version of activeSteps without any potentially circular references
    let safeActiveSteps = [];
    try {
      // Try to create a safe version of activeSteps with minimal properties
      if (Array.isArray(activeSteps)) {
        safeActiveSteps = activeSteps.map(step => ({
          id: step.id,
          name: step.name,
          phase: step.phase || 'Unknown Phase'
        }));
      }
    } catch (e) {
      console.error('Error creating safe active steps:', e);
    }
    
    return NextResponse.json(
      { 
        error: 'Failed to process diagram data: ' + (error.message || 'Unknown error'),
        errorStack: error.stack,
        pptSteps: pptSteps,
        nodes: [],
        connections: [],
        activeSteps: safeActiveSteps,
        executionOrder: []
      }, 
      { status: 500 }
    );
  }
  } catch (error) {
    console.error('Error processing progress data:', error);
    console.error('Error stack:', error instanceof Error ? error.stack : 'No stack trace available');
    
    return new NextResponse(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Internal Server Error',
      location: 'API route: /api/progress/data' 
    }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
