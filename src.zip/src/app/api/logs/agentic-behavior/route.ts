import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const LOG_FILE_PATH = path.join(process.cwd(), '..', 'backend', 'output', 'logging_agentic_behavior.json');

export async function GET() {
  try {
    // Check if file exists
    if (!fs.existsSync(LOG_FILE_PATH)) {
      return NextResponse.json(
        { error: 'Log file does not exist', exists: false },
        { status: 404 }
      );
    }

    // Read file content
    const fileContent = fs.readFileSync(LOG_FILE_PATH, 'utf8');
    
    // Check if file is empty
    if (!fileContent.trim()) {
      return NextResponse.json(
        { error: 'Log file is empty', exists: true, isEmpty: true },
        { status: 200 }
      );
    }

    try {
      // Parse JSON content
      const logData = JSON.parse(fileContent);
      
      // Return the parsed data
      return NextResponse.json(
        { 
          exists: true, 
          isEmpty: false, 
          data: logData 
        },
        { status: 200 }
      );
    } catch (parseError) {
      // Handle JSON parsing error
      return NextResponse.json(
        { 
          error: 'Invalid JSON format in log file', 
          exists: true, 
          isEmpty: false,
          rawContent: fileContent 
        },
        { status: 500 }
      );
    }
  } catch (error) {
    // Handle any other errors
    return NextResponse.json(
      { error: 'Failed to read log file', message: (error as Error).message },
      { status: 500 }
    );
  }
}
