import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

// Function to get file size in a readable format
function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Function to get file extension
function getFileExtension(filename: string): string {
  return path.extname(filename).slice(1).toUpperCase();
}

export async function GET() {
  try {
    // Path to the synthetic_data directory
    const dataDir = path.join(process.cwd(), '..', 'backend', 'synthetic_data');
    
    // Read all files in the directory
    const files = fs.readdirSync(dataDir);
    
    // Get file details
    const fileDetails = files.map(file => {
      const filePath = path.join(dataDir, file);
      const stats = fs.statSync(filePath);
      
      return {
        id: Buffer.from(file).toString('base64'),
        name: file.replace(/\.[^/.]+$/, ""), // Remove file extension from name
        type: getFileExtension(file),
        size: formatFileSize(stats.size),
        status: 'Approved', // Default status
        lastModified: stats.mtime.toISOString().split('T')[0], // Format date as YYYY-MM-DD
        author: 'System', // Default author
        path: filePath
      };
    });
    
    return NextResponse.json({ documents: fileDetails });
  } catch (error) {
    console.error('Error reading documents:', error);
    return NextResponse.json({ error: 'Failed to fetch documents' }, { status: 500 });
  }
}
