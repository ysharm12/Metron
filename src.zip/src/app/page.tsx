"use client";

import MainLayout from '../components/MainLayout';

export default function Home() {
  const handleResetReports = async () => {
    try {
      // Call the reset API
      const response = await fetch('/api/reset-seen-reports', {
        method: 'POST',
      });
      
      // Clear localStorage
      localStorage.removeItem('optumMarketing_seenReports');
      
      // Reload the page to apply changes
      window.location.reload();
    } catch (error) {
      console.error('Error resetting reports:', error);
    }
  };
  return (
    <MainLayout>
      <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Welcome to Optum Marketing Platform</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-blue-50 dark:bg-blue-900 p-6 rounded-lg">
            <h2 className="text-xl font-semibold text-blue-700 dark:text-blue-300 mb-3">Campaign Management</h2>
            <p className="text-gray-700 dark:text-gray-300">
              Create, manage, and track marketing campaigns with our comprehensive platform.
              Use our AI-powered tools to optimize your marketing strategy.
            </p>
          </div>
          
          <div className="bg-green-50 dark:bg-green-900 p-6 rounded-lg">
            <h2 className="text-xl font-semibold text-green-700 dark:text-green-300 mb-3">Content Creation</h2>
            <p className="text-gray-700 dark:text-gray-300">
              Generate high-quality content for your campaigns with our automated content creation tools.
              Review and approve content before publishing.
            </p>
          </div>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg mb-8">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Getting Started</h2>
          <ol className="list-decimal list-inside space-y-2 text-gray-700 dark:text-gray-300">
            <li>Navigate to the <strong>Trigger</strong> page to start a new marketing campaign</li>
            <li>Use <strong>Blueprints</strong> to select a campaign template</li>
            <li>Review and approve content in the <strong>HITL</strong> (Human-in-the-Loop) section</li>
            <li>Track campaign performance in the <strong>Logs</strong> section</li>
          </ol>
        </div>
        
        <div className="flex flex-col md:flex-row gap-4 justify-center">
          <a href="/trigger" className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
            Start New Campaign
          </a>
          <a href="/documents" className="inline-flex items-center justify-center px-5 py-3 border border-gray-300 dark:border-gray-600 text-base font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700">
            View Documents
          </a>
        </div>
        {/* Debug button to reset seen reports */}
        <button 
          onClick={handleResetReports}
          className="fixed bottom-4 right-4 bg-red-500 text-white px-4 py-2 rounded shadow-md hover:bg-red-600 text-sm z-50"
        >
          Reset Report Tracking
        </button>
      </div>
    </MainLayout>
  );
}
