"use client"
import { useState } from 'react';
import MainLayout from '../../components/MainLayout';
import { AgentBehaviorLogs, RuntimeMetrics, TasksCounter, LogsSummary } from '../../components/logs';

export default function LogsPage() {
  const [activeTab, setActiveTab] = useState<string>('summary');

  return (
    <MainLayout>
      <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Agent Logs</h1>
          
          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              Export Logs
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 dark:border-gray-700 mb-6">
          <ul className="flex flex-wrap -mb-px">
            <li className="mr-2">
              <button 
                onClick={() => setActiveTab('summary')} 
                className={`inline-block py-2 px-4 text-sm font-medium ${activeTab === 'summary' 
                  ? 'text-blue-600 border-b-2 border-blue-600 dark:text-blue-500 dark:border-blue-500' 
                  : 'text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300'}`}
              >
                Summary
              </button>
            </li>
            <li className="mr-2">
              <button 
                onClick={() => setActiveTab('behavior')} 
                className={`inline-block py-2 px-4 text-sm font-medium ${activeTab === 'behavior' 
                  ? 'text-blue-600 border-b-2 border-blue-600 dark:text-blue-500 dark:border-blue-500' 
                  : 'text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300'}`}
              >
                Agent Behavior
              </button>
            </li>
            <li className="mr-2">
              <button 
                onClick={() => setActiveTab('runtime')} 
                className={`inline-block py-2 px-4 text-sm font-medium ${activeTab === 'runtime' 
                  ? 'text-blue-600 border-b-2 border-blue-600 dark:text-blue-500 dark:border-blue-500' 
                  : 'text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300'}`}
              >
                Runtime Metrics
              </button>
            </li>
            <li className="mr-2">
              <button 
                onClick={() => setActiveTab('tasks')} 
                className={`inline-block py-2 px-4 text-sm font-medium ${activeTab === 'tasks' 
                  ? 'text-blue-600 border-b-2 border-blue-600 dark:text-blue-500 dark:border-blue-500' 
                  : 'text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300'}`}
              >
                Tasks Counter
              </button>
            </li>
          </ul>
        </div>

        {/* Tab Content */}
        <div className="tab-content">
          {activeTab === 'summary' && (
            <div>
              <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Agent Activity Summary</h2>
              <LogsSummary className="mb-6" />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                <div>
                  <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Runtime Overview</h3>
                  <RuntimeMetrics />
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Tasks Overview</h3>
                  <TasksCounter />
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'behavior' && (
            <div>
              <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Agent Behavior Logs</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Detailed logs of agent activities, processes, and task execution. These logs show the step-by-step execution of the marketing automation workflow.
              </p>
              <AgentBehaviorLogs />
            </div>
          )}
          
          {activeTab === 'runtime' && (
            <div>
              <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Agent Runtime Metrics</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Performance metrics showing how long each agent takes to complete their tasks. This helps identify bottlenecks in the workflow.
              </p>
              <RuntimeMetrics />
            </div>
          )}
          
          {activeTab === 'tasks' && (
            <div>
              <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Agent Tasks Counter</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Distribution of tasks across different agents, showing which agents are handling the most work in the system.
              </p>
              <TasksCounter />
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
