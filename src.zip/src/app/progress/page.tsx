"use client";

import { useState, useEffect } from 'react';
import MainLayout from '../../components/MainLayout';
import ProgressAnimation from '../../components/progress/ProgressAnimation';
import Card from '../../components/ui/Card';
import { motion } from 'framer-motion';

// CSS for toggle switch
const toggleStyles = `
  .toggle-checkbox {
    right: 0;
    z-index: 5;
    transition: all 0.3s;
    border-color: #e2e8f0;
  }
  .toggle-checkbox:checked {
    right: 4px;
    border-color: #3b82f6;
  }
  .toggle-label {
    transition: background-color 0.3s;
  }
`;

export default function ProgressPage() {
  const [processData, setProcessData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);

  const fetchProcessData = async () => {
    try {
      if (!loading) setLoading(true);
      const response = await fetch('/api/progress/data');
      
      if (!response.ok) {
        throw new Error(`Failed to fetch process data: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Check if data has changed before updating state
      const hasChanged = !processData || 
        JSON.stringify(data.activeSteps) !== JSON.stringify(processData.activeSteps) ||
        JSON.stringify(data.executionOrder) !== JSON.stringify(processData.executionOrder);
      
      if (hasChanged) {
        console.log('Process data updated:', data);
        setProcessData(data);
        setLastUpdated(new Date());
      }
      
      setError(null);
    } catch (err) {
      console.error('Error fetching process data:', err);
      setError(err.message || 'Failed to load process data');
    } finally {
      setLoading(false);
    }
  };

  // Initial data fetch
  useEffect(() => {
    fetchProcessData();
  }, []);
  
  // Set up auto-refresh interval
  useEffect(() => {
    if (!autoRefresh) return;
    
    const intervalId = setInterval(() => {
      console.log('Auto-refreshing process data...');
      fetchProcessData();
    }, 10000); // Refresh every 10 seconds
    
    return () => clearInterval(intervalId);
  }, [autoRefresh]);

  return (
    <MainLayout>
      {/* Add toggle switch styles */}
      <style jsx global>{toggleStyles}</style>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              Marketing Campaign Progress
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Visualizing the automated marketing workflow from strategy to optimization
            </p>
          </div>
          <div className="flex flex-col items-end">
            <div className="flex items-center mb-2">
              <label htmlFor="auto-refresh" className="mr-2 text-sm text-gray-600 dark:text-gray-400">
                Auto-refresh:
              </label>
              <div className="relative inline-block w-10 mr-2 align-middle select-none">
                <input 
                  type="checkbox" 
                  id="auto-refresh" 
                  checked={autoRefresh} 
                  onChange={() => setAutoRefresh(!autoRefresh)}
                  className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"
                />
                <label 
                  htmlFor="auto-refresh" 
                  className={`toggle-label block overflow-hidden h-6 rounded-full cursor-pointer ${autoRefresh ? 'bg-blue-500' : 'bg-gray-300'}`}
                ></label>
              </div>
            </div>
            {lastUpdated && (
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Last updated: {lastUpdated.toLocaleTimeString()}
              </p>
            )}
          </div>
        </div>
      </motion.div>

      <Card>
        {loading && !processData ? (
          <div className="flex justify-center items-center h-96">
            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
            <p className="mt-2">
              Unable to load process data. Please ensure the backend service is running and try again.
            </p>
            <button 
              onClick={fetchProcessData}
              className="mt-3 bg-red-100 hover:bg-red-200 text-red-800 font-semibold py-2 px-4 rounded"
            >
              Try Again
            </button>
          </div>
        ) : (
          <>
            {loading && (
              <div className="absolute top-4 right-4">
                <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-blue-500"></div>
              </div>
            )}
            <ProgressAnimation processData={processData} />
          </>
        )}
      </Card>
    </MainLayout>
  );
}
