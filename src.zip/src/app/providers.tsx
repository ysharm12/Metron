"use client";

import React from 'react';
import { ReportMonitorProvider } from '../contexts/ReportMonitorContext';

export function Providers({ children }: { children: React.ReactNode }) {
  // Use a very short polling interval (500ms) for near real-time monitoring
  return (
    <ReportMonitorProvider pollingInterval={500}>
      {children}
    </ReportMonitorProvider>
  );
}
