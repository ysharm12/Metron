import MainLayout from '../../components/MainLayout';
import HtmlFileViewer from '../../components/hitl/HtmlFileViewer';

export default function HITLPage() {

  return (
    <MainLayout>
      <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Human-in-the-Loop (HITL) Review</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">Review and approve generated HTML reports from the backend</p>
        </div>
        
        {/* HTML File Viewer Section */}
        <div>
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 border border-gray-200 dark:border-gray-600">
            <HtmlFileViewer />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
