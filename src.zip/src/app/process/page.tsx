"use client";
import { useState } from 'react';
import MainLayout from '../../components/MainLayout';
import { ProcessFlowDiagram, ExecutionSteps, AgentExplanation } from '@/components/process';

export default function ProcessPage() {
  const [activeTab, setActiveTab] = useState('diagram');

  return (
    <MainLayout>
      <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6">
        <h1 className="text-3xl font-bold mb-2">Process Visualization</h1>
        <p className="text-gray-600 mb-6">
          Explore the marketing automation workflow, from trigger to content generation
        </p>

        {/* Tabs */}
        <div className="border-b border-gray-200 mb-6">
          <ul className="flex flex-wrap -mb-px">
            <li className="mr-2">
              <button
                onClick={() => setActiveTab('diagram')}
                className={`inline-block p-4 ${
                  activeTab === 'diagram'
                    ? 'text-blue-600 border-b-2 border-blue-600 rounded-t-lg active'
                    : 'text-gray-500 hover:text-gray-600 hover:border-gray-300 border-b-2 border-transparent'
                }`}
              >
                Process Flow Diagram
              </button>
            </li>
            <li className="mr-2">
              <button
                onClick={() => setActiveTab('steps')}
                className={`inline-block p-4 ${
                  activeTab === 'steps'
                    ? 'text-blue-600 border-b-2 border-blue-600 rounded-t-lg active'
                    : 'text-gray-500 hover:text-gray-600 hover:border-gray-300 border-b-2 border-transparent'
                }`}
              >
                Execution Steps
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('agents')}
                className={`inline-block p-4 ${
                  activeTab === 'agents'
                    ? 'text-blue-600 border-b-2 border-blue-600 rounded-t-lg active'
                    : 'text-gray-500 hover:text-gray-600 hover:border-gray-300 border-b-2 border-transparent'
                }`}
              >
                Agents & Roles
              </button>
            </li>
          </ul>
        </div>

        {/* Tab Content */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          {activeTab === 'diagram' && (
            <div>
              <h2 className="text-2xl font-bold mb-6">Process Flow Diagram</h2>
              <p className="text-gray-600 mb-4">
                This diagram visualizes how agents interact during the marketing automation process. 
                Hover over nodes to see details about each agent's role and runtime.
              </p>
              <div className="h-[800px]">
                <ProcessFlowDiagram />
              </div>
            </div>
          )}

          {activeTab === 'steps' && <ExecutionSteps />}
          
          {activeTab === 'agents' && <AgentExplanation />}
        </div>
      </div>
    </MainLayout>
  );
}
